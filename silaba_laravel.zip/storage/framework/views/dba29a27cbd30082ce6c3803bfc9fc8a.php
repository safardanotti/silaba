<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <!-- Welcome Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 bg-gradient" style="background: linear-gradient(135deg, #2e7d32, #4caf50);">
                <div class="card-body text-white py-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="mb-1">Selamat Datang, <?php echo e($anggota->nama_anggota); ?>!</h4>
                            <p class="mb-0 opacity-75">No. Anggota: <?php echo e($anggota->no_anggota); ?> | <?php echo e($anggota->unit_kerja ?? '-'); ?></p>
                        </div>
                        <div class="col-md-4 text-md-end mt-3 mt-md-0">
                            <a href="<?php echo e(route('anggota.pengajuan.create')); ?>" class="btn btn-light">
                                <i class="fas fa-plus me-2"></i>Ajukan Pinjaman
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card stat-card simpanan h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-piggy-bank"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Total Simpanan</p>
                            <h4 class="mb-0 currency-display">Rp <?php echo e(number_format($totalSimpanan, 0, ',', '.')); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="<?php echo e(route('anggota.simpanan')); ?>" class="btn btn-sm btn-outline-success">
                        Lihat Detail <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card stat-card pinjaman h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Sisa Pinjaman</p>
                            <h4 class="mb-0 currency-display">Rp <?php echo e(number_format($totalPinjaman, 0, ',', '.')); ?></h4>
                            <small class="text-muted"><?php echo e($pinjamanAktif); ?> pinjaman aktif</small>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="<?php echo e(route('anggota.pinjaman.index')); ?>" class="btn btn-sm btn-outline-warning">
                        Lihat Detail <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card stat-card angsuran h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Angsuran Bulan Ini</p>
                            <h4 class="mb-0 currency-display">Rp <?php echo e(number_format($angsuranBulanIni->sum('total_angsuran'), 0, ',', '.')); ?></h4>
                            <small class="text-muted"><?php echo e($angsuranBulanIni->count()); ?> angsuran</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Angsuran Jatuh Tempo -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle text-warning me-2"></i>Angsuran Bulan Ini</h6>
                </div>
                <div class="card-body">
                    <?php if($angsuranBulanIni->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>No. Pinjaman</th>
                                        <th>Ke-</th>
                                        <th>Jatuh Tempo</th>
                                        <th class="text-end">Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $angsuranBulanIni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('anggota.pinjaman.show', $ang->pinjaman_id)); ?>">
                                                    <?php echo e($ang->pinjaman->no_pinjaman); ?>

                                                </a>
                                            </td>
                                            <td><?php echo e($ang->angsuran_ke); ?></td>
                                            <td>
                                                <?php echo e(\Carbon\Carbon::parse($ang->tanggal_jatuh_tempo)->format('d/m/Y')); ?>

                                            </td>
                                            <td class="text-end currency-display">
                                                Rp <?php echo e(number_format($ang->total_angsuran, 0, ',', '.')); ?>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-check-circle fa-3x mb-3 text-success"></i>
                            <p class="mb-0">Tidak ada angsuran bulan ini</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Saldo Simpanan -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-wallet text-success me-2"></i>Saldo Simpanan</h6>
                    <a href="<?php echo e(route('anggota.simpanan')); ?>" class="btn btn-sm btn-outline-success">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <?php if($saldoSimpanan->count() > 0): ?>
                        <?php $__currentLoopData = $saldoSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saldo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                <div>
                                    <strong><?php echo e($saldo->jenisSimpanan->nama_simpanan); ?></strong>
                                    <br>
                                    <small class="text-muted"><?php echo e($saldo->jenisSimpanan->kode_simpanan); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="currency-display fs-5 text-success">
                                        Rp <?php echo e(number_format($saldo->total_saldo, 0, ',', '.')); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-piggy-bank fa-3x mb-3"></i>
                            <p class="mb-0">Belum ada data simpanan</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Pinjaman Aktif -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-hand-holding-usd text-warning me-2"></i>Pinjaman Aktif</h6>
                    <a href="<?php echo e(route('anggota.pinjaman.index')); ?>" class="btn btn-sm btn-outline-warning">Lihat Semua</a>
                </div>
                <div class="card-body">
                    <?php if($pinjamanList->count() > 0): ?>
                        <?php $__currentLoopData = $pinjamanList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border rounded p-3 mb-2">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <strong><?php echo e($pinj->no_pinjaman); ?></strong>
                                        <br>
                                        <small class="text-muted"><?php echo e($pinj->produkPinjaman->nama_produk); ?></small>
                                    </div>
                                    <div class="text-end">
                                        <?php echo $pinj->status_label; ?>

                                    </div>
                                </div>
                                <hr class="my-2">
                                <div class="row small">
                                    <div class="col-6">
                                        <span class="text-muted">Pinjaman:</span><br>
                                        <strong class="currency-display">Rp <?php echo e(number_format($pinj->jumlah_pinjaman, 0, ',', '.')); ?></strong>
                                    </div>
                                    <div class="col-6 text-end">
                                        <span class="text-muted">Sisa:</span><br>
                                        <strong class="currency-display text-danger">Rp <?php echo e(number_format($pinj->saldo_pokok, 0, ',', '.')); ?></strong>
                                    </div>
                                </div>
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-success" style="width: <?php echo e($pinj->persentase_lunas); ?>%"></div>
                                </div>
                                <small class="text-muted"><?php echo e($pinj->persentase_lunas); ?>% terbayar (<?php echo e($pinj->angsuran_ke); ?>/<?php echo e($pinj->tenor); ?>)</small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-hand-holding-usd fa-3x mb-3"></i>
                            <p class="mb-0">Tidak ada pinjaman aktif</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Riwayat Simpanan Terakhir -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-history text-info me-2"></i>Transaksi Simpanan Terakhir</h6>
                </div>
                <div class="card-body">
                    <?php if($riwayatSimpanan->count() > 0): ?>
                        <?php $__currentLoopData = $riwayatSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $riwayat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="d-flex justify-content-between py-2 border-bottom">
                                <div>
                                    <span class="badge <?php echo e($riwayat->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e(ucfirst($riwayat->jenis_transaksi)); ?>

                                    </span>
                                    <span class="ms-2"><?php echo e($riwayat->jenisSimpanan->nama_simpanan); ?></span>
                                    <br>
                                    <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($riwayat->tanggal_transaksi)->format('d/m/Y')); ?></small>
                                </div>
                                <div class="text-end">
                                    <span class="currency-display <?php echo e($riwayat->jenis_transaksi == 'setor' ? 'text-success' : 'text-danger'); ?>">
                                        <?php echo e($riwayat->jenis_transaksi == 'setor' ? '+' : '-'); ?>Rp <?php echo e(number_format($riwayat->jumlah, 0, ',', '.')); ?>

                                    </span>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-history fa-3x mb-3"></i>
                            <p class="mb-0">Belum ada transaksi</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/dashboard.blade.php ENDPATH**/ ?>