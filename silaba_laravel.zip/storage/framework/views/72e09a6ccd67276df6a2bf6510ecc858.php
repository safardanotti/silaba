<?php $__env->startSection('title', 'Manajemen User'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-user-cog me-2"></i>Manajemen User</h4>
        <a href="<?php echo e(route('admin.manajemen-user.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Tambah User
        </a>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Cari username/nama..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <select name="role" class="form-select">
                        <option value="">Semua Role</option>
                        <option value="admin" <?php echo e(request('role') == 'admin' ? 'selected' : ''); ?>>Admin</option>
                        <option value="pimpinan" <?php echo e(request('role') == 'pimpinan' ? 'selected' : ''); ?>>Pimpinan</option>
                        <option value="staff" <?php echo e(request('role') == 'staff' ? 'selected' : ''); ?>>Staff</option>
                        <option value="anggota" <?php echo e(request('role') == 'anggota' ? 'selected' : ''); ?>>Anggota</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="inactive" <?php echo e(request('status') == 'inactive' ? 'selected' : ''); ?>>Tidak Aktif</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="<?php echo e(route('admin.manajemen-user.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Username</th>
                            <th>Nama Lengkap</th>
                            <th>Role</th>
                            <th>Anggota</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($user->username); ?></strong></td>
                                <td><?php echo e($user->full_name); ?></td>
                                <td>
                                    <?php if($user->role == 'admin'): ?>
                                        <span class="badge bg-primary">Admin</span>
                                    <?php elseif($user->role == 'pimpinan'): ?>
                                        <span class="badge bg-info">Pimpinan</span>
                                    <?php elseif($user->role == 'staff'): ?>
                                        <span class="badge bg-secondary">Staff</span>
                                    <?php else: ?>
                                        <span class="badge bg-success">Anggota</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($user->anggota): ?>
                                        <a href="<?php echo e(route('admin.anggota.show', $user->anggota_id)); ?>">
                                            <?php echo e($user->anggota->no_anggota); ?>

                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($user->status == 'active'): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php elseif($user->status == 'inactive'): ?>
                                        <span class="badge bg-danger">Tidak Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-warning">Pending</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.manajemen-user.edit', $user->id)); ?>" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <form action="<?php echo e(route('admin.manajemen-user.reset-password', $user->id)); ?>" method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-info" title="Reset Password" 
                                                    onclick="return confirm('Reset password ke default (password123)?')">
                                                <i class="fas fa-key"></i>
                                            </button>
                                        </form>
                                        <?php if($user->id !== auth()->id()): ?>
                                            <button type="button" class="btn btn-danger" title="Hapus" 
                                                    onclick="confirmDelete(<?php echo e($user->id); ?>)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                    <form id="deleteForm<?php echo e($user->id); ?>" action="<?php echo e(route('admin.manajemen-user.destroy', $user->id)); ?>" 
                                          method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">
                                    Tidak ada data user
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($users->withQueryString()->links()); ?>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(id) {
    if (confirm('Apakah Anda yakin ingin menghapus user ini?')) {
        document.getElementById('deleteForm' + id).submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/manajemen-user/index.blade.php ENDPATH**/ ?>