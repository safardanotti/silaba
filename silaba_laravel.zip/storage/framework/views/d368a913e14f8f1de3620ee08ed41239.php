<?php $__env->startSection('title', 'Detail Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.pinjaman.index')); ?>">Manajemen Pinjaman</a></li>
            <li class="breadcrumb-item active"><?php echo e($pinjaman->no_pinjaman); ?></li>
        </ol>
    </nav>

    <div class="row">
        <!-- Info Pinjaman -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header bg-<?php echo e($pinjaman->status == 'aktif' ? 'warning' : ($pinjaman->status == 'lunas' ? 'success' : 'danger')); ?> text-white">
                    <h5 class="mb-0"><?php echo e($pinjaman->no_pinjaman); ?></h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-muted">Anggota</td>
                            <td>
                                <a href="<?php echo e(route('admin.anggota.show', $pinjaman->anggota_id)); ?>">
                                    <strong><?php echo e($pinjaman->anggota->nama_anggota); ?></strong>
                                </a>
                                <br><small class="text-muted"><?php echo e($pinjaman->anggota->no_anggota); ?></small>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-muted">Produk</td>
                            <td><strong><?php echo e($pinjaman->produkPinjaman->nama_produk); ?></strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Status</td>
                            <td><?php echo $pinjaman->status_label; ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tanggal Pinjaman</td>
                            <td><?php echo e(\Carbon\Carbon::parse($pinjaman->tanggal_pinjaman)->format('d/m/Y')); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Jatuh Tempo</td>
                            <td><?php echo e(\Carbon\Carbon::parse($pinjaman->tanggal_jatuh_tempo)->format('d/m/Y')); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Bunga</td>
                            <td><?php echo e($pinjaman->bunga_persen); ?>% / tahun</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tenor</td>
                            <td><?php echo e($pinjaman->tenor); ?> bulan</td>
                        </tr>
                    </table>
                    <hr>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-muted">Jumlah Pinjaman</td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($pinjaman->jumlah_pinjaman, 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Sisa Pokok</td>
                            <td class="text-end text-danger"><strong>Rp <?php echo e(number_format($pinjaman->saldo_pokok, 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Angsuran/bulan</td>
                            <td class="text-end">Rp <?php echo e(number_format($pinjaman->total_angsuran, 0, ',', '.')); ?></td>
                        </tr>
                    </table>
                    <hr>
                    <div class="progress mb-2" style="height: 25px;">
                        <div class="progress-bar bg-success" style="width: <?php echo e($pinjaman->persentase_lunas); ?>%">
                            <?php echo e($pinjaman->persentase_lunas); ?>%
                        </div>
                    </div>
                    <p class="text-center text-muted mb-0"><?php echo e($pinjaman->angsuran_ke); ?> / <?php echo e($pinjaman->tenor); ?> angsuran terbayar</p>
                </div>
            </div>
        </div>

        <!-- Jadwal Angsuran -->
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Jadwal Angsuran</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">Ke-</th>
                                    <th>Jatuh Tempo</th>
                                    <th class="text-end">Pokok</th>
                                    <th class="text-end">Bunga</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-center">Status</th>
                                    <th>Tanggal Bayar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $pinjaman->angsuran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="<?php echo e($ang->status == 'lunas' ? 'table-success' : ($ang->status == 'terlambat' ? 'table-danger' : '')); ?>">
                                        <td class="text-center"><?php echo e($ang->angsuran_ke); ?></td>
                                        <td><?php echo e(\Carbon\Carbon::parse($ang->tanggal_jatuh_tempo)->format('d/m/Y')); ?></td>
                                        <td class="text-end">Rp <?php echo e(number_format($ang->angsuran_pokok, 0, ',', '.')); ?></td>
                                        <td class="text-end">Rp <?php echo e(number_format($ang->angsuran_bunga, 0, ',', '.')); ?></td>
                                        <td class="text-end"><strong>Rp <?php echo e(number_format($ang->total_angsuran, 0, ',', '.')); ?></strong></td>
                                        <td class="text-center">
                                            <?php if($ang->status == 'lunas'): ?>
                                                <span class="badge bg-success">Lunas</span>
                                            <?php elseif($ang->status == 'terlambat'): ?>
                                                <span class="badge bg-danger">Terlambat</span>
                                            <?php elseif($ang->status == 'sebagian'): ?>
                                                <span class="badge bg-warning">Sebagian</span>
                                            <?php else: ?>
                                                <span class="badge bg-secondary">Belum Bayar</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($ang->tanggal_bayar ? \Carbon\Carbon::parse($ang->tanggal_bayar)->format('d/m/Y') : '-'); ?></td>
                                        <td>
                                            <?php if($ang->status != 'lunas' && $pinjaman->status == 'aktif'): ?>
                                                <a href="<?php echo e(route('admin.pinjaman.bayar-angsuran', [$pinjaman->id, $ang->id])); ?>" class="btn btn-sm btn-success">
                                                    <i class="fas fa-money-bill"></i> Bayar
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/pinjaman/show.blade.php ENDPATH**/ ?>