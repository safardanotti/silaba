<?php $__env->startSection('title', 'Ikhtisar Jurnal'); ?>
<?php $__env->startSection('page-title', 'Ikhtisar Jurnal'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .jurnal-table {
        font-size: 0.9rem;
    }
    .jurnal-table th {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        text-align: center;
        vertical-align: middle;
        font-weight: bold;
    }
    .jurnal-table td {
        border: 1px solid #dee2e6;
        vertical-align: middle;
    }
    .text-right {
        text-align: right !important;
    }
    .text-center {
        text-align: center !important;
    }
    .total-row {
        background-color: #e9ecef;
        font-weight: bold;
    }
    .koperasi-header {
        text-align: center;
        margin-bottom: 20px;
    }
    .koperasi-header h2 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: bold;
    }
    .koperasi-header h3 {
        margin: 5px 0;
        font-size: 1rem;
        font-weight: bold;
    }
    .periode-header {
        text-align: center;
        margin: 20px 0;
        font-weight: bold;
        font-size: 0.95rem;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
        .jurnal-table {
            font-size: 0.8rem;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Filter Section -->
<div class="card no-print mb-3">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-6">
                <form method="GET" action="" class="row g-2" id="filterForm">
                    <div class="col-md-5">
                        <label class="form-label">Bulan</label>
                        <select class="form-select" id="filterBulan" name="bulan">
                            <?php $__currentLoopData = $bulanNama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($key); ?>" <?php echo e($bulan == $key ? 'selected' : ''); ?>>
                                    <?php echo e($value); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Tahun</label>
                        <select class="form-select" id="filterTahun" name="tahun">
                            <?php for($i = 2020; $i <= date('Y') + 1; $i++): ?>
                                <option value="<?php echo e($i); ?>" <?php echo e($tahun == $i ? 'selected' : ''); ?>><?php echo e($i); ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <div class="d-flex gap-2 justify-content-end align-items-end h-100 mt-3">
                    <button class="btn btn-success" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak
                    </button>
                    <a href="<?php echo e(route('laporan.transaksi')); ?>" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Penerimaan -->
<div class="card mb-4">
    <div class="card-body">
        <div class="koperasi-header">
            <h2>KOPERASI KARYAWAN PELABUHAN</h2>
            <h2>CABANG PALEMBANG</h2>
        </div>
        
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENERIMAAN KAS</h3>
            <h3>BULAN <?php echo e($periodeName); ?></h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $penerimaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <td class="text-center"><?php echo e($row->kode_akun); ?></td>
                            <td><?php echo e($row->nama_akun); ?></td>
                            <td class="text-right">
                                <?php echo e($row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-'); ?>

                            </td>
                            <td class="text-right">
                                <?php echo e($row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi penerimaan untuk periode ini</em></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($penerimaan->isNotEmpty()): ?>
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPenerimaan['debet'], 2, ',', '.')); ?></strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPenerimaan['kredit'], 2, ',', '.')); ?></strong></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Pengeluaran -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENGELUARAN KAS</h3>
            <h3>BULAN <?php echo e($periodeName); ?></h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $pengeluaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <td class="text-center"><?php echo e($row->kode_akun); ?></td>
                            <td><?php echo e($row->nama_akun); ?></td>
                            <td class="text-right">
                                <?php echo e($row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-'); ?>

                            </td>
                            <td class="text-right">
                                <?php echo e($row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi pengeluaran untuk periode ini</em></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($pengeluaran->isNotEmpty()): ?>
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPengeluaran['debet'], 2, ',', '.')); ?></strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPengeluaran['kredit'], 2, ',', '.')); ?></strong></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Rupa-Rupa -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL RUPA-RUPA</h3>
            <h3>BULAN <?php echo e($periodeName); ?></h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $rupaRupa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <td class="text-center"><?php echo e($row->kode_akun); ?></td>
                            <td><?php echo e($row->nama_akun); ?></td>
                            <td class="text-right">
                                <?php echo e($row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-'); ?>

                            </td>
                            <td class="text-right">
                                <?php echo e($row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi rupa-rupa untuk periode ini</em></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($rupaRupa->isNotEmpty()): ?>
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsRupaRupa['debet'], 2, ',', '.')); ?></strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsRupaRupa['kredit'], 2, ',', '.')); ?></strong></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Penjualan Kredit -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENJUALAN KREDIT</h3>
            <h3>BULAN <?php echo e($periodeName); ?></h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $penjualanKredit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td class="text-center"><?php echo e($index + 1); ?></td>
                            <td class="text-center"><?php echo e($row->kode_akun); ?></td>
                            <td><?php echo e($row->nama_akun); ?></td>
                            <td class="text-right">
                                <?php echo e($row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-'); ?>

                            </td>
                            <td class="text-right">
                                <?php echo e($row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-'); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi penjualan kredit untuk periode ini</em></td>
                        </tr>
                    <?php endif; ?>
                    <?php if($penjualanKredit->isNotEmpty()): ?>
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPenjualanKredit['debet'], 2, ',', '.')); ?></strong></td>
                            <td class="text-right"><strong><?php echo e(number_format($totalsPenjualanKredit['kredit'], 2, ',', '.')); ?></strong></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('filterBulan').addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });
    document.getElementById('filterTahun').addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/ikhtisar/jurnal.blade.php ENDPATH**/ ?>