<?php $__env->startSection('title', 'Laporan Transaksi'); ?>
<?php $__env->startSection('page-title'); ?>
    <i class="fas fa-list"></i> Laporan Transaksi
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .pagination-info {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-top: 20px;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
    }
    .table td.text-end {
        font-family: 'Courier New', monospace;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('laporan.transaksi')); ?>" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="bulan" class="form-select">
                    <?php $__currentLoopData = $bulanNama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e($bulan == $key ? 'selected' : ''); ?>>
                            <?php echo e($value); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-2">
                <label class="form-label">Tahun</label>
                <select name="tahun" class="form-select">
                    <?php for($y = 2020; $y <= 2030; $y++): ?>
                        <option value="<?php echo e($y); ?>" <?php echo e($tahun == $y ? 'selected' : ''); ?>><?php echo e($y); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Jenis Transaksi</label>
                <select name="jenis" class="form-select">
                    <option value="">Semua</option>
                    <option value="penerimaan" <?php echo e($jenis == 'penerimaan' ? 'selected' : ''); ?>>Penerimaan</option>
                    <option value="pengeluaran" <?php echo e($jenis == 'pengeluaran' ? 'selected' : ''); ?>>Pengeluaran</option>
                    <option value="rupa_rupa" <?php echo e($jenis == 'rupa_rupa' ? 'selected' : ''); ?>>Rupa-rupa</option>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <a href="<?php echo e(route('laporan.transaksi')); ?>" class="btn btn-secondary">
                    <i class="fas fa-undo"></i> Reset
                </a>
            </div>
        </form>
    </div>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Daftar Transaksi</h5>
        <span class="badge bg-primary"><?php echo e($transactions->total()); ?> transaksi</span>
    </div>
    <div class="card-body">
        <!-- Export Buttons -->
        <div class="mb-3">
            <div class="row">
                <div class="col-md-8">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('export.penerimaan', ['periode' => $tahun . '-' . $bulan])); ?>" class="btn btn-success btn-sm">
                            <i class="fas fa-file-excel"></i> Export Penerimaan
                        </a>
                        <a href="<?php echo e(route('export.pengeluaran', ['periode' => $tahun . '-' . $bulan])); ?>" class="btn btn-danger btn-sm">
                            <i class="fas fa-file-excel"></i> Export Pengeluaran
                        </a>
                        <a href="<?php echo e(route('export.rupa-rupa', ['periode' => $tahun . '-' . $bulan])); ?>" class="btn btn-info btn-sm">
                            <i class="fas fa-file-excel"></i> Export Rupa-rupa
                        </a>
                    </div>
                </div>
                <div class="col-md-4 text-end">
                    <div class="btn-group" role="group">
                        <a href="<?php echo e(route('rekap.akun')); ?>" class="btn btn-primary btn-sm">
                            <i class="fas fa-calculator"></i> Rekap Per Kode Akun
                        </a>
                        <a href="<?php echo e(route('ikhtisar.jurnal')); ?>" class="btn btn-warning btn-sm">
                            <i class="fas fa-chart-bar"></i> Ikhtisar Jurnal
                        </a>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th>Uraian</th>
                        <th>Kas/Bank</th>
                        <th class="text-end">Debet (Rp)</th>
                        <th class="text-end">Kredit (Rp)</th>
                        <th>Dibuat Oleh</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $jenisLabel = [
                                'penerimaan' => '<span class="badge bg-success">Penerimaan</span>',
                                'pengeluaran' => '<span class="badge bg-danger">Pengeluaran</span>',
                                'rupa_rupa' => '<span class="badge bg-info">Rupa-rupa</span>'
                            ];
                            
                            $totalDebet = $trans->detailTransaksi->sum('debet');
                            $totalKredit = $trans->detailTransaksi->sum('kredit');
                            
                            $kasDebet = $trans->detailTransaksi->whereIn('kode_akun', ['100', '101'])->sum('debet');
                            $kasKredit = $trans->detailTransaksi->whereIn('kode_akun', ['100', '101'])->sum('kredit');
                            
                            if ($kasDebet > 0) {
                                $kasBank = '<span class="text-success currency-display">+' . number_format($kasDebet, 0, ',', '.') . '</span>';
                            } elseif ($kasKredit > 0) {
                                $kasBank = '<span class="text-danger currency-display">-' . number_format($kasKredit, 0, ',', '.') . '</span>';
                            } else {
                                $kasBank = '-';
                            }
                        ?>
                        <tr>
                            <td><?php echo e($transactions->firstItem() + $index); ?></td>
                            <td><?php echo e($trans->tanggal->format('d/m/Y')); ?></td>
                            <td><?php echo $jenisLabel[$trans->jenis_transaksi] ?? '-'; ?></td>
                            <td><?php echo e(Str::limit($trans->uraian_kegiatan, 40)); ?></td>
                            <td class="text-center"><?php echo $kasBank; ?></td>
                            <td class="text-end"><?php echo e(number_format($totalDebet, 0, ',', '.')); ?></td>
                            <td class="text-end"><?php echo e(number_format($totalKredit, 0, ',', '.')); ?></td>
                            <td><small><?php echo e($trans->user->full_name ?? '-'); ?></small></td>
                            <td>
                                <div class="btn-group btn-group-sm" role="group">
                                    <button type="button" class="btn btn-info btn-view-detail" 
                                            data-id="<?php echo e($trans->id); ?>" title="Lihat Detail">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                    <?php if(auth()->user()->role == 'admin'): ?>
                                    <a href="<?php echo e(route('transaksi.edit', $trans->id)); ?>" class="btn btn-warning" title="Edit">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-danger" onclick="confirmDelete(<?php echo e($trans->id); ?>)" title="Hapus">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Delete Form (Hidden) -->
                                <form id="deleteForm<?php echo e($trans->id); ?>" action="<?php echo e(route('transaksi.destroy', $trans->id)); ?>" method="POST" style="display: none;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center">Tidak ada transaksi</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
        
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($transactions->withQueryString()->links()); ?>

        </div>
    </div>
</div>

<!-- Single Detail Modal -->
<div class="modal fade" id="detailModal" tabindex="-1" aria-labelledby="detailModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="detailModalLabel">Detail Transaksi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="detailModalBody">
                <div class="text-center py-4">
                    <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                    </div>
                    <p class="mt-2">Memuat data...</p>
                </div>
            </div>
            <div class="modal-footer" id="detailModalFooter">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Data transaksi untuk modal (dari controller)
const transactionsData = <?php echo json_encode($transactionsJson, 15, 512) ?>;
const isAdmin = <?php echo e(auth()->user()->role == 'admin' ? 'true' : 'false'); ?>;

function formatRupiah(num) {
    return new Intl.NumberFormat('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    }).format(num);
}

function getJenisLabel(jenis) {
    const labels = {
        'penerimaan': '<span class="badge bg-success">Penerimaan</span>',
        'pengeluaran': '<span class="badge bg-danger">Pengeluaran</span>',
        'rupa_rupa': '<span class="badge bg-info">Rupa-rupa</span>'
    };
    return labels[jenis] || '-';
}

function showDetail(id) {
    const trans = transactionsData.find(t => t.id === id);
    if (!trans) return;
    
    let detailRows = '';
    trans.details.forEach(detail => {
        detailRows += `
            <tr>
                <td>${detail.kode_akun}</td>
                <td>${detail.nama_akun}</td>
                <td class="text-end" style="font-family: 'Courier New', monospace;">Rp ${formatRupiah(detail.debet)}</td>
                <td class="text-end" style="font-family: 'Courier New', monospace;">Rp ${formatRupiah(detail.kredit)}</td>
            </tr>
        `;
    });
    
    const bodyHtml = `
        <div class="row mb-3">
            <div class="col-md-6">
                <strong>Tanggal:</strong> ${trans.tanggal}<br>
                <strong>Jenis:</strong> ${getJenisLabel(trans.jenis_transaksi)}<br>
                <strong>Jenis Masuk:</strong> ${trans.jenis_masuk}
            </div>
            <div class="col-md-6">
                <strong>Uraian:</strong> ${trans.uraian_kegiatan}<br>
                <strong>Dibuat:</strong> ${trans.created_by}<br>
                <strong>Waktu:</strong> ${trans.created_at}
            </div>
        </div>
        <hr>
        <h6>Detail Jurnal</h6>
        <table class="table table-sm">
            <thead>
                <tr>
                    <th>Kode</th>
                    <th>Nama Akun</th>
                    <th class="text-end">Debet (Rp)</th>
                    <th class="text-end">Kredit (Rp)</th>
                </tr>
            </thead>
            <tbody>
                ${detailRows}
            </tbody>
            <tfoot>
                <tr class="table-light">
                    <th colspan="2">TOTAL</th>
                    <th class="text-end" style="font-family: 'Courier New', monospace;">Rp ${formatRupiah(trans.total_debet)}</th>
                    <th class="text-end" style="font-family: 'Courier New', monospace;">Rp ${formatRupiah(trans.total_kredit)}</th>
                </tr>
            </tfoot>
        </table>
    `;
    
    document.getElementById('detailModalLabel').textContent = `Detail Transaksi #${trans.id}`;
    document.getElementById('detailModalBody').innerHTML = bodyHtml;
    
    // Update footer with edit button if admin
    let footerHtml = '';
    if (isAdmin) {
        footerHtml += `<a href="/transaksi/${trans.id}/edit" class="btn btn-warning"><i class="fas fa-edit"></i> Edit</a>`;
    }
    footerHtml += '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>';
    document.getElementById('detailModalFooter').innerHTML = footerHtml;
}

function confirmDelete(id) {
    if (confirm('Apakah Anda yakin ingin menghapus transaksi ini?')) {
        document.getElementById('deleteForm' + id).submit();
    }
}

// Event listener untuk tombol view detail
document.addEventListener('DOMContentLoaded', function() {
    const detailModal = new bootstrap.Modal(document.getElementById('detailModal'));
    
    document.querySelectorAll('.btn-view-detail').forEach(btn => {
        btn.addEventListener('click', function() {
            const id = parseInt(this.dataset.id);
            showDetail(id);
            detailModal.show();
        });
    });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/laporan/transaksi.blade.php ENDPATH**/ ?>