<?php $__env->startSection('title', 'Detail Pengajuan'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('anggota.pengajuan.index')); ?>">Pengajuan Pinjaman</a></li>
            <li class="breadcrumb-item active"><?php echo e($pengajuan->no_pengajuan); ?></li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h5 class="mb-0"><?php echo e($pengajuan->no_pengajuan); ?></h5>
                        <?php echo $pengajuan->status_label; ?>

                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <small class="text-muted">Tanggal Pengajuan</small>
                            <p class="mb-0"><strong><?php echo e($pengajuan->created_at->format('d/m/Y H:i')); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted">Produk Pinjaman</small>
                            <p class="mb-0"><strong><?php echo e($pengajuan->produkPinjaman->nama_produk); ?></strong></p>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <small class="text-muted">Jumlah Pinjaman</small>
                            <p class="mb-0 currency-display fs-4 text-primary"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman, 0, ',', '.')); ?></strong></p>
                        </div>
                        <div class="col-md-6">
                            <small class="text-muted">Jangka Waktu</small>
                            <p class="mb-0"><strong><?php echo e($pengajuan->tenor); ?> bulan</strong></p>
                        </div>
                    </div>
                    <div class="mb-3">
                        <small class="text-muted">Keperluan</small>
                        <p class="mb-0"><?php echo e($pengajuan->keperluan); ?></p>
                    </div>

                    <?php if($pengajuan->catatan_approval): ?>
                        <div class="alert alert-<?php echo e($pengajuan->status == 'ditolak' ? 'danger' : 'info'); ?>">
                            <strong>Catatan:</strong> <?php echo e($pengajuan->catatan_approval); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Dokumen -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-file me-2"></i>Dokumen Persyaratan</h6>
                </div>
                <div class="card-body">
                    <div class="row">
                        <?php if($pengajuan->dok_ktp): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-2 text-center">
                                    <i class="fas fa-id-card fa-2x mb-2 text-muted"></i>
                                    <p class="mb-0 small">KTP</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_ktp)); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2">Lihat</a>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($pengajuan->dok_kk): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-2 text-center">
                                    <i class="fas fa-users fa-2x mb-2 text-muted"></i>
                                    <p class="mb-0 small">Kartu Keluarga</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_kk)); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2">Lihat</a>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($pengajuan->dok_slip_gaji): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-2 text-center">
                                    <i class="fas fa-file-invoice-dollar fa-2x mb-2 text-muted"></i>
                                    <p class="mb-0 small">Slip Gaji</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_slip_gaji)); ?>" target="_blank" class="btn btn-sm btn-outline-primary mt-2">Lihat</a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Simulasi -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Simulasi Angsuran</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <td>Jumlah Pinjaman</td>
                            <td class="text-end currency-display"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman, 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Bunga/tahun</td>
                            <td class="text-end"><?php echo e($pengajuan->produkPinjaman->bunga_persen); ?>%</td>
                        </tr>
                        <tr>
                            <td>Tenor</td>
                            <td class="text-end"><?php echo e($pengajuan->tenor); ?> bulan</td>
                        </tr>
                        <tr class="table-light">
                            <td colspan="2"><strong>Perhitungan</strong></td>
                        </tr>
                        <tr>
                            <td>Angsuran Pokok/bln</td>
                            <td class="text-end currency-display">Rp <?php echo e(number_format($simulasi['angsuran_pokok'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <td>Angsuran Bunga/bln</td>
                            <td class="text-end currency-display">Rp <?php echo e(number_format($simulasi['angsuran_bunga'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr class="table-success">
                            <td><strong>Total Angsuran/bln</strong></td>
                            <td class="text-end currency-display fs-5"><strong>Rp <?php echo e(number_format($simulasi['total_angsuran'], 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Total Bunga</td>
                            <td class="text-end currency-display">Rp <?php echo e(number_format($simulasi['total_bunga'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <td>Total Bayar</td>
                            <td class="text-end currency-display"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman + $simulasi['total_bunga'], 0, ',', '.')); ?></strong></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Status Timeline -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="mb-0"><i class="fas fa-history me-2"></i>Status Pengajuan</h6>
                </div>
                <div class="card-body">
                    <div class="timeline">
                        <div class="timeline-item <?php echo e(in_array($pengajuan->status, ['pending', 'diproses', 'disetujui', 'ditolak', 'dicairkan']) ? 'active' : ''); ?>">
                            <div class="timeline-marker bg-primary"></div>
                            <div class="timeline-content">
                                <p class="mb-0"><strong>Pengajuan Dibuat</strong></p>
                                <small class="text-muted"><?php echo e($pengajuan->created_at->format('d/m/Y H:i')); ?></small>
                            </div>
                        </div>
                        <div class="timeline-item <?php echo e(in_array($pengajuan->status, ['diproses', 'disetujui', 'ditolak', 'dicairkan']) ? 'active' : ''); ?>">
                            <div class="timeline-marker <?php echo e(in_array($pengajuan->status, ['diproses', 'disetujui', 'ditolak', 'dicairkan']) ? 'bg-primary' : 'bg-secondary'); ?>"></div>
                            <div class="timeline-content">
                                <p class="mb-0"><strong>Sedang Diproses</strong></p>
                            </div>
                        </div>
                        <?php if($pengajuan->status == 'ditolak'): ?>
                            <div class="timeline-item active">
                                <div class="timeline-marker bg-danger"></div>
                                <div class="timeline-content">
                                    <p class="mb-0"><strong>Ditolak</strong></p>
                                    <?php if($pengajuan->approved_at): ?>
                                        <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($pengajuan->approved_at)->format('d/m/Y H:i')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php else: ?>
                            <div class="timeline-item <?php echo e(in_array($pengajuan->status, ['disetujui', 'dicairkan']) ? 'active' : ''); ?>">
                                <div class="timeline-marker <?php echo e(in_array($pengajuan->status, ['disetujui', 'dicairkan']) ? 'bg-success' : 'bg-secondary'); ?>"></div>
                                <div class="timeline-content">
                                    <p class="mb-0"><strong>Disetujui</strong></p>
                                    <?php if($pengajuan->approved_at && $pengajuan->status != 'ditolak'): ?>
                                        <small class="text-muted"><?php echo e(\Carbon\Carbon::parse($pengajuan->approved_at)->format('d/m/Y H:i')); ?></small>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="timeline-item <?php echo e($pengajuan->status == 'dicairkan' ? 'active' : ''); ?>">
                                <div class="timeline-marker <?php echo e($pengajuan->status == 'dicairkan' ? 'bg-success' : 'bg-secondary'); ?>"></div>
                                <div class="timeline-content">
                                    <p class="mb-0"><strong>Dicairkan</strong></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('styles'); ?>
<style>
.timeline {
    position: relative;
    padding-left: 30px;
}
.timeline-item {
    position: relative;
    padding-bottom: 20px;
    padding-left: 20px;
    border-left: 2px solid #dee2e6;
}
.timeline-item:last-child {
    border-left: 2px solid transparent;
}
.timeline-item.active {
    border-left-color: #0d6efd;
}
.timeline-marker {
    position: absolute;
    left: -8px;
    width: 14px;
    height: 14px;
    border-radius: 50%;
    background: #dee2e6;
}
</style>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/pengajuan/show.blade.php ENDPATH**/ ?>