<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; }
        th { background-color: #f0f0f0; font-weight: bold; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; }
        .section-header { font-weight: bold; text-decoration: underline; }
        .sub-total { font-weight: bold; border-top: 1px solid #000; }
        .grand-total { font-weight: bold; background-color: #e0e0e0; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="6" class="header">KOPERASI KARYAWAN PELABUHAN</td>
        </tr>
        <tr>
            <td colspan="6" class="header">CABANG PALEMBANG</td>
        </tr>
        <tr>
            <td colspan="6" class="header">NERACA</td>
        </tr>
        <tr>
            <td colspan="6" class="header">PER <?php echo e(strtoupper($periodeName)); ?> <?php echo e($tahun); ?></td>
        </tr>
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        <tr>
            <th colspan="3">AKTIVA</th>
            <th colspan="3">PASSIVA</th>
        </tr>
        <tr>
            <th width="10%">NO<br>REK</th>
            <th width="30%">URAIAN</th>
            <th width="15%">JUMLAH</th>
            <th width="10%">NO<br>REK</th>
            <th width="30%">URAIAN</th>
            <th width="15%">JUMLAH</th>
        </tr>
        
        <!-- AKTIVA LANCAR & HUTANG -->
        <tr>
            <td colspan="3" class="section-header">AKTIVA LANCAR :</td>
            <td colspan="3" class="section-header">HUTANG :</td>
        </tr>
        
        <?php
            $maxRows = max(count($aktiva['lancar']), count($passiva['hutang']));
        ?>
        
        <?php for($i = 0; $i < $maxRows; $i++): ?>
        <tr>
            <?php if(isset($aktiva['lancar'][$i])): ?>
                <td class="text-center"><?php echo e($aktiva['lancar'][$i]['kode']); ?></td>
                <td><?php echo e($aktiva['lancar'][$i]['nama']); ?></td>
                <td class="text-right"><?php echo e(number_format($aktiva['lancar'][$i]['jumlah'], 2, ',', '.')); ?></td>
            <?php else: ?>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            <?php endif; ?>
            
            <?php if(isset($passiva['hutang'][$i])): ?>
                <td class="text-center"><?php echo e($passiva['hutang'][$i]['kode']); ?></td>
                <td><?php echo e($passiva['hutang'][$i]['nama']); ?></td>
                <td class="text-right"><?php echo e(number_format($passiva['hutang'][$i]['jumlah'], 2, ',', '.')); ?></td>
            <?php else: ?>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            <?php endif; ?>
        </tr>
        <?php endfor; ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalAktivaLancar, 2, ',', '.')); ?></td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalHutang, 2, ',', '.')); ?></td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- AKTIVA TETAP & DANA-DANA -->
        <tr>
            <td colspan="3" class="section-header">AKTIVA TETAP :</td>
            <td colspan="3" class="section-header">DANA - DANA :</td>
        </tr>
        
        <?php
            $maxRows = max(count($aktiva['tetap']), count($passiva['dana']));
        ?>
        
        <?php for($i = 0; $i < $maxRows; $i++): ?>
        <tr>
            <?php if(isset($aktiva['tetap'][$i])): ?>
                <td class="text-center"><?php echo e($aktiva['tetap'][$i]['kode']); ?></td>
                <td><?php echo e($aktiva['tetap'][$i]['nama']); ?></td>
                <td class="text-right">
                    <?php if($aktiva['tetap'][$i]['is_negative'] ?? false): ?>
                        (<?php echo e(number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.')); ?>)
                    <?php else: ?>
                        <?php echo e(number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.')); ?>

                    <?php endif; ?>
                </td>
            <?php else: ?>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            <?php endif; ?>
            
            <?php if(isset($passiva['dana'][$i])): ?>
                <td class="text-center"><?php echo e($passiva['dana'][$i]['kode']); ?></td>
                <td><?php echo e($passiva['dana'][$i]['nama']); ?></td>
                <td class="text-right"><?php echo e(number_format($passiva['dana'][$i]['jumlah'], 2, ',', '.')); ?></td>
            <?php else: ?>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            <?php endif; ?>
        </tr>
        <?php endfor; ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalAktivaTetap, 2, ',', '.')); ?></td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalDana, 2, ',', '.')); ?></td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- MODAL -->
        <tr>
            <td colspan="3">&nbsp;</td>
            <td colspan="3" class="section-header">MODAL :</td>
        </tr>
        
        <?php $__currentLoopData = $passiva['modal']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="text-center"><?php echo e($item['kode']); ?></td>
            <td><?php echo e($item['nama']); ?></td>
            <td class="text-right"><?php echo e(number_format($item['jumlah'], 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="3">&nbsp;</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalModal, 2, ',', '.')); ?></td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- SISA HASIL USAHA -->
        <tr>
            <td colspan="3">&nbsp;</td>
            <td colspan="3" class="section-header">SISA HASIL USAHA :</td>
        </tr>
        
        <?php $__currentLoopData = $passiva['shu']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="text-center"><?php echo e($item['kode']); ?></td>
            <td><?php echo e($item['nama']); ?></td>
            <td class="text-right"><?php echo e(number_format($item['jumlah'], 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="3">&nbsp;</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right"><?php echo e(number_format($totalSHU, 2, ',', '.')); ?></td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- GRAND TOTAL -->
        <tr class="grand-total">
            <td colspan="2" class="text-center">JUMLAH AKTIVA</td>
            <td class="text-right"><?php echo e(number_format($totalAktiva, 2, ',', '.')); ?></td>
            <td colspan="2" class="text-center">JUMLAH PASSIVA</td>
            <td class="text-right"><?php echo e(number_format($totalPassiva, 2, ',', '.')); ?></td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/export/neraca.blade.php ENDPATH**/ ?>