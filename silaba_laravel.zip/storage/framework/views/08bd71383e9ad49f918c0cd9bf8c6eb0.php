<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; font-size: 10pt; }
        th { background-color: #f0f0f0; font-weight: bold; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; font-size: 12pt; }
        .total-row { font-weight: bold; background-color: #e9ecef; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="8" class="header">KOPERASI KARYAWAN PELABUHAN</td>
        </tr>
        <tr>
            <td colspan="8" class="header">CABANG PALEMBANG</td>
        </tr>
        <tr>
            <td colspan="8" class="header">NERACA MUTASI</td>
        </tr>
        <tr>
            <td colspan="8" class="header">PER <?php echo e(strtoupper($periodeName)); ?> <?php echo e($tahun); ?></td>
        </tr>
        <tr>
            <td colspan="8">&nbsp;</td>
        </tr>
        <tr>
            <th rowspan="2">KODE REK</th>
            <th rowspan="2">URAIAN</th>
            <th colspan="2">SALDO AWAL</th>
            <th colspan="2">MUTASI</th>
            <th colspan="2">SALDO AKHIR</th>
        </tr>
        <tr>
            <th>DEBET</th>
            <th>KREDIT</th>
            <th>DEBET</th>
            <th>KREDIT</th>
            <th>DEBET</th>
            <th>KREDIT</th>
        </tr>
        
        <?php $__currentLoopData = $neracaMutasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($row['kode_akun']); ?></td>
            <td><?php echo e($row['nama_akun']); ?></td>
            <td class="text-right">
                <?php echo e($row['saldo_awal_debet'] > 0 ? number_format($row['saldo_awal_debet'], 2, ',', '.') : ''); ?>

            </td>
            <td class="text-right">
                <?php echo e($row['saldo_awal_kredit'] > 0 ? number_format($row['saldo_awal_kredit'], 2, ',', '.') : ''); ?>

            </td>
            <td class="text-right">
                <?php echo e($row['mutasi_debet'] > 0 ? number_format($row['mutasi_debet'], 2, ',', '.') : ''); ?>

            </td>
            <td class="text-right">
                <?php echo e($row['mutasi_kredit'] > 0 ? number_format($row['mutasi_kredit'], 2, ',', '.') : ''); ?>

            </td>
            <td class="text-right">
                <?php echo e($row['saldo_akhir_debet'] > 0 ? number_format($row['saldo_akhir_debet'], 2, ',', '.') : ''); ?>

            </td>
            <td class="text-right">
                <?php echo e($row['saldo_akhir_kredit'] > 0 ? number_format($row['saldo_akhir_kredit'], 2, ',', '.') : ''); ?>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">TOTAL</td>
            <td class="text-right"><?php echo e(number_format($totals['saldo_awal_debet'] ?? 0, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($totals['saldo_awal_kredit'] ?? 0, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($totals['mutasi_debet'] ?? 0, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($totals['mutasi_kredit'] ?? 0, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($totals['saldo_akhir_debet'] ?? 0, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($totals['saldo_akhir_kredit'] ?? 0, 2, ',', '.')); ?></td>
        </tr>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/export/neraca-mutasi.blade.php ENDPATH**/ ?>