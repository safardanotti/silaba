<?php $__env->startSection('title', 'Manajemen Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-hand-holding-usd me-2"></i>Manajemen Pinjaman</h4>
        <a href="<?php echo e(route('admin.pinjaman.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Buat Pinjaman Baru
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h6>Total Pinjaman Disalurkan</h6>
                    <h4 class="mb-0">Rp <?php echo e(number_format($summary['total_pinjaman'], 0, ',', '.')); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6>Total Sisa Piutang</h6>
                    <h4 class="mb-0">Rp <?php echo e(number_format($summary['total_saldo'], 0, ',', '.')); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6>Pinjaman Aktif</h6>
                    <h4 class="mb-0"><?php echo e($summary['jumlah_aktif']); ?> pinjaman</h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h6>Pinjaman Lunas</h6>
                    <h4 class="mb-0"><?php echo e($summary['jumlah_lunas']); ?> pinjaman</h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari no pinjaman / nama anggota..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="lunas" <?php echo e(request('status') == 'lunas' ? 'selected' : ''); ?>>Lunas</option>
                        <option value="macet" <?php echo e(request('status') == 'macet' ? 'selected' : ''); ?>>Macet</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="<?php echo e(route('admin.pinjaman.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pinjaman</th>
                            <th>Anggota</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-end">Sisa Pokok</th>
                            <th class="text-center">Progress</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($p->no_pinjaman); ?></strong></td>
                                <td>
                                    <?php echo e($p->anggota->nama_anggota); ?>

                                    <br><small class="text-muted"><?php echo e($p->anggota->no_anggota); ?></small>
                                </td>
                                <td><?php echo e($p->produkPinjaman->nama_produk); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format($p->jumlah_pinjaman, 0, ',', '.')); ?></td>
                                <td class="text-end text-danger">Rp <?php echo e(number_format($p->saldo_pokok, 0, ',', '.')); ?></td>
                                <td class="text-center">
                                    <div class="progress" style="height: 20px; width: 100px;">
                                        <div class="progress-bar bg-success" style="width: <?php echo e($p->persentase_lunas); ?>%">
                                            <?php echo e($p->persentase_lunas); ?>%
                                        </div>
                                    </div>
                                    <small><?php echo e($p->angsuran_ke); ?>/<?php echo e($p->tenor); ?></small>
                                </td>
                                <td class="text-center"><?php echo $p->status_label; ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.pinjaman.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada data pinjaman
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($pinjaman->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/pinjaman/index.blade.php ENDPATH**/ ?>