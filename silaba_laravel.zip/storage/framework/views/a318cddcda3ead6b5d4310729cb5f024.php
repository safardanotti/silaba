<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> SIKOPKAR</h3>
    </div>
    <ul class="sidebar-menu">
        <li>
            <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo e(request()->routeIs('dashboard') ? 'active' : ''); ?>">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        <?php if(auth()->user()->isAdmin()): ?>
        <!-- Menu Koperasi -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>KOPERASI</span>
        </li>
        <li>
            <a href="<?php echo e(route('admin.anggota.index')); ?>" class="<?php echo e(request()->routeIs('admin.anggota.*') ? 'active' : ''); ?>">
                <i class="fas fa-users"></i>
                <span>Manajemen Anggota</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pinjaman.index')); ?>" class="<?php echo e(request()->routeIs('admin.pinjaman.*') && !request()->routeIs('admin.pinjaman.pengajuan*') ? 'active' : ''); ?>">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Pinjaman</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.pinjaman.pengajuan')); ?>" class="<?php echo e(request()->routeIs('admin.pinjaman.pengajuan*') ? 'active' : ''); ?>">
                <i class="fas fa-file-alt"></i>
                <span>Pengajuan Pinjaman</span>
                <?php
                    $pendingCount = \App\Models\PengajuanPinjaman::pending()->count();
                ?>
                <?php if($pendingCount > 0): ?>
                    <span class="badge bg-danger ms-auto"><?php echo e($pendingCount); ?></span>
                <?php endif; ?>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('admin.manajemen-user.index')); ?>" class="<?php echo e(request()->routeIs('admin.manajemen-user.*') ? 'active' : ''); ?>">
                <i class="fas fa-user-cog"></i>
                <span>Manajemen User</span>
            </a>
        </li>
        
        <!-- Menu Akuntansi -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>AKUNTANSI</span>
        </li>
        <li>
            <a href="<?php echo e(route('transaksi.penerimaan')); ?>" class="<?php echo e(request()->routeIs('transaksi.penerimaan*') ? 'active' : ''); ?>">
                <i class="fas fa-download"></i>
                <span>Penerimaan</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('transaksi.pengeluaran')); ?>" class="<?php echo e(request()->routeIs('transaksi.pengeluaran*') ? 'active' : ''); ?>">
                <i class="fas fa-upload"></i>
                <span>Pengeluaran</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('transaksi.rupa-rupa')); ?>" class="<?php echo e(request()->routeIs('transaksi.rupa-rupa*') ? 'active' : ''); ?>">
                <i class="fas fa-exchange-alt"></i>
                <span>Rupa-rupa</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('saldo-awal.index')); ?>" class="<?php echo e(request()->routeIs('saldo-awal*') ? 'active' : ''); ?>">
                <i class="fas fa-wallet"></i>
                <span>Saldo Awal</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('kas-bank.index')); ?>" class="<?php echo e(request()->routeIs('kas-bank*') ? 'active' : ''); ?>">
                <i class="fas fa-money-bill-wave"></i>
                <span>Kas & Bank</span>
            </a>
        </li>
        <?php endif; ?>
        
        <!-- Menu Laporan -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>LAPORAN</span>
        </li>
        <li>
            <a href="<?php echo e(route('laporan.transaksi')); ?>" class="<?php echo e(request()->routeIs('laporan.transaksi*') ? 'active' : ''); ?>">
                <i class="fas fa-list"></i>
                <span>Laporan Transaksi</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('rekap.akun')); ?>" class="<?php echo e(request()->routeIs('rekap*') ? 'active' : ''); ?>">
                <i class="fas fa-calculator"></i>
                <span>Rekap Per Akun</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('ikhtisar.jurnal')); ?>" class="<?php echo e(request()->routeIs('ikhtisar*') ? 'active' : ''); ?>">
                <i class="fas fa-chart-bar"></i>
                <span>Ikhtisar Jurnal</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('neraca.index')); ?>" class="<?php echo e(request()->routeIs('neraca.index') ? 'active' : ''); ?>">
                <i class="fas fa-balance-scale"></i>
                <span>Neraca</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('neraca.mutasi')); ?>" class="<?php echo e(request()->routeIs('neraca.mutasi') ? 'active' : ''); ?>">
                <i class="fas fa-sync-alt"></i>
                <span>Neraca Mutasi</span>
            </a>
        </li>
        <?php if(auth()->user()->isAdmin() || auth()->user()->isPimpinan()): ?>
        <li>
            <a href="<?php echo e(route('neraca.review')); ?>" class="<?php echo e(request()->routeIs('neraca.review*') ? 'active' : ''); ?>">
                <i class="fas fa-clipboard-check"></i>
                <span>Review Neraca</span>
            </a>
        </li>
        <?php endif; ?>
        <li>
            <a href="<?php echo e(route('laba-rugi.index')); ?>" class="<?php echo e(request()->routeIs('laba-rugi*') ? 'active' : ''); ?>">
                <i class="fas fa-chart-line"></i>
                <span>Laba Rugi</span>
            </a>
        </li>
        <li>
            <a href="<?php echo e(route('piutang.index')); ?>" class="<?php echo e(request()->routeIs('piutang*') ? 'active' : ''); ?>">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Piutang</span>
            </a>
        </li>
        
        <!-- Logout -->
        <li style="margin-top: 20px;">
            <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo csrf_field(); ?>
            </form>
        </li>
    </ul>
</div>
<?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>