<?php $__env->startSection('title', 'Edit Transaksi'); ?>
<?php $__env->startSection('page-title'); ?>
    <i class="fas fa-edit"></i> Edit Transaksi
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .table-container {
        overflow-x: auto;
    }
    .currency {
        text-align: right;
    }
    #balanceWarning {
        display: none;
    }
    #balanceWarning.show {
        display: block;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('transaksi.update', $transaksi->id)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <input type="hidden" id="jenis_transaksi" value="<?php echo e($transaksi->jenis_transaksi); ?>">
    
    <div class="card">
        <div class="card-header">
            <h3>Form Edit Transaksi 
                <?php
                    $jenisLabel = [
                        'penerimaan' => '<span class="badge bg-success">Penerimaan</span>',
                        'pengeluaran' => '<span class="badge bg-danger">Pengeluaran</span>',
                        'rupa_rupa' => '<span class="badge bg-info">Rupa-rupa</span>'
                    ];
                ?>
                <?php echo $jenisLabel[$transaksi->jenis_transaksi] ?? ''; ?>

            </h3>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Tanggal Transaksi *</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" 
                               value="<?php echo e(old('tanggal', $transaksi->tanggal->format('Y-m-d'))); ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Uraian Kegiatan *</label>
                        <input type="text" class="form-control" id="uraian_kegiatan" name="uraian_kegiatan" 
                               value="<?php echo e(old('uraian_kegiatan', $transaksi->uraian_kegiatan)); ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Jenis Masuk *</label>
                        <select class="form-select" id="jenis_masuk" name="jenis_masuk" required>
                            <option value="kas" <?php echo e(old('jenis_masuk', $transaksi->jenis_masuk) == 'kas' ? 'selected' : ''); ?>>KAS</option>
                            <option value="bank" <?php echo e(old('jenis_masuk', $transaksi->jenis_masuk) == 'bank' ? 'selected' : ''); ?>>BANK</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>Detail Jurnal Transaksi</h4>
                <button type="button" class="btn btn-primary btn-sm" onclick="addTransactionRow()">
                    <i class="fas fa-plus"></i> Tambah Baris
                </button>
            </div>
            
            <div class="alert alert-warning mb-3" id="balanceWarning">
                <i class="fas fa-exclamation-triangle"></i> Perhatian: Total Debet dan Kredit harus balance!
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">NO</th>
                            <th width="200">KODE AKUN</th>
                            <th>NAMA AKUN</th>
                            <th width="100">JENIS MASUK</th>
                            <th width="120">TANGGAL</th>
                            <th width="150">DEBET</th>
                            <th width="150">KREDIT</th>
                            <th width="50">AKSI</th>
                        </tr>
                    </thead>
                    <tbody id="transactionDetails">
                        <?php $__currentLoopData = $transaksi->detailTransaksi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($index + 1); ?></td>
                            <td>
                                <select name="kode_akun[]" class="form-select" required onchange="updateAccountName(this)">
                                    <option value="">Pilih Kode Akun</option>
                                    <?php $__currentLoopData = $kodeAkun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($akun->kode_akun); ?>" 
                                            data-nama="<?php echo e($akun->nama_akun); ?>"
                                            <?php echo e($detail->kode_akun == $akun->kode_akun ? 'selected' : ''); ?>>
                                        <?php echo e($akun->kode_akun); ?> - <?php echo e($akun->nama_akun); ?>

                                    </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </td>
                            <td class="nama-akun">
                                <?php $__currentLoopData = $kodeAkun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $akun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($akun->kode_akun == $detail->kode_akun): ?>
                                        <?php echo e($akun->nama_akun); ?>

                                        <?php break; ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td class="jenis-masuk"><?php echo e(strtoupper($transaksi->jenis_masuk)); ?></td>
                            <td><?php echo e($transaksi->tanggal->format('Y-m-d')); ?></td>
                            <td><input type="text" name="debet[]" class="form-control currency" value="<?php echo e(number_format($detail->debet, 2, ',', '.')); ?>"></td>
                            <td><input type="text" name="kredit[]" class="form-control currency" value="<?php echo e(number_format($detail->kredit, 2, ',', '.')); ?>"></td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-end"><strong>TOTAL:</strong></td>
                            <td><strong>RP <span id="totalDebet">0</span></strong></td>
                            <td><strong>RP <span id="totalKredit">0</span></strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-end"><strong>SELISIH:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong>RP <span id="selisih">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Transaksi
                </button>
                <a href="<?php echo e(route('laporan.transaksi')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Kode akun data untuk JavaScript
const kodeAkunData = <?php echo json_encode($kodeAkun, 15, 512) ?>;

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value.replace(/[^0-9,]/g, '');
    if (value) {
        const parts = value.split(',');
        if (parts.length > 2) {
            value = parts[0] + ',' + parts.slice(1).join('');
        }
        if (parts[0]) {
            parts[0] = parseInt(parts[0]).toLocaleString('id-ID');
            value = parts.join(',');
        }
        input.value = value;
    }
}

// Parse currency to number
function parseCurrency(str) {
    if (!str) return 0;
    let value = str.toString().replace(/\./g, '');
    value = value.replace(',', '.');
    return parseFloat(value) || 0;
}

// Format number for display
function formatNumber(num) {
    if (typeof num === 'string') {
        num = parseFloat(num);
    }
    return new Intl.NumberFormat('id-ID', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(num);
}

// Update account name when kode akun changes
function updateAccountName(select) {
    const row = select.closest('tr');
    const namaAkunCell = row.querySelector('.nama-akun');
    const selectedOption = select.options[select.selectedIndex];
    namaAkunCell.textContent = selectedOption.dataset.nama || '-';
    calculateTotal();
}

// Add new transaction row
function addTransactionRow() {
    const tbody = document.getElementById('transactionDetails');
    const rowCount = tbody.rows.length + 1;
    
    let optionsHtml = '<option value="">Pilih Kode Akun</option>';
    kodeAkunData.forEach(akun => {
        optionsHtml += `<option value="${akun.kode_akun}" data-nama="${akun.nama_akun}">${akun.kode_akun} - ${akun.nama_akun}</option>`;
    });
    
    const row = tbody.insertRow();
    row.innerHTML = `
        <td>${rowCount}</td>
        <td>
            <select name="kode_akun[]" class="form-select" required onchange="updateAccountName(this)">
                ${optionsHtml}
            </select>
        </td>
        <td class="nama-akun">-</td>
        <td class="jenis-masuk">${document.getElementById('jenis_masuk').value.toUpperCase()}</td>
        <td>${document.getElementById('tanggal').value}</td>
        <td><input type="text" name="debet[]" class="form-control currency" value="0,00"></td>
        <td><input type="text" name="kredit[]" class="form-control currency" value="0,00"></td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    initCurrencyInputs();
    updateRowNumbers();
}

// Remove row
function removeRow(btn) {
    const row = btn.closest('tr');
    const tbody = row.parentNode;
    
    if (tbody.rows.length > 1) {
        row.remove();
        updateRowNumbers();
        calculateTotal();
    } else {
        alert('Minimal harus ada 1 baris detail!');
    }
}

// Update row numbers
function updateRowNumbers() {
    const tbody = document.getElementById('transactionDetails');
    const rows = tbody.rows;
    for (let i = 0; i < rows.length; i++) {
        rows[i].cells[0].textContent = i + 1;
    }
}

// Calculate totals
function calculateTotal() {
    let totalDebet = 0;
    let totalKredit = 0;
    
    document.querySelectorAll('input[name="debet[]"]').forEach(input => {
        totalDebet += parseCurrency(input.value);
    });
    
    document.querySelectorAll('input[name="kredit[]"]').forEach(input => {
        totalKredit += parseCurrency(input.value);
    });
    
    document.getElementById('totalDebet').textContent = formatNumber(totalDebet);
    document.getElementById('totalKredit').textContent = formatNumber(totalKredit);
    
    const selisih = Math.abs(totalDebet - totalKredit);
    const selisihElement = document.getElementById('selisih');
    selisihElement.textContent = formatNumber(selisih);
    
    // Show/hide balance warning
    const warningElement = document.getElementById('balanceWarning');
    if (selisih > 0.01) {
        warningElement.classList.add('show');
        selisihElement.style.color = '#dc3545';
    } else {
        warningElement.classList.remove('show');
        selisihElement.style.color = '#28a745';
    }
}

// Initialize currency inputs
function initCurrencyInputs() {
    document.querySelectorAll('input.currency').forEach(input => {
        input.addEventListener('input', function() {
            formatCurrencyInput(this);
            calculateTotal();
        });
        
        input.addEventListener('blur', function() {
            if (this.value === '') {
                this.value = '0,00';
            }
            formatCurrencyInput(this);
            calculateTotal();
        });
        
        input.addEventListener('focus', function() {
            this.select();
        });
    });
}

// Update jenis masuk display when changed
document.getElementById('jenis_masuk').addEventListener('change', function() {
    document.querySelectorAll('.jenis-masuk').forEach(td => {
        td.textContent = this.value.toUpperCase();
    });
});

// Initialize on load
document.addEventListener('DOMContentLoaded', function() {
    initCurrencyInputs();
    calculateTotal();
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/transaksi/edit.blade.php ENDPATH**/ ?>