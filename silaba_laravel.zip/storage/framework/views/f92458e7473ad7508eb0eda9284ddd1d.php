<?php $__env->startSection('title', 'Simpanan Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-4"><i class="fas fa-piggy-bank me-2"></i>Simpanan Saya</h4>

    <!-- Saldo Simpanan -->
    <div class="row mb-4">
        <?php $__empty_1 = true; $__currentLoopData = $saldoSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saldo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-md-4 mb-3">
                <div class="card border-success h-100">
                    <div class="card-body">
                        <h6 class="text-muted"><?php echo e($saldo->jenisSimpanan->nama_simpanan); ?></h6>
                        <h3 class="text-success currency-display">Rp <?php echo e(number_format($saldo->total_saldo, 0, ',', '.')); ?></h3>
                        <small class="text-muted"><?php echo e($saldo->jenisSimpanan->keterangan); ?></small>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-12">
                <div class="alert alert-info">Belum ada data simpanan</div>
            </div>
        <?php endif; ?>
    </div>

    <!-- Riwayat Transaksi -->
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Riwayat Transaksi Simpanan</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Jenis Simpanan</th>
                            <th>Transaksi</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-end">Saldo</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $riwayatSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($r->tanggal_transaksi)->format('d/m/Y')); ?></td>
                                <td><?php echo e($r->jenisSimpanan->nama_simpanan); ?></td>
                                <td>
                                    <span class="badge <?php echo e($r->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e(ucfirst($r->jenis_transaksi)); ?>

                                    </span>
                                </td>
                                <td class="text-end currency-display <?php echo e($r->jenis_transaksi == 'setor' ? 'text-success' : 'text-danger'); ?>">
                                    <?php echo e($r->jenis_transaksi == 'setor' ? '+' : '-'); ?>Rp <?php echo e(number_format($r->jumlah, 0, ',', '.')); ?>

                                </td>
                                <td class="text-end currency-display">Rp <?php echo e(number_format($r->saldo_sesudah, 0, ',', '.')); ?></td>
                                <td><?php echo e($r->keterangan ?? '-'); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">Belum ada transaksi simpanan</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <?php echo e($riwayatSimpanan->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/simpanan.blade.php ENDPATH**/ ?>