<?php $__env->startSection('title', 'Detail Pengajuan Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.pinjaman.pengajuan')); ?>">Pengajuan Pinjaman</a></li>
            <li class="breadcrumb-item active"><?php echo e($pengajuan->no_pengajuan); ?></li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><?php echo e($pengajuan->no_pengajuan); ?></h5>
                    <?php echo $pengajuan->status_label; ?>

                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-muted">Data Anggota</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td>No. Anggota</td>
                                    <td><strong><?php echo e($pengajuan->anggota->no_anggota); ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Nama</td>
                                    <td><strong><?php echo e($pengajuan->anggota->nama_anggota); ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Unit Kerja</td>
                                    <td><?php echo e($pengajuan->anggota->unit_kerja ?? '-'); ?></td>
                                </tr>
                                <tr>
                                    <td>No. HP</td>
                                    <td><?php echo e($pengajuan->anggota->no_hp ?? '-'); ?></td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">Data Pengajuan</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td>Tanggal Pengajuan</td>
                                    <td><?php echo e($pengajuan->created_at->format('d/m/Y H:i')); ?></td>
                                </tr>
                                <tr>
                                    <td>Produk</td>
                                    <td><strong><?php echo e($pengajuan->produkPinjaman->nama_produk); ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Jumlah</td>
                                    <td class="fs-5 text-primary"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman, 0, ',', '.')); ?></strong></td>
                                </tr>
                                <tr>
                                    <td>Tenor</td>
                                    <td><strong><?php echo e($pengajuan->tenor); ?> bulan</strong></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="text-muted">Keperluan</h6>
                        <p class="border rounded p-3 bg-light"><?php echo e($pengajuan->keperluan); ?></p>
                    </div>

                    <!-- Dokumen -->
                    <h6 class="text-muted">Dokumen Persyaratan</h6>
                    <div class="row">
                        <?php if($pengajuan->dok_ktp): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-id-card fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">KTP</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_ktp)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($pengajuan->dok_kk): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-users fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Kartu Keluarga</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_kk)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                        <?php if($pengajuan->dok_slip_gaji): ?>
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-file-invoice-dollar fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Slip Gaji</p>
                                    <a href="<?php echo e(Storage::url($pengajuan->dok_slip_gaji)); ?>" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if($pengajuan->catatan_approval): ?>
                        <div class="alert alert-<?php echo e($pengajuan->status == 'ditolak' ? 'danger' : 'info'); ?> mt-3">
                            <strong>Catatan:</strong> <?php echo e($pengajuan->catatan_approval); ?>

                        </div>
                    <?php endif; ?>

                    <!-- Actions -->
                    <?php if($pengajuan->status == 'pending' || $pengajuan->status == 'diproses'): ?>
                        <hr>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <form action="<?php echo e(route('admin.pinjaman.pengajuan-approve', $pengajuan->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Catatan (opsional)"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fas fa-check me-2"></i>Setujui Pengajuan
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-6 mb-3">
                                <form action="<?php echo e(route('admin.pinjaman.pengajuan-tolak', $pengajuan->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Alasan penolakan (wajib)" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100">
                                        <i class="fas fa-times me-2"></i>Tolak Pengajuan
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>

                    <!-- Cairkan -->
                    <?php if($pengajuan->status == 'disetujui'): ?>
                        <hr>
                        <div class="alert alert-success">
                            <strong><i class="fas fa-check-circle me-2"></i>Pengajuan Disetujui</strong>
                            <p class="mb-0">Silakan cairkan pinjaman ini.</p>
                        </div>
                        <form action="<?php echo e(route('admin.pinjaman.cairkan', $pengajuan->id)); ?>" method="POST" class="row">
                            <?php echo csrf_field(); ?>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Tanggal Pencairan</label>
                                <input type="date" name="tanggal_pinjaman" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Sumber Dana</label>
                                <select name="jenis_keluar" class="form-select" required>
                                    <option value="kas">Kas</option>
                                    <option value="bank">Bank</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-money-bill-wave me-2"></i>Cairkan Pinjaman
                                </button>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Simulasi -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Simulasi Angsuran</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <td>Jumlah Pinjaman</td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman, 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Bunga/tahun</td>
                            <td class="text-end"><?php echo e($pengajuan->produkPinjaman->bunga_persen); ?>%</td>
                        </tr>
                        <tr>
                            <td>Tenor</td>
                            <td class="text-end"><?php echo e($pengajuan->tenor); ?> bulan</td>
                        </tr>
                        <tr class="table-light">
                            <td colspan="2"><strong>Perhitungan</strong></td>
                        </tr>
                        <tr>
                            <td>Angsuran Pokok/bln</td>
                            <td class="text-end">Rp <?php echo e(number_format($simulasi['angsuran_pokok'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <td>Angsuran Bunga/bln</td>
                            <td class="text-end">Rp <?php echo e(number_format($simulasi['angsuran_bunga'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr class="table-success">
                            <td><strong>Total Angsuran/bln</strong></td>
                            <td class="text-end fs-5"><strong>Rp <?php echo e(number_format($simulasi['total_angsuran'], 0, ',', '.')); ?></strong></td>
                        </tr>
                        <tr>
                            <td>Total Bunga</td>
                            <td class="text-end">Rp <?php echo e(number_format($simulasi['total_bunga'], 0, ',', '.')); ?></td>
                        </tr>
                        <tr>
                            <td>Total Bayar</td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($pengajuan->jumlah_pinjaman + $simulasi['total_bunga'], 0, ',', '.')); ?></strong></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Riwayat Anggota -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="mb-0">Riwayat Pinjaman Anggota</h6>
                </div>
                <div class="card-body">
                    <?php
                        $riwayatPinjaman = $pengajuan->anggota->pinjaman ?? collect();
                    ?>
                    <?php if($riwayatPinjaman->count() > 0): ?>
                        <?php $__currentLoopData = $riwayatPinjaman->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pinj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="border-bottom pb-2 mb-2">
                                <div class="d-flex justify-content-between">
                                    <small><?php echo e($pinj->no_pinjaman); ?></small>
                                    <?php echo $pinj->status_label; ?>

                                </div>
                                <small class="text-muted">Rp <?php echo e(number_format($pinj->jumlah_pinjaman, 0, ',', '.')); ?></small>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p class="text-muted mb-0">Belum ada riwayat pinjaman</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/pinjaman/pengajuan-detail.blade.php ENDPATH**/ ?>