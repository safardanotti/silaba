<?php $__env->startSection('title', 'Input Transaksi Penerimaan'); ?>
<?php $__env->startSection('page-title'); ?>
    <i class="fas fa-download text-success"></i> Input Transaksi Penerimaan
<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('transaksi.penerimaan.store')); ?>" id="formPenerimaan">
    <?php echo csrf_field(); ?>
    <input type="hidden" id="jenis_transaksi" value="penerimaan">
    
    <div class="card">
        <div class="card-header">
            <h3 class="mb-0">Form Input Penerimaan</h3>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Tanggal Transaksi *</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" 
                               value="<?php echo e(old('tanggal', date('Y-m-d'))); ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Uraian Kegiatan *</label>
                        <input type="text" class="form-control" id="uraian_kegiatan" name="uraian_kegiatan" 
                               placeholder="Contoh: ANGSURAN SEWA DEPOT FOOD COURT" 
                               value="<?php echo e(old('uraian_kegiatan')); ?>" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Jenis Masuk *</label>
                        <select class="form-select" id="jenis_masuk" name="jenis_masuk" required>
                            <option value="">Pilih Jenis Masuk</option>
                            <option value="kas" <?php echo e(old('jenis_masuk') == 'kas' ? 'selected' : ''); ?>>KAS</option>
                            <option value="bank" <?php echo e(old('jenis_masuk') == 'bank' ? 'selected' : ''); ?>>BANK</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>Detail Jurnal Transaksi</h4>
                <button type="button" class="btn btn-primary btn-sm" onclick="addTransactionRow()">
                    <i class="fas fa-plus"></i> Tambah Baris
                </button>
            </div>
            
            <div class="alert alert-warning mb-3" id="balanceWarning" style="display: none;">
                <i class="fas fa-exclamation-triangle"></i> Perhatian: Total Debet dan Kredit harus balance untuk transaksi penerimaan!
            </div>
            
            <div class="alert alert-info mb-3">
                <i class="fas fa-info-circle"></i> <strong>Tips:</strong> Semua transaksi dengan "Jenis Masuk" KAS akan dihitung sebagai KAS, dan yang memilih BANK akan dihitung sebagai BANK.
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">NO</th>
                            <th width="200">KODE AKUN</th>
                            <th>NAMA AKUN</th>
                            <th width="100">JENIS MASUK</th>
                            <th width="120">TANGGAL</th>
                            <th width="180">DEBET (Rp)</th>
                            <th width="180">KREDIT (Rp)</th>
                            <th width="50">AKSI</th>
                        </tr>
                    </thead>
                    <tbody id="transactionDetails">
                        <!-- Rows will be added dynamically -->
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-end"><strong>TOTAL:</strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalDebet">0</span></strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalKredit">0</span></strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-end"><strong>SELISIH:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong class="currency-display">Rp <span id="selisih">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-end"><strong>KAS MASUK:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong class="currency-display text-success">Rp <span id="totalKas">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-end"><strong>BANK MASUK:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong class="currency-display text-primary">Rp <span id="totalBank">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Transaksi
                </button>
                <a href="<?php echo e(route('laporan.transaksi')); ?>" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
                <button type="button" class="btn btn-warning text-white" onclick="if(confirm('Cetak nota?')) window.print();">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </div>
    </div>
</form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// Store kode akun data
const kodeAkunData = <?php echo json_encode($kodeAkun, 15, 512) ?>;

// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    // Hapus semua karakter kecuali angka dan koma
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    // Ganti koma dengan titik untuk parsing
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format input saat mengetik
function formatCurrencyInput(input) {
    let value = input.value;
    
    // Hapus semua karakter selain angka dan koma
    value = value.replace(/[^\d,]/g, '');
    
    // Pisahkan bagian integer dan desimal
    let parts = value.split(',');
    
    // Format bagian integer dengan titik sebagai pemisah ribuan
    if (parts[0]) {
        // Hapus leading zeros kecuali jika hanya "0"
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        // Tambahkan pemisah ribuan
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    // Batasi desimal hingga 2 digit
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

// Add transaction row
function addTransactionRow() {
    const tbody = document.getElementById('transactionDetails');
    const rowCount = tbody.rows.length + 1;
    
    const tanggal = document.getElementById('tanggal').value;
    const jenisMasuk = document.getElementById('jenis_masuk').value;
    
    let jenisMasukDisplay = jenisMasuk ? jenisMasuk.toUpperCase() : '-';
    
    const row = tbody.insertRow();
    row.innerHTML = `
        <td>${rowCount}</td>
        <td>
            <select name="kode_akun[]" class="form-select kode-akun-select" required onchange="updateAccountName(this)">
                <option value="">Pilih Kode Akun</option>
                ${kodeAkunData.map(akun => 
                    `<option value="${akun.kode_akun}" data-nama="${akun.nama_akun}">${akun.kode_akun} - ${akun.nama_akun}</option>`
                ).join('')}
            </select>
        </td>
        <td class="nama-akun">-</td>
        <td class="jenis-masuk">${jenisMasukDisplay}</td>
        <td>${tanggal}</td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="debet[]" class="form-control currency-input" 
                       onkeyup="formatCurrencyInput(this); calculateTotal();" 
                       onfocus="this.select();" value="0" placeholder="0">
            </div>
        </td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="kredit[]" class="form-control currency-input" 
                       onkeyup="formatCurrencyInput(this); calculateTotal();" 
                       onfocus="this.select();" value="0" placeholder="0">
            </div>
        </td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    // Auto-select KAS/BANK for first row based on jenis_masuk
    if (rowCount === 1 && jenisMasuk) {
        const selectElement = row.querySelector('select[name="kode_akun[]"]');
        if (jenisMasuk === 'kas') {
            selectElement.value = '100';
        } else if (jenisMasuk === 'bank') {
            selectElement.value = '101';
        }
        updateAccountName(selectElement);
    }
}

// Update account name
function updateAccountName(select) {
    const namaAkun = select.options[select.selectedIndex].dataset.nama || '-';
    select.closest('tr').querySelector('.nama-akun').textContent = namaAkun;
}

// Remove transaction row
function removeRow(btn) {
    const row = btn.closest('tr');
    row.remove();
    updateRowNumbers();
    calculateTotal();
}

// Update row numbers
function updateRowNumbers() {
    const tbody = document.getElementById('transactionDetails');
    const rows = tbody.querySelectorAll('tr');
    rows.forEach((row, index) => {
        row.cells[0].textContent = index + 1;
    });
}

// Calculate total
function calculateTotal() {
    let totalDebet = 0;
    let totalKredit = 0;
    
    document.querySelectorAll('input[name="debet[]"]').forEach(input => {
        totalDebet += parseRupiah(input.value);
    });
    
    document.querySelectorAll('input[name="kredit[]"]').forEach(input => {
        totalKredit += parseRupiah(input.value);
    });
    
    const jenisMasuk = document.getElementById('jenis_masuk').value;
    let totalKas = 0;
    let totalBank = 0;
    
    if (jenisMasuk === 'kas') {
        totalKas = totalDebet - totalKredit;
    } else if (jenisMasuk === 'bank') {
        totalBank = totalDebet - totalKredit;
    }
    
    document.getElementById('totalDebet').textContent = formatRupiah(totalDebet);
    document.getElementById('totalKredit').textContent = formatRupiah(totalKredit);
    document.getElementById('selisih').textContent = formatRupiah(Math.abs(totalDebet - totalKredit));
    document.getElementById('totalKas').textContent = formatRupiah(Math.abs(totalKas));
    document.getElementById('totalBank').textContent = formatRupiah(Math.abs(totalBank));
    
    // Check balance
    const selisihElement = document.getElementById('selisih');
    const warningElement = document.getElementById('balanceWarning');
    
    if (Math.abs(totalDebet - totalKredit) > 0.01) {
        selisihElement.style.color = 'red';
        warningElement.style.display = 'block';
    } else {
        selisihElement.style.color = 'green';
        warningElement.style.display = 'none';
    }
}

// Update all detail rows when main form changes
function updateAllDetailRows() {
    const jenisMasuk = document.getElementById('jenis_masuk').value;
    const tanggal = document.getElementById('tanggal').value;
    
    document.querySelectorAll('.jenis-masuk').forEach(cell => {
        cell.textContent = jenisMasuk ? jenisMasuk.toUpperCase() : '-';
    });
    
    document.querySelectorAll('#transactionDetails tr').forEach(row => {
        if (row.cells[4]) {
            row.cells[4].textContent = tanggal;
        }
    });
    
    // Update first row kode akun based on jenis_masuk
    const firstRowSelect = document.querySelector('#transactionDetails tr:first-child select[name="kode_akun[]"]');
    if (firstRowSelect && jenisMasuk) {
        const currentValue = firstRowSelect.value;
        if (currentValue === '100' || currentValue === '101' || currentValue === '') {
            if (jenisMasuk === 'kas') {
                firstRowSelect.value = '100';
            } else if (jenisMasuk === 'bank') {
                firstRowSelect.value = '101';
            }
            updateAccountName(firstRowSelect);
        }
    }
    
    calculateTotal();
}

// Add event listeners
document.addEventListener('DOMContentLoaded', function() {
    addTransactionRow();
    
    document.getElementById('jenis_masuk').addEventListener('change', updateAllDetailRows);
    document.getElementById('tanggal').addEventListener('change', updateAllDetailRows);
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/transaksi/penerimaan.blade.php ENDPATH**/ ?>