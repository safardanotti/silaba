<?php $__env->startSection('title', 'Laba Rugi'); ?>
<?php $__env->startSection('page-title', 'Laba Rugi'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .laba-rugi-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 10pt;
    }
    .laba-rugi-table td, .laba-rugi-table th {
        padding: 3px 5px;
        border: 1px solid #000;
    }
    .laba-rugi-table th {
        background-color: #f0f0f0;
        text-align: center;
        font-weight: bold;
        vertical-align: middle;
    }
    .section-header {
        font-weight: bold;
    }
    .text-right {
        text-align: right;
    }
    .text-center {
        text-align: center;
    }
    .total-row {
        font-weight: bold;
        background-color: #e0e0e0;
    }
    .sub-total {
        font-weight: bold;
    }
    .grand-total {
        font-weight: bold;
        background-color: #ffffcc;
    }
    .laba-rugi-row {
        background-color: #e6ffe6;
        font-weight: bold;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        body {
            font-size: 10pt;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Filter Section -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="bulan" class="form-select" onchange="updateUrl()">
                    <?php $__currentLoopData = $bulanNama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php echo e($bulan == $key ? 'selected' : ''); ?>>
                            <?php echo e($value); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="<?php echo e($tahun); ?>" 
                       min="2020" max="2030" onchange="updateUrl()">
            </div>
            <div class="col-md-6 d-flex align-items-end gap-2">
                <button type="submit" name="generate" value="1" class="btn btn-primary">
                    <i class="fas fa-file-alt"></i> Generate Laba Rugi
                </button>
                <?php if($showLabaRugi ?? false): ?>
                <button type="button" class="btn btn-info" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
                <a href="<?php echo e(route('export.laba-rugi', ['bulan' => $bulan, 'tahun' => $tahun])); ?>" 
                   class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <a href="<?php echo e(route('neraca.index', ['bulan' => $bulan, 'tahun' => $tahun])); ?>" 
                   class="btn btn-warning">
                    <i class="fas fa-balance-scale"></i> Lihat Neraca
                </a>
                <?php endif; ?>
            </div>
        </form>
    </div>
</div>

<?php if($showLabaRugi ?? false): ?>
<!-- Laba Rugi Header -->
<div class="text-center mb-3">
    <h5>KOPERASI KARYAWAN PELABUHAN<br>
    CABANG PALEMBANG</h5>
    <h4><strong>REALISASI PERHITUNGAN LABA-RUGI<br>
    BULAN <?php echo e(strtoupper($bulanNama[$bulan])); ?> <?php echo e($tahun); ?></strong></h4>
</div>

<!-- Laba Rugi Table -->
<table class="laba-rugi-table">
    <thead>
        <tr>
            <th rowspan="2" width="5%">NO</th>
            <th rowspan="2" width="35%">URAIAN</th>
            <th rowspan="2" width="12%">Anggaran Tahun <?php echo e($tahun); ?></th>
            <th rowspan="2" width="12%">Anggaran Triwulan IV</th>
            <th colspan="3">Realisasi</th>
        </tr>
        <tr>
            <th width="12%">S/D BULAN LALU</th>
            <th width="12%">BULAN INI</th>
            <th width="12%">S/D BULAN INI</th>
        </tr>
    </thead>
    <tbody>
        <!-- I. PENDAPATAN -->
        <tr>
            <td colspan="7" class="section-header">I. PENDAPATAN</td>
        </tr>
        <?php $__currentLoopData = $pendapatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->kode_akun); ?></td>
            <td><?php echo e($item->nama_akun); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_tahun, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_triwulan, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->realisasi_bulan_lalu, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->mutasi_bulan_ini, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->sd_bulan_ini, 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 1:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlah1, 2, ',', '.')); ?></td>
        </tr>
        
        <!-- PENDAPATAN USAHA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">PENDAPATAN USAHA DILUAR ANGGOTA</td>
        </tr>
        <?php $__currentLoopData = $pendapatanUsaha; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->kode_akun); ?></td>
            <td><?php echo e($item->nama_akun); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_tahun, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_triwulan, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->realisasi_bulan_lalu, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->mutasi_bulan_ini, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->sd_bulan_ini, 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 2:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlah2, 2, ',', '.')); ?></td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Pendapatan (1+2)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlahPendapatan, 2, ',', '.')); ?></td>
        </tr>
        
        <!-- II. BIAYA - BIAYA -->
        <tr>
            <td colspan="7" class="section-header">II. BIAYA - BIAYA</td>
        </tr>
        
        <!-- BIAYA DENGAN ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA DENGAN ANGGOTA</td>
        </tr>
        <?php $__currentLoopData = $biayaDenganAnggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->kode_akun); ?></td>
            <td><?php echo e($item->nama_akun); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_tahun, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_triwulan, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->realisasi_bulan_lalu, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->mutasi_bulan_ini, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->sd_bulan_ini, 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 3:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlah3, 2, ',', '.')); ?></td>
        </tr>
        
        <!-- BIAYA - BIAYA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA - BIAYA DILUAR ANGGOTA</td>
        </tr>
        <?php $__currentLoopData = $biayaDiluarAnggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->kode_akun); ?></td>
            <td><?php echo e($item->nama_akun); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_tahun, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_triwulan, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->realisasi_bulan_lalu, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->mutasi_bulan_ini, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->sd_bulan_ini, 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 4:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlah4, 2, ',', '.')); ?></td>
        </tr>
        
        <!-- BIAYA ORGANISASI DAN MANAJEMEN -->
        <tr>
            <td colspan="7" class="section-header">BIAYA ORGANISASI DAN MANAJEMEN</td>
        </tr>
        <?php $__currentLoopData = $biayaOrganisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($item->kode_akun); ?></td>
            <td><?php echo e($item->nama_akun); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_tahun, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->anggaran_triwulan, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->realisasi_bulan_lalu, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->mutasi_bulan_ini, 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($item->sd_bulan_ini, 2, ',', '.')); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 5:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlah5, 2, ',', '.')); ?></td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Biaya (3+4+5)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($jumlahBiaya, 2, ',', '.')); ?></td>
        </tr>
        
        <!-- LABA RUGI CALCULATIONS -->
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (1-3)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($labaRugi1_3, 2, ',', '.')); ?></td>
        </tr>
        
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (2-4)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><?php echo e(number_format($labaRugi2_4, 2, ',', '.')); ?></td>
        </tr>
        
        <tr class="grand-total">
            <td colspan="2" class="text-center"><strong>Laba - Rugi (I-II)</strong></td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><strong><?php echo e(number_format($labaRugiBersih, 2, ',', '.')); ?></strong></td>
        </tr>
    </tbody>
</table>

<div class="alert alert-info mt-3 no-print">
    <strong>Informasi:</strong>
    <ul>
        <li>Nilai Laba/Rugi Bersih: <strong>Rp <?php echo e(number_format($labaRugiBersih, 2, ',', '.')); ?></strong></li>
        <li>Laba Rugi (1-3): <strong>Rp <?php echo e(number_format($labaRugi1_3, 2, ',', '.')); ?></strong></li>
        <li>Laba Rugi (2-4): <strong>Rp <?php echo e(number_format($labaRugi2_4, 2, ',', '.')); ?></strong></li>
        <li>Nilai ini akan dicatat sebagai SHU Tahun Berjalan (kode 900) di Neraca</li>
    </ul>
</div>

<!-- Form untuk input/update anggaran -->
<div class="card mt-3 no-print">
    <div class="card-header bg-secondary text-white">
        <h6 class="mb-0">Update Anggaran & Realisasi S/D Bulan Lalu</h6>
    </div>
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('laba-rugi.store-anggaran')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="periode" value="<?php echo e($tahun); ?>-<?php echo e($bulan); ?>-01">
            <input type="hidden" name="redirect_url" value="<?php echo e(route('laba-rugi.index', ['bulan' => $bulan, 'tahun' => $tahun, 'generate' => 1])); ?>">
            
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Akun</th>
                            <th>Anggaran Tahun</th>
                            <th>Anggaran Triwulan</th>
                            <th>Realisasi S/D Bulan Lalu</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $allAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $accObj = is_array($acc) ? (object)$acc : $acc;
                        ?>
                        <tr>
                            <td><?php echo e($accObj->kode_akun); ?></td>
                            <td><?php echo e($accObj->nama_akun); ?></td>
                            <td>
                                <input type="number" name="anggaran_tahun[<?php echo e($accObj->kode_akun); ?>]" 
                                       class="form-control form-control-sm" 
                                       value="<?php echo e($accObj->anggaran_tahun); ?>" step="0.01">
                            </td>
                            <td>
                                <input type="number" name="anggaran_triwulan[<?php echo e($accObj->kode_akun); ?>]" 
                                       class="form-control form-control-sm" 
                                       value="<?php echo e($accObj->anggaran_triwulan); ?>" step="0.01">
                            </td>
                            <td>
                                <input type="number" name="realisasi_bulan_lalu[<?php echo e($accObj->kode_akun); ?>]" 
                                       class="form-control form-control-sm" 
                                       value="<?php echo e($accObj->realisasi_bulan_lalu); ?>" step="0.01">
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Anggaran
            </button>
        </form>
    </div>
</div>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function updateUrl() {
    const bulan = document.querySelector('[name="bulan"]').value;
    const tahun = document.querySelector('[name="tahun"]').value;
    window.location.href = `?bulan=${bulan}&tahun=${tahun}`;
}
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/laba-rugi/index.blade.php ENDPATH**/ ?>