<?php $__env->startSection('title', 'Review Neraca'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4"><i class="fas fa-clipboard-check"></i> Review Neraca</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Daftar Neraca -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Daftar Neraca untuk Direview</h5>
            
            <?php if($postingList->isEmpty()): ?>
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Tidak ada neraca yang perlu direview saat ini.
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Periode</th>
                                <th>Status</th>
                                <th>Diposting Oleh</th>
                                <th>Tanggal Posting</th>
                                <th>Catatan Revisi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $postingList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $periodeDate = \Carbon\Carbon::parse($posting->periode);
                                $bulanKey = $periodeDate->format('m');
                                $tahunVal = $periodeDate->format('Y');
                            ?>
                            <tr>
                                <td>
                                    <strong><?php echo e($bulanNama[$bulanKey] ?? $bulanKey); ?> <?php echo e($tahunVal); ?></strong>
                                </td>
                                <td>
                                    <span class="badge bg-<?php echo e($posting->status == 'posted' ? 'info' : ($posting->status == 'revisi' ? 'warning' : 'success')); ?>">
                                        <?php echo e(strtoupper($posting->status)); ?>

                                    </span>
                                </td>
                                <td><?php echo e($posting->postedBy->full_name ?? '-'); ?></td>
                                <td><?php echo e($posting->posted_at ? \Carbon\Carbon::parse($posting->posted_at)->format('d/m/Y H:i') : '-'); ?></td>
                                <td>
                                    <?php if($posting->catatan_revisi): ?>
                                        <small class="text-muted"><?php echo e($posting->catatan_revisi); ?></small>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo e(route('neraca.review.detail', $posting->id)); ?>" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> Review
                                    </a>
                                    
                                    <?php if($posting->status == 'approved'): ?>
                                        <a href="<?php echo e(route('export.neraca-approved', $posting->id)); ?>" class="btn btn-sm btn-success">
                                            <i class="fas fa-file-excel"></i> Export
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Riwayat Review -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Riwayat Review Terakhir</h5>
            
            <?php if($recentHistory->isEmpty()): ?>
                <p class="text-muted">Belum ada riwayat review.</p>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Periode</th>
                                <th>User</th>
                                <th>Aksi</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $recentHistory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $periodeDate = $h->posting ? \Carbon\Carbon::parse($h->posting->periode) : null;
                                $bulanKey = $periodeDate ? $periodeDate->format('m') : '01';
                                $tahunVal = $periodeDate ? $periodeDate->format('Y') : '-';
                            ?>
                            <tr>
                                <td><?php echo e(\Carbon\Carbon::parse($h->created_at)->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e(($bulanNama[$bulanKey] ?? $bulanKey) . ' ' . $tahunVal); ?></td>
                                <td><?php echo e($h->user->full_name ?? '-'); ?></td>
                                <td>
                                    <span class="badge bg-<?php echo e($h->action == 'post' ? 'primary' : ($h->action == 'revisi' ? 'warning' : 'success')); ?>">
                                        <?php echo e(strtoupper($h->action)); ?>

                                    </span>
                                </td>
                                <td><small><?php echo e($h->catatan); ?></small></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/neraca/review.blade.php ENDPATH**/ ?>