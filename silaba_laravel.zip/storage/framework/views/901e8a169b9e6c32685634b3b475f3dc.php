<?php $__env->startSection('title', 'Neraca'); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .currency-display {
        font-family: 'Courier New', monospace;
    }
    .table-neraca td.text-end,
    .table-neraca th.text-end {
        font-family: 'Courier New', monospace;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-4">Neraca</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo e(session('success')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo e(session('error')); ?>

            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endif; ?>

    <!-- Filter Form -->
    <div class="card mb-4 no-print">
        <div class="card-body">
            <form method="GET" action="<?php echo e(route('neraca.index')); ?>" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Bulan</label>
                    <select name="bulan" class="form-select">
                        <?php $__currentLoopData = $bulanNama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e($bulan == $key ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Tahun</label>
                    <input type="number" name="tahun" class="form-control" value="<?php echo e($tahun); ?>" min="2020" max="2099">
                </div>
                <div class="col-md-7">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-sync"></i> Generate Neraca
                    </button>
                    <?php if($showNeraca ?? false): ?>
                        <a href="<?php echo e(route('export.neraca', ['bulan' => $bulan, 'tahun' => $tahun])); ?>" class="btn btn-primary">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </a>
                        <button type="button" class="btn btn-secondary" onclick="window.print()">
                            <i class="fas fa-print"></i> Cetak
                        </button>
                        <a href="<?php echo e(route('laba-rugi.index', ['bulan' => $bulan, 'tahun' => $tahun])); ?>" class="btn btn-info">
                            <i class="fas fa-chart-line"></i> Lihat Laba Rugi
                        </a>
                        
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <?php if(!$postingData || $postingData->status == 'draft' || $postingData->status == 'revisi'): ?>
                                <button type="button" class="btn btn-warning" onclick="postNeraca()">
                                    <i class="fas fa-paper-plane"></i> Post Neraca
                                </button>
                            <?php endif; ?>
                        <?php endif; ?>
                        
                        <?php if($postingData): ?>
                            <span class="badge bg-<?php echo e($postingData->status == 'posted' ? 'info' : ($postingData->status == 'revisi' ? 'warning' : ($postingData->status == 'approved' ? 'success' : 'secondary'))); ?> fs-6 ms-2">
                                Status: <?php echo e(strtoupper($postingData->status)); ?>

                            </span>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </form>
        </div>
    </div>

    <?php if($showNeraca ?? false): ?>
    <!-- Neraca Table -->
    <div class="card">
        <div class="card-body">
            <h4 class="text-center mb-1"><strong>NERACA</strong></h4>
            <h5 class="text-center mb-4">PER <?php echo e($bulanNama[$bulan]); ?> <?php echo e($tahun); ?></h5>

            <?php if($postingData && $postingData->status == 'revisi'): ?>
                <div class="alert alert-warning">
                    <strong><i class="fas fa-exclamation-triangle"></i> Perlu Revisi!</strong><br>
                    Catatan: <?php echo e($postingData->catatan_revisi); ?>

                </div>
            <?php endif; ?>

            <div class="table-responsive">
                <table class="table table-bordered table-sm table-neraca">
                    <thead class="table-light">
                        <tr>
                            <th colspan="3" class="text-center">AKTIVA</th>
                            <th colspan="3" class="text-center">PASSIVA</th>
                        </tr>
                        <tr>
                            <th width="8%" class="text-center">NO REK</th>
                            <th width="25%">URAIAN</th>
                            <th width="17%" class="text-end">JUMLAH (Rp)</th>
                            <th width="8%" class="text-center">NO REK</th>
                            <th width="25%">URAIAN</th>
                            <th width="17%" class="text-end">JUMLAH (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- AKTIVA LANCAR & HUTANG -->
                        <tr>
                            <td colspan="3"><strong><u>AKTIVA LANCAR :</u></strong></td>
                            <td colspan="3"><strong><u>HUTANG :</u></strong></td>
                        </tr>
                        <?php
                            $maxRowsLancarHutang = max(count($aktiva['lancar'] ?? []), count($passiva['hutang'] ?? []));
                        ?>
                        <?php for($i = 0; $i < $maxRowsLancarHutang; $i++): ?>
                            <tr>
                                <?php if(isset($aktiva['lancar'][$i])): ?>
                                    <td class="text-center"><?php echo e($aktiva['lancar'][$i]['kode']); ?></td>
                                    <td><?php echo e($aktiva['lancar'][$i]['nama']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($aktiva['lancar'][$i]['jumlah'], 0, ',', '.')); ?></td>
                                <?php else: ?>
                                    <td></td><td></td><td></td>
                                <?php endif; ?>
                                <?php if(isset($passiva['hutang'][$i])): ?>
                                    <td class="text-center"><?php echo e($passiva['hutang'][$i]['kode']); ?></td>
                                    <td><?php echo e($passiva['hutang'][$i]['nama']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($passiva['hutang'][$i]['jumlah'], 0, ',', '.')); ?></td>
                                <?php else: ?>
                                    <td></td><td></td><td></td>
                                <?php endif; ?>
                            </tr>
                        <?php endfor; ?>
                        <tr class="table-secondary">
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalAktivaLancar ?? 0, 0, ',', '.')); ?></strong></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalHutang ?? 0, 0, ',', '.')); ?></strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- AKTIVA TETAP & DANA-DANA -->
                        <tr>
                            <td colspan="3"><strong><u>AKTIVA TETAP :</u></strong></td>
                            <td colspan="3"><strong><u>DANA - DANA :</u></strong></td>
                        </tr>
                        <?php
                            $maxRowsTetapDana = max(count($aktiva['tetap'] ?? []), count($passiva['dana'] ?? []));
                        ?>
                        <?php for($i = 0; $i < $maxRowsTetapDana; $i++): ?>
                            <tr>
                                <?php if(isset($aktiva['tetap'][$i])): ?>
                                    <td class="text-center"><?php echo e($aktiva['tetap'][$i]['kode']); ?></td>
                                    <td><?php echo e($aktiva['tetap'][$i]['nama']); ?></td>
                                    <td class="text-end">
                                        <?php if($aktiva['tetap'][$i]['is_negative'] ?? false): ?>
                                            (<?php echo e(number_format($aktiva['tetap'][$i]['jumlah'], 0, ',', '.')); ?>)
                                        <?php else: ?>
                                            <?php echo e(number_format($aktiva['tetap'][$i]['jumlah'], 0, ',', '.')); ?>

                                        <?php endif; ?>
                                    </td>
                                <?php else: ?>
                                    <td></td><td></td><td></td>
                                <?php endif; ?>
                                <?php if(isset($passiva['dana'][$i])): ?>
                                    <td class="text-center"><?php echo e($passiva['dana'][$i]['kode']); ?></td>
                                    <td><?php echo e($passiva['dana'][$i]['nama']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($passiva['dana'][$i]['jumlah'], 0, ',', '.')); ?></td>
                                <?php else: ?>
                                    <td></td><td></td><td></td>
                                <?php endif; ?>
                            </tr>
                        <?php endfor; ?>
                        <tr class="table-secondary">
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalAktivaTetap ?? 0, 0, ',', '.')); ?></strong></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalDana ?? 0, 0, ',', '.')); ?></strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- MODAL -->
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="3"><strong><u>MODAL :</u></strong></td>
                        </tr>
                        <?php $__currentLoopData = $passiva['modal'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td><td></td><td></td>
                                <td class="text-center"><?php echo e($item['kode']); ?></td>
                                <td><?php echo e($item['nama']); ?></td>
                                <td class="text-end"><?php echo e(number_format($item['jumlah'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-secondary">
                            <td></td><td></td><td></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalModal ?? 0, 0, ',', '.')); ?></strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- SHU -->
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="3"><strong><u>SISA HASIL USAHA :</u></strong></td>
                        </tr>
                        <?php $__currentLoopData = $passiva['shu'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td></td><td></td><td></td>
                                <td class="text-center"><?php echo e($item['kode']); ?></td>
                                <td><?php echo e($item['nama']); ?></td>
                                <td class="text-end"><?php echo e(number_format($item['jumlah'], 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr class="table-secondary">
                            <td></td><td></td><td></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalSHU ?? 0, 0, ',', '.')); ?></strong></td>
                        </tr>

                        <!-- TOTAL -->
                        <tr class="table-dark">
                            <td colspan="2" class="text-center"><strong>JUMLAH AKTIVA</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalAktiva ?? 0, 0, ',', '.')); ?></strong></td>
                            <td colspan="2" class="text-center"><strong>JUMLAH PASSIVA</strong></td>
                            <td class="text-end"><strong>Rp <?php echo e(number_format($totalPassiva ?? 0, 0, ',', '.')); ?></strong></td>
                        </tr>

                        <?php if(abs(($totalAktiva ?? 0) - ($totalPassiva ?? 0)) > 0.01): ?>
                        <tr class="table-danger">
                            <td colspan="6" class="text-center">
                                <strong><i class="fas fa-exclamation-triangle"></i> TIDAK BALANCE! Selisih: Rp <?php echo e(number_format(abs($totalAktiva - $totalPassiva), 0, ',', '.')); ?></strong>
                            </td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startPush('scripts'); ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function postNeraca() {
    Swal.fire({
        title: 'Post Neraca',
        text: 'Apakah Anda yakin ingin memposting neraca periode <?php echo e($bulanNama[$bulan]); ?> <?php echo e($tahun); ?> untuk direview pimpinan?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Post',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "<?php echo e(route('neraca.post', ['bulan' => $bulan, 'tahun' => $tahun])); ?>";
        }
    });
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/neraca/index.blade.php ENDPATH**/ ?>