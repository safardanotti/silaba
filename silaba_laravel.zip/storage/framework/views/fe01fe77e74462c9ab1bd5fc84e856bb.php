<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; vertical-align: middle; }
        th { background-color: #cccccc; font-weight: bold; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; background-color: #cccccc; }
        .merged { vertical-align: middle; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="8" class="header">TRANSAKSI RUPA-RUPA</td>
        </tr>
        <tr>
            <td colspan="8" class="header">PERIODE <?php echo e($periodeName); ?></td>
        </tr>
        <tr>
            <td colspan="8">&nbsp;</td>
        </tr>
        <tr>
            <th width="5%">NO</th>
            <th width="10%">KODE AKUN</th>
            <th width="25%">NAMA AKUN</th>
            <th width="30%">URAIAN KEGIATAN</th>
            <th width="10%">JENIS</th>
            <th width="10%">TANGGAL</th>
            <th width="10%">DEBET</th>
            <th width="10%">KREDIT</th>
        </tr>
        <?php $no = 1; ?>
        <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transId => $trans): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php 
                $detailCount = count($trans['details']);
                $isFirst = true;
            ?>
            <?php $__currentLoopData = $trans['details']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($no++); ?></td>
            <td class="text-center"><?php echo e($detail['kode_akun']); ?></td>
            <td><?php echo e($detail['nama_akun']); ?></td>
            <?php if($isFirst): ?>
            <td class="merged" rowspan="<?php echo e($detailCount); ?>"><?php echo e($trans['uraian_kegiatan']); ?></td>
            <td class="text-center merged" rowspan="<?php echo e($detailCount); ?>"><?php echo e(strtoupper($trans['jenis_masuk'] ?? '-')); ?></td>
            <td class="text-center merged" rowspan="<?php echo e($detailCount); ?>"><?php echo e(date('d-M-y', strtotime($trans['tanggal']))); ?></td>
            <?php endif; ?>
            <td class="text-right"><?php echo e(number_format($detail['debet'], 2, ',', '.')); ?></td>
            <td class="text-right"><?php echo e(number_format($detail['kredit'], 2, ',', '.')); ?></td>
        </tr>
            <?php $isFirst = false; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th colspan="6" class="text-right">TOTAL:</th>
            <th class="text-right"><?php echo e(number_format($totalDebet, 2, ',', '.')); ?></th>
            <th class="text-right"><?php echo e(number_format($totalKredit, 2, ',', '.')); ?></th>
        </tr>
        <?php if(abs($totalDebet - $totalKredit) > 0.01): ?>
        <tr>
            <td colspan="8" class="text-center" style="color: red; font-weight: bold;">
                PERHATIAN: Total Debet dan Kredit tidak balance! Selisih: Rp <?php echo e(number_format(abs($totalDebet - $totalKredit), 2, ',', '.')); ?>

            </td>
        </tr>
        <?php endif; ?>
    </table>
</body>
</html>
<?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/export/rupa-rupa.blade.php ENDPATH**/ ?>