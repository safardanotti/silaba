<?php $__env->startSection('title', 'Pengajuan Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="fas fa-file-alt me-2"></i>Pengajuan Pinjaman
            <?php if($countPending > 0): ?>
                <span class="badge bg-danger"><?php echo e($countPending); ?> Pending</span>
            <?php endif; ?>
        </h4>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
                        <option value="diproses" <?php echo e(request('status') == 'diproses' ? 'selected' : ''); ?>>Diproses</option>
                        <option value="disetujui" <?php echo e(request('status') == 'disetujui' ? 'selected' : ''); ?>>Disetujui</option>
                        <option value="ditolak" <?php echo e(request('status') == 'ditolak' ? 'selected' : ''); ?>>Ditolak</option>
                        <option value="dicairkan" <?php echo e(request('status') == 'dicairkan' ? 'selected' : ''); ?>>Dicairkan</option>
                    </select>
                </div>
                <div class="col-md-8">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="<?php echo e(route('admin.pinjaman.pengajuan')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pengajuan</th>
                            <th>Tanggal</th>
                            <th>Anggota</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-center">Tenor</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="<?php echo e($p->status == 'pending' ? 'table-warning' : ''); ?>">
                                <td><strong><?php echo e($p->no_pengajuan); ?></strong></td>
                                <td><?php echo e($p->created_at->format('d/m/Y H:i')); ?></td>
                                <td>
                                    <?php echo e($p->anggota->nama_anggota); ?>

                                    <br><small class="text-muted"><?php echo e($p->anggota->no_anggota); ?></small>
                                </td>
                                <td><?php echo e($p->produkPinjaman->nama_produk); ?></td>
                                <td class="text-end">Rp <?php echo e(number_format($p->jumlah_pinjaman, 0, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($p->tenor); ?> bln</td>
                                <td class="text-center"><?php echo $p->status_label; ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.pinjaman.pengajuan-detail', $p->id)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Proses
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada pengajuan pinjaman
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($pengajuan->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/pinjaman/pengajuan.blade.php ENDPATH**/ ?>