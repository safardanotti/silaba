<?php $__env->startSection('title', 'Pengajuan Pinjaman'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0"><i class="fas fa-file-alt me-2"></i>Pengajuan Pinjaman Saya</h4>
        <a href="<?php echo e(route('anggota.pengajuan.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Ajukan Pinjaman Baru
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pengajuan</th>
                            <th>Tanggal</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-center">Tenor</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $pengajuan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($p->no_pengajuan); ?></strong></td>
                                <td><?php echo e($p->created_at->format('d/m/Y H:i')); ?></td>
                                <td><?php echo e($p->produkPinjaman->nama_produk); ?></td>
                                <td class="text-end currency-display">Rp <?php echo e(number_format($p->jumlah_pinjaman, 0, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($p->tenor); ?> bulan</td>
                                <td class="text-center"><?php echo $p->status_label; ?></td>
                                <td>
                                    <a href="<?php echo e(route('anggota.pengajuan.show', $p->id)); ?>" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-file-alt fa-3x mb-3"></i>
                                        <p>Belum ada pengajuan pinjaman</p>
                                        <a href="<?php echo e(route('anggota.pengajuan.create')); ?>" class="btn btn-success">
                                            <i class="fas fa-plus me-2"></i>Ajukan Pinjaman
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($pengajuan->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/pengajuan/index.blade.php ENDPATH**/ ?>