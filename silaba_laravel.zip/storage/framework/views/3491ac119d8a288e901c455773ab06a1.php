<?php $__env->startSection('title', 'Pinjaman Saya'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0"><i class="fas fa-hand-holding-usd me-2"></i>Pinjaman Saya</h4>
        <a href="<?php echo e(route('anggota.pengajuan.create')); ?>" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Ajukan Pinjaman Baru
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="card mb-3 border-<?php echo e($p->status == 'aktif' ? 'warning' : ($p->status == 'lunas' ? 'success' : 'danger')); ?>">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <span>
                            <strong><?php echo e($p->no_pinjaman); ?></strong>
                            <small class="text-muted ms-2"><?php echo e($p->produkPinjaman->nama_produk); ?></small>
                        </span>
                        <?php echo $p->status_label; ?>

                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-3">
                                <small class="text-muted">Tanggal Pinjaman</small>
                                <p class="mb-0"><?php echo e(\Carbon\Carbon::parse($p->tanggal_pinjaman)->format('d/m/Y')); ?></p>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted">Jumlah Pinjaman</small>
                                <p class="mb-0 currency-display"><strong>Rp <?php echo e(number_format($p->jumlah_pinjaman, 0, ',', '.')); ?></strong></p>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted">Sisa Pokok</small>
                                <p class="mb-0 currency-display text-danger"><strong>Rp <?php echo e(number_format($p->saldo_pokok, 0, ',', '.')); ?></strong></p>
                            </div>
                            <div class="col-md-3">
                                <small class="text-muted">Angsuran/bulan</small>
                                <p class="mb-0 currency-display">Rp <?php echo e(number_format($p->total_angsuran, 0, ',', '.')); ?></p>
                            </div>
                        </div>
                        <hr>
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <div class="progress" style="height: 20px;">
                                    <div class="progress-bar bg-success" style="width: <?php echo e($p->persentase_lunas); ?>%">
                                        <?php echo e($p->persentase_lunas); ?>% Terbayar
                                    </div>
                                </div>
                                <small class="text-muted">Angsuran ke-<?php echo e($p->angsuran_ke); ?> dari <?php echo e($p->tenor); ?> bulan</small>
                            </div>
                            <div class="col-md-4 text-end">
                                <a href="<?php echo e(route('anggota.pinjaman.show', $p->id)); ?>" class="btn btn-info btn-sm">
                                    <i class="fas fa-eye me-1"></i>Lihat Detail
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-hand-holding-usd fa-4x mb-3"></i>
                    <p>Anda belum memiliki pinjaman</p>
                    <a href="<?php echo e(route('anggota.pengajuan.create')); ?>" class="btn btn-success">
                        <i class="fas fa-plus me-2"></i>Ajukan Pinjaman
                    </a>
                </div>
            <?php endif; ?>
            
            <?php echo e($pinjaman->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/pinjaman/index.blade.php ENDPATH**/ ?>