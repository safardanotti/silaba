<?php $__env->startSection('title', 'Detail Anggota'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('admin.anggota.index')); ?>">Manajemen Anggota</a></li>
            <li class="breadcrumb-item active">Detail Anggota</li>
        </ol>
    </nav>

    <div class="row">
        <!-- Profil Anggota -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    <?php if($anggota->foto): ?>
                        <img src="<?php echo e(Storage::url($anggota->foto)); ?>" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
                    <?php else: ?>
                        <img src="https://ui-avatars.com/api/?name=<?php echo e(urlencode($anggota->nama_anggota)); ?>&size=120&background=4caf50&color=fff" class="rounded-circle mb-3">
                    <?php endif; ?>
                    <h5 class="mb-1"><?php echo e($anggota->nama_anggota); ?></h5>
                    <p class="text-muted mb-2"><?php echo e($anggota->no_anggota); ?></p>
                    <?php if($anggota->status_anggota == 'aktif'): ?>
                        <span class="badge bg-success">Aktif</span>
                    <?php elseif($anggota->status_anggota == 'tidak_aktif'): ?>
                        <span class="badge bg-secondary">Tidak Aktif</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Keluar</span>
                    <?php endif; ?>
                </div>
                <div class="card-footer">
                    <a href="<?php echo e(route('admin.anggota.edit', $anggota->id)); ?>" class="btn btn-warning btn-sm w-100">
                        <i class="fas fa-edit me-2"></i>Edit Data
                    </a>
                </div>
            </div>

            <!-- Info Singkat -->
            <div class="card mt-3">
                <div class="card-header"><strong>Informasi</strong></div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <td class="text-muted">NIK</td>
                            <td><?php echo e($anggota->nik ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">TTL</td>
                            <td><?php echo e($anggota->tempat_lahir ?? ''); ?><?php echo e($anggota->tanggal_lahir ? ', ' . $anggota->tanggal_lahir->format('d/m/Y') : '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">No. HP</td>
                            <td><?php echo e($anggota->no_hp ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Email</td>
                            <td><?php echo e($anggota->email ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Unit Kerja</td>
                            <td><?php echo e($anggota->unit_kerja ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Jabatan</td>
                            <td><?php echo e($anggota->jabatan ?? '-'); ?></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tgl Masuk</td>
                            <td><?php echo e($anggota->tanggal_masuk ? $anggota->tanggal_masuk->format('d/m/Y') : '-'); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Akun -->
            <div class="card mt-3">
                <div class="card-header"><strong>Akun Login</strong></div>
                <div class="card-body">
                    <?php if($anggota->user): ?>
                        <p class="mb-2"><i class="fas fa-user me-2"></i>Username: <strong><?php echo e($anggota->user->username); ?></strong></p>
                        <p class="mb-0"><i class="fas fa-circle me-2 <?php echo e($anggota->user->status == 'active' ? 'text-success' : 'text-danger'); ?>"></i>
                            Status: <?php echo e(ucfirst($anggota->user->status)); ?>

                        </p>
                    <?php else: ?>
                        <p class="text-muted mb-3">Belum memiliki akun</p>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalBuatAkun">
                            <i class="fas fa-user-plus me-2"></i>Buat Akun
                        </button>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Data Simpanan & Pinjaman -->
        <div class="col-lg-8">
            <!-- Ringkasan -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h6>Total Simpanan</h6>
                            <h4 class="mb-0">Rp <?php echo e(number_format($anggota->total_simpanan, 0, ',', '.')); ?></h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <h6>Total Pinjaman Aktif</h6>
                            <h4 class="mb-0">Rp <?php echo e(number_format($anggota->total_pinjaman_aktif, 0, ',', '.')); ?></h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#simpanan">
                                <i class="fas fa-piggy-bank me-2"></i>Simpanan
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#pinjaman">
                                <i class="fas fa-hand-holding-usd me-2"></i>Pinjaman
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <!-- Tab Simpanan -->
                        <div class="tab-pane fade show active" id="simpanan">
                            <h6 class="mb-3">Saldo Simpanan</h6>
                            <?php if($anggota->saldoSimpanan->count() > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Jenis Simpanan</th>
                                                <th class="text-end">Saldo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $anggota->saldoSimpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saldo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($saldo->jenisSimpanan->nama_simpanan); ?></td>
                                                    <td class="text-end">Rp <?php echo e(number_format($saldo->total_saldo, 0, ',', '.')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">Belum ada data simpanan</p>
                            <?php endif; ?>

                            <hr>
                            <h6 class="mb-3">Riwayat Transaksi Simpanan</h6>
                            <?php if($anggota->simpanan->count() > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Jenis</th>
                                                <th>Transaksi</th>
                                                <th class="text-end">Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $anggota->simpanan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($s->tanggal_transaksi->format('d/m/Y')); ?></td>
                                                    <td><?php echo e($s->jenisSimpanan->nama_simpanan); ?></td>
                                                    <td>
                                                        <span class="badge <?php echo e($s->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger'); ?>">
                                                            <?php echo e(ucfirst($s->jenis_transaksi)); ?>

                                                        </span>
                                                    </td>
                                                    <td class="text-end">Rp <?php echo e(number_format($s->jumlah, 0, ',', '.')); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <p class="text-muted">Belum ada transaksi simpanan</p>
                            <?php endif; ?>
                        </div>

                        <!-- Tab Pinjaman -->
                        <div class="tab-pane fade" id="pinjaman">
                            <?php if($anggota->pinjaman->count() > 0): ?>
                                <?php $__currentLoopData = $anggota->pinjaman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="card mb-3">
                                        <div class="card-header d-flex justify-content-between">
                                            <span>
                                                <strong><?php echo e($p->no_pinjaman); ?></strong>
                                                <small class="text-muted ms-2"><?php echo e($p->produkPinjaman->nama_produk); ?></small>
                                            </span>
                                            <?php echo $p->status_label; ?>

                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <small class="text-muted">Jumlah Pinjaman</small>
                                                    <p class="mb-0"><strong>Rp <?php echo e(number_format($p->jumlah_pinjaman, 0, ',', '.')); ?></strong></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <small class="text-muted">Sisa Pokok</small>
                                                    <p class="mb-0 text-danger"><strong>Rp <?php echo e(number_format($p->saldo_pokok, 0, ',', '.')); ?></strong></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <small class="text-muted">Progress</small>
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar bg-success" style="width: <?php echo e($p->persentase_lunas); ?>%">
                                                            <?php echo e($p->persentase_lunas); ?>%
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <small class="text-muted">Angsuran: <?php echo e($p->angsuran_ke); ?>/<?php echo e($p->tenor); ?> | Rp <?php echo e(number_format($p->total_angsuran, 0, ',', '.')); ?>/bulan</small>
                                            <br>
                                            <a href="<?php echo e(route('admin.pinjaman.show', $p->id)); ?>" class="btn btn-sm btn-outline-primary mt-2">
                                                <i class="fas fa-eye me-1"></i>Detail Pinjaman
                                            </a>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-muted">Tidak ada data pinjaman</p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Buat Akun -->
<?php if(!$anggota->user): ?>
<div class="modal fade" id="modalBuatAkun" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.anggota.buat-akun', $anggota->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Buat Akun untuk <?php echo e($anggota->nama_anggota); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" 
                               value="<?php echo e(strtolower(str_replace(' ', '', $anggota->nama_anggota)) . $anggota->id); ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" value="password123" required>
                        <small class="text-muted">Default: password123</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Buat Akun</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/anggota/show.blade.php ENDPATH**/ ?>