<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-bell me-2"></i>Notifikasi</h4>
        <?php if($notifikasi->where('dibaca', false)->count() > 0): ?>
            <form action="<?php echo e(route('anggota.notifikasi.baca-semua')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-check-double me-1"></i>Tandai Semua Dibaca
                </button>
            </form>
        <?php endif; ?>
    </div>

    <div class="card">
        <div class="card-body">
            <?php $__empty_1 = true; $__currentLoopData = $notifikasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="d-flex align-items-start border-bottom py-3 <?php echo e(!$n->dibaca ? 'bg-light' : ''); ?>">
                    <div class="flex-shrink-0 me-3">
                        <?php if($n->tipe == 'success'): ?>
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        <?php elseif($n->tipe == 'danger'): ?>
                            <i class="fas fa-times-circle fa-2x text-danger"></i>
                        <?php elseif($n->tipe == 'warning'): ?>
                            <i class="fas fa-exclamation-circle fa-2x text-warning"></i>
                        <?php else: ?>
                            <i class="fas fa-info-circle fa-2x text-info"></i>
                        <?php endif; ?>
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between">
                            <h6 class="mb-1 <?php echo e(!$n->dibaca ? 'fw-bold' : ''); ?>"><?php echo e($n->judul); ?></h6>
                            <small class="text-muted"><?php echo e($n->created_at->diffForHumans()); ?></small>
                        </div>
                        <p class="mb-1 text-muted"><?php echo e($n->pesan); ?></p>
                        <?php if($n->link && !$n->dibaca): ?>
                            <form action="<?php echo e(route('anggota.notifikasi.baca', $n->id)); ?>" method="POST" class="d-inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-outline-primary">Lihat Detail</button>
                            </form>
                        <?php elseif($n->link): ?>
                            <a href="<?php echo e($n->link); ?>" class="btn btn-sm btn-outline-secondary">Lihat Detail</a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-bell-slash fa-4x mb-3"></i>
                    <p>Tidak ada notifikasi</p>
                </div>
            <?php endif; ?>

            <?php echo e($notifikasi->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.anggota', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/anggota/notifikasi.blade.php ENDPATH**/ ?>