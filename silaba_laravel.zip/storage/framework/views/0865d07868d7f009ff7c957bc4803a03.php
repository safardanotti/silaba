<?php $__env->startSection('title', 'Manajemen Anggota'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-users me-2"></i>Manajemen Anggota</h4>
        <div>
            <a href="<?php echo e(route('admin.anggota.pendaftaran')); ?>" class="btn btn-warning me-2">
                <i class="fas fa-user-plus me-2"></i>Pendaftaran Baru
                <?php
                    $countPending = \App\Models\PendaftaranAnggota::pending()->count();
                ?>
                <?php if($countPending > 0): ?>
                    <span class="badge bg-danger"><?php echo e($countPending); ?></span>
                <?php endif; ?>
            </a>
            <a href="<?php echo e(route('admin.anggota.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus me-2"></i>Tambah Anggota
            </a>
        </div>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama/no anggota..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="aktif" <?php echo e(request('status') == 'aktif' ? 'selected' : ''); ?>>Aktif</option>
                        <option value="tidak_aktif" <?php echo e(request('status') == 'tidak_aktif' ? 'selected' : ''); ?>>Tidak Aktif</option>
                        <option value="keluar" <?php echo e(request('status') == 'keluar' ? 'selected' : ''); ?>>Keluar</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="unit_kerja" class="form-select">
                        <option value="">Semua Unit Kerja</option>
                        <?php $__currentLoopData = $unitKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($uk); ?>" <?php echo e(request('unit_kerja') == $uk ? 'selected' : ''); ?>><?php echo e($uk); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="<?php echo e(route('admin.anggota.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Anggota</th>
                            <th>Nama</th>
                            <th>Unit Kerja</th>
                            <th>No. HP</th>
                            <th class="text-center">Pinjaman Aktif</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Akun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $anggota; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><strong><?php echo e($a->no_anggota); ?></strong></td>
                                <td>
                                    <?php echo e($a->nama_anggota); ?>

                                    <br><small class="text-muted"><?php echo e($a->jabatan ?? '-'); ?></small>
                                </td>
                                <td><?php echo e($a->unit_kerja ?? '-'); ?></td>
                                <td><?php echo e($a->no_hp ?? '-'); ?></td>
                                <td class="text-center">
                                    <?php if($a->pinjaman_aktif_count > 0): ?>
                                        <span class="badge bg-warning"><?php echo e($a->pinjaman_aktif_count); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($a->status_anggota == 'aktif'): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php elseif($a->status_anggota == 'tidak_aktif'): ?>
                                        <span class="badge bg-secondary">Tidak Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger">Keluar</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <?php if($a->user): ?>
                                        <span class="badge bg-info"><?php echo e($a->user->username); ?></span>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="<?php echo e(route('admin.anggota.show', $a->id)); ?>" class="btn btn-info" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.anggota.edit', $a->id)); ?>" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-danger" title="Hapus" 
                                                onclick="confirmDelete(<?php echo e($a->id); ?>)">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <form id="deleteForm<?php echo e($a->id); ?>" action="<?php echo e(route('admin.anggota.destroy', $a->id)); ?>" 
                                          method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada data anggota
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            
            <?php echo e($anggota->withQueryString()->links()); ?>

        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
function confirmDelete(id) {
    if (confirm('Apakah Anda yakin ingin menghapus anggota ini?')) {
        document.getElementById('deleteForm' + id).submit();
    }
}
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\ottis\Downloads\Projekku\silaba_laravel\resources\views/admin/anggota/index.blade.php ENDPATH**/ ?>