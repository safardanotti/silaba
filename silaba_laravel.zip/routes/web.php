<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\TransaksiController;
use App\Http\Controllers\LaporanController;
use App\Http\Controllers\SaldoAwalController;
use App\Http\Controllers\ExportController;
use App\Http\Controllers\KasBankController;
use App\Http\Controllers\RekapController;
use App\Http\Controllers\IkhtisarController;
use App\Http\Controllers\PiutangController;
use App\Http\Controllers\LabaRugiController;
use App\Http\Controllers\NeracaController;
use App\Http\Controllers\ManajemenUserController;
use App\Http\Controllers\AnggotaController;
use App\Http\Controllers\PinjamanController;
use App\Http\Controllers\AnggotaAreaController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Auth Routes
Route::get('/', function () {
    return redirect()->route('login');
});

Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
Route::post('/login', [AuthController::class, 'login']);
Route::post('/logout', [AuthController::class, 'logout'])->name('logout');

// =============================================
// AREA ANGGOTA (Member Area)
// =============================================
Route::middleware(['auth', 'anggota'])->prefix('anggota')->name('anggota.')->group(function () {
    // Dashboard Anggota
    Route::get('/dashboard', [AnggotaAreaController::class, 'dashboard'])->name('dashboard');
    
    // Profil
    Route::get('/profil', [AnggotaAreaController::class, 'profil'])->name('profil');
    Route::put('/profil', [AnggotaAreaController::class, 'updateProfil'])->name('profil.update');
    
    // Simpanan
    Route::get('/simpanan', [AnggotaAreaController::class, 'simpanan'])->name('simpanan');
    
    // Pinjaman
    Route::get('/pinjaman', [AnggotaAreaController::class, 'pinjaman'])->name('pinjaman.index');
    Route::get('/pinjaman/{id}', [AnggotaAreaController::class, 'pinjamanShow'])->name('pinjaman.show');
    
    // Pengajuan Pinjaman
    Route::get('/pengajuan', [AnggotaAreaController::class, 'pengajuan'])->name('pengajuan.index');
    Route::get('/pengajuan/create', [AnggotaAreaController::class, 'pengajuanCreate'])->name('pengajuan.create');
    Route::post('/pengajuan', [AnggotaAreaController::class, 'pengajuanStore'])->name('pengajuan.store');
    Route::get('/pengajuan/{id}', [AnggotaAreaController::class, 'pengajuanShow'])->name('pengajuan.show');
    
    // Notifikasi
    Route::get('/notifikasi', [AnggotaAreaController::class, 'notifikasi'])->name('notifikasi');
    Route::post('/notifikasi/{id}/baca', [AnggotaAreaController::class, 'bacaNotifikasi'])->name('notifikasi.baca');
    Route::post('/notifikasi/baca-semua', [AnggotaAreaController::class, 'bacaSemuaNotifikasi'])->name('notifikasi.baca-semua');
    
    // AJAX
    Route::post('/simulasi-pinjaman', [AnggotaAreaController::class, 'simulasiPinjaman'])->name('simulasi-pinjaman');
});

// =============================================
// AREA ADMIN/STAFF (Protected Routes)
// =============================================
Route::middleware(['auth', 'staff'])->group(function () {
    
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    
    // =============================================
    // MASTER DATA (Admin Only)
    // =============================================
    Route::middleware(['admin'])->prefix('admin')->name('admin.')->group(function () {
        // Manajemen User
        Route::get('/manajemen-user', [ManajemenUserController::class, 'index'])->name('manajemen-user.index');
        Route::get('/manajemen-user/create', [ManajemenUserController::class, 'create'])->name('manajemen-user.create');
        Route::post('/manajemen-user', [ManajemenUserController::class, 'store'])->name('manajemen-user.store');
        Route::get('/manajemen-user/{id}/edit', [ManajemenUserController::class, 'edit'])->name('manajemen-user.edit');
        Route::put('/manajemen-user/{id}', [ManajemenUserController::class, 'update'])->name('manajemen-user.update');
        Route::delete('/manajemen-user/{id}', [ManajemenUserController::class, 'destroy'])->name('manajemen-user.destroy');
        Route::post('/manajemen-user/{id}/reset-password', [ManajemenUserController::class, 'resetPassword'])->name('manajemen-user.reset-password');
        
        // Manajemen Anggota
        Route::get('/anggota', [AnggotaController::class, 'index'])->name('anggota.index');
        Route::get('/anggota/create', [AnggotaController::class, 'create'])->name('anggota.create');
        Route::post('/anggota', [AnggotaController::class, 'store'])->name('anggota.store');
        Route::get('/anggota/{id}', [AnggotaController::class, 'show'])->name('anggota.show');
        Route::get('/anggota/{id}/edit', [AnggotaController::class, 'edit'])->name('anggota.edit');
        Route::put('/anggota/{id}', [AnggotaController::class, 'update'])->name('anggota.update');
        Route::delete('/anggota/{id}', [AnggotaController::class, 'destroy'])->name('anggota.destroy');
        Route::post('/anggota/{id}/buat-akun', [AnggotaController::class, 'buatAkun'])->name('anggota.buat-akun');
        
        // Pendaftaran Anggota
        Route::get('/pendaftaran', [AnggotaController::class, 'pendaftaran'])->name('anggota.pendaftaran');
        Route::get('/pendaftaran/{id}', [AnggotaController::class, 'pendaftaranDetail'])->name('anggota.pendaftaran-detail');
        Route::post('/pendaftaran/{id}/approve', [AnggotaController::class, 'approvePendaftaran'])->name('anggota.pendaftaran-approve');
        Route::post('/pendaftaran/{id}/tolak', [AnggotaController::class, 'tolakPendaftaran'])->name('anggota.pendaftaran-tolak');
        
        // Manajemen Pinjaman
        Route::get('/pinjaman', [PinjamanController::class, 'index'])->name('pinjaman.index');
        Route::get('/pinjaman/create', [PinjamanController::class, 'create'])->name('pinjaman.create');
        Route::post('/pinjaman', [PinjamanController::class, 'store'])->name('pinjaman.store');
        Route::get('/pinjaman/{id}', [PinjamanController::class, 'show'])->name('pinjaman.show');
        Route::get('/pinjaman/{pinjamanId}/angsuran/{angsuranId}/bayar', [PinjamanController::class, 'bayarAngsuran'])->name('pinjaman.bayar-angsuran');
        Route::post('/pinjaman/{pinjamanId}/angsuran/{angsuranId}/bayar', [PinjamanController::class, 'prosesBayarAngsuran'])->name('pinjaman.proses-bayar-angsuran');
        
        // Pengajuan Pinjaman
        Route::get('/pengajuan-pinjaman', [PinjamanController::class, 'pengajuan'])->name('pinjaman.pengajuan');
        Route::get('/pengajuan-pinjaman/{id}', [PinjamanController::class, 'pengajuanDetail'])->name('pinjaman.pengajuan-detail');
        Route::post('/pengajuan-pinjaman/{id}/approve', [PinjamanController::class, 'approvePengajuan'])->name('pinjaman.pengajuan-approve');
        Route::post('/pengajuan-pinjaman/{id}/tolak', [PinjamanController::class, 'tolakPengajuan'])->name('pinjaman.pengajuan-tolak');
        Route::post('/pengajuan-pinjaman/{id}/cairkan', [PinjamanController::class, 'cairkan'])->name('pinjaman.cairkan');
        
        // AJAX
        Route::post('/pinjaman/hitung-simulasi', [PinjamanController::class, 'hitungSimulasi'])->name('pinjaman.hitung-simulasi');
    });
    
    // Transaksi (Admin Only)
    Route::middleware(['admin'])->group(function () {
        // Penerimaan
        Route::get('/transaksi/penerimaan', [TransaksiController::class, 'penerimaan'])->name('transaksi.penerimaan');
        Route::post('/transaksi/penerimaan', [TransaksiController::class, 'storePenerimaan'])->name('transaksi.penerimaan.store');
        
        // Pengeluaran
        Route::get('/transaksi/pengeluaran', [TransaksiController::class, 'pengeluaran'])->name('transaksi.pengeluaran');
        Route::post('/transaksi/pengeluaran', [TransaksiController::class, 'storePengeluaran'])->name('transaksi.pengeluaran.store');
        
        // Rupa-rupa
        Route::get('/transaksi/rupa-rupa', [TransaksiController::class, 'rupaRupa'])->name('transaksi.rupa-rupa');
        Route::post('/transaksi/rupa-rupa', [TransaksiController::class, 'storeRupaRupa'])->name('transaksi.rupa-rupa.store');
        
        // Edit & Delete Transaksi
        Route::get('/transaksi/{id}/edit', [TransaksiController::class, 'edit'])->name('transaksi.edit');
        Route::put('/transaksi/{id}', [TransaksiController::class, 'update'])->name('transaksi.update');
        Route::delete('/transaksi/{id}', [TransaksiController::class, 'destroy'])->name('transaksi.destroy');
        
        // Saldo Awal
        Route::get('/saldo-awal', [SaldoAwalController::class, 'index'])->name('saldo-awal.index');
        Route::post('/saldo-awal', [SaldoAwalController::class, 'store'])->name('saldo-awal.store');
        
        // Kas & Bank (Admin Only)
        Route::get('/kas-bank', [KasBankController::class, 'index'])->name('kas-bank.index');
        Route::post('/kas-bank/save-saldo-awal', [KasBankController::class, 'saveSaldoAwal'])->name('kas-bank.save-saldo-awal');
        Route::post('/kas-bank/update-mutasi', [KasBankController::class, 'updateMutasi'])->name('kas-bank.update-mutasi');
        Route::post('/kas-bank/copy-to-next', [KasBankController::class, 'copyToNextMonth'])->name('kas-bank.copy-to-next');
        
        // Piutang (Admin Only for store)
        Route::post('/piutang', [PiutangController::class, 'store'])->name('piutang.store');
        
        // Post Neraca (Admin Only)
        Route::get('/neraca/post', [NeracaController::class, 'post'])->name('neraca.post');
    });
    
    // Laporan Transaksi (All Users)
    Route::get('/laporan/transaksi', [LaporanController::class, 'transaksi'])->name('laporan.transaksi');
    
    // Rekap Per Akun (All Users)
    Route::get('/rekap/akun', [RekapController::class, 'perAkun'])->name('rekap.akun');
    Route::get('/rekap/detail-akun', [RekapController::class, 'detailAkun'])->name('rekap.detail-akun');
    
    // Ikhtisar Jurnal (All Users)
    Route::get('/ikhtisar/jurnal', [IkhtisarController::class, 'jurnal'])->name('ikhtisar.jurnal');
    
    // Piutang (All Users can view)
    Route::get('/piutang', [PiutangController::class, 'index'])->name('piutang.index');
    
    // Laba Rugi (All Users)
    Route::get('/laba-rugi', [LabaRugiController::class, 'index'])->name('laba-rugi.index');
    Route::post('/laba-rugi/anggaran', [LabaRugiController::class, 'storeAnggaran'])->name('laba-rugi.store-anggaran');
    
    // Neraca (All Users)
    Route::get('/neraca', [NeracaController::class, 'index'])->name('neraca.index');
    Route::get('/neraca/mutasi', [NeracaController::class, 'mutasi'])->name('neraca.mutasi');
    
    // Review Neraca (Pimpinan & Admin only)
    Route::middleware(['pimpinan.admin'])->group(function () {
        Route::get('/neraca/review', [NeracaController::class, 'review'])->name('neraca.review');
        Route::get('/neraca/review/{id}', [NeracaController::class, 'reviewDetail'])->name('neraca.review.detail');
        Route::post('/neraca/revisi/{id}', [NeracaController::class, 'requestRevision'])->name('neraca.revisi');
        Route::post('/neraca/approve/{id}', [NeracaController::class, 'approve'])->name('neraca.approve');
    });
    
    // Export Excel (All Users)
    Route::get('/export/penerimaan', [ExportController::class, 'penerimaan'])->name('export.penerimaan');
    Route::get('/export/pengeluaran', [ExportController::class, 'pengeluaran'])->name('export.pengeluaran');
    Route::get('/export/rupa-rupa', [ExportController::class, 'rupaRupa'])->name('export.rupa-rupa');
    Route::get('/export/rekap-akun', [ExportController::class, 'rekapAkun'])->name('export.rekap-akun');
    Route::get('/export/laba-rugi', [ExportController::class, 'labaRugi'])->name('export.laba-rugi');
    Route::get('/export/neraca', [ExportController::class, 'neraca'])->name('export.neraca');
    Route::get('/export/neraca-mutasi', [ExportController::class, 'neracaMutasi'])->name('export.neraca-mutasi');
    Route::get('/export/neraca-approved/{id}', [ExportController::class, 'neracaApproved'])->name('export.neraca-approved');
    
    // AJAX
    Route::get('/ajax/kode-akun', [TransaksiController::class, 'getKodeAkun'])->name('ajax.kode-akun');
});
