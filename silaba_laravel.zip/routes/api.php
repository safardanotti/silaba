<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ApiAnggotaController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| File ini berisi route API untuk aplikasi Flutter
| Tambahkan isi file ini ke routes/api.php yang sudah ada
|
*/

// Public routes
Route::post('/login', [ApiAnggotaController::class, 'login']);

// Protected routes (memerlukan token)
Route::middleware([])->group(function () {
    // Dashboard
    Route::get('/dashboard', [ApiAnggotaController::class, 'dashboard']);
    
    // Profil
    Route::get('/profil', [ApiAnggotaController::class, 'profil']);
    
    // Simpanan
    Route::get('/simpanan', [ApiAnggotaController::class, 'simpanan']);
    
    // Pinjaman
    Route::get('/pinjaman', [ApiAnggotaController::class, 'pinjaman']);
    Route::get('/pinjaman/{id}', [ApiAnggotaController::class, 'pinjamanDetail']);
    
    // Pengajuan
    Route::get('/pengajuan', [ApiAnggotaController::class, 'pengajuan']);
    Route::get('/pengajuan/{id}', [ApiAnggotaController::class, 'pengajuanDetail']);
    Route::post('/pengajuan', [ApiAnggotaController::class, 'storePengajuan']);
    
    // Produk Pinjaman
    Route::get('/produk-pinjaman', [ApiAnggotaController::class, 'produkPinjaman']);
    
    // Simulasi
    Route::post('/simulasi-pinjaman', [ApiAnggotaController::class, 'simulasiPinjaman']);
    
    // Notifikasi
    Route::get('/notifikasi', [ApiAnggotaController::class, 'notifikasi']);
    Route::post('/notifikasi/{id}/baca', [ApiAnggotaController::class, 'bacaNotifikasi']);
    Route::post('/notifikasi/baca-semua', [ApiAnggotaController::class, 'bacaSemuaNotifikasi']);
});
