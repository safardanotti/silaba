@extends('layouts.app')

@section('title', 'Rekap Per Kode Akun')
@section('page-title', 'Rekap Per Kode Akun')

@push('styles')
<style>
    .table-rekap {
        font-size: 14px;
    }
    .table-rekap th {
        background-color: #f8f9fa;
        position: sticky;
        top: 0;
        z-index: 10;
    }
    .total-row {
        background-color: #e9ecef;
        font-weight: bold;
    }
    .filter-card {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .summary-card {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        color: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
    }
    .tipe-aktiva { background-color: #d4edda; }
    .tipe-passiva { background-color: #cce5ff; }
    .tipe-pendapatan { background-color: #fff3cd; }
    .tipe-biaya { background-color: #f8d7da; }
</style>
@endpush

@section('content')
<!-- Filter Card -->
<div class="filter-card">
    <form method="GET" action="" class="row g-3">
        <div class="col-md-4">
            <label class="form-label">Jenis Transaksi:</label>
            <select name="jenis" class="form-select" onchange="this.form.submit()">
                <option value="semua" {{ $jenis == 'semua' ? 'selected' : '' }}>Semua Transaksi</option>
                <option value="penerimaan" {{ $jenis == 'penerimaan' ? 'selected' : '' }}>Penerimaan</option>
                <option value="pengeluaran" {{ $jenis == 'pengeluaran' ? 'selected' : '' }}>Pengeluaran</option>
                <option value="rupa_rupa" {{ $jenis == 'rupa_rupa' ? 'selected' : '' }}>Rupa-rupa</option>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label">Periode:</label>
            <div class="input-group">
                <input type="month" name="periode" id="periode" class="form-control" 
                       value="{{ $periode == 'semua' ? '' : $periode }}" 
                       onchange="this.form.submit()">
                <button type="button" class="btn btn-outline-secondary" 
                        onclick="clearPeriode()" 
                        title="Tampilkan Semua Periode">
                    <i class="fas fa-times"></i> Semua
                </button>
            </div>
            <small class="text-muted">Kosongkan untuk melihat semua periode</small>
        </div>
        <div class="col-md-4">
            <label class="form-label">&nbsp;</label>
            <div>
                <a href="{{ route('export.rekap-akun', ['jenis' => $jenis, 'periode' => $periode]) }}" 
                   class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <button type="button" class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </div>
    </form>
</div>

<!-- Summary Card -->
<div class="summary-card">
    <div class="row">
        <div class="col-md-4">
            <h5>Total Debet</h5>
            <h3>Rp {{ number_format($grandTotalDebet, 2, ',', '.') }}</h3>
        </div>
        <div class="col-md-4">
            <h5>Total Kredit</h5>
            <h3>Rp {{ number_format($grandTotalKredit, 2, ',', '.') }}</h3>
        </div>
        <div class="col-md-4">
            <h5>Selisih</h5>
            <h3>Rp {{ number_format(abs($grandTotalDebet - $grandTotalKredit), 2, ',', '.') }}</h3>
        </div>
    </div>
</div>

<!-- Data Table -->
<div class="card">
    <div class="card-header">
        <h3>
            <i class="fas fa-calculator me-2"></i>
            Rekap 
            @if($jenis == 'penerimaan') Penerimaan
            @elseif($jenis == 'pengeluaran') Pengeluaran
            @elseif($jenis == 'rupa_rupa') Rupa-rupa
            @else Semua Transaksi
            @endif
            
            @if($periode != 'semua')
                @php
                    $bulanPeriode = substr($periode, 5, 2);
                    $tahunPeriode = substr($periode, 0, 4);
                @endphp
                - {{ $bulanNama[$bulanPeriode] ?? '' }} {{ $tahunPeriode }}
            @endif
        </h3>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-hover table-rekap" id="tableRekap">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="10%">Kode Akun</th>
                        <th width="30%">Nama Akun</th>
                        <th width="10%">Tipe Akun</th>
                        <th width="15%" class="text-end">Total Debet</th>
                        <th width="15%" class="text-end">Total Kredit</th>
                        <th width="10%" class="text-center">Jumlah Transaksi</th>
                        <th width="5%" class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($data as $index => $row)
                        @php
                            $rowClass = '';
                            if ($row->tipe_akun == 'aktiva') $rowClass = 'tipe-aktiva';
                            elseif ($row->tipe_akun == 'passiva') $rowClass = 'tipe-passiva';
                            elseif ($row->tipe_akun == 'pendapatan') $rowClass = 'tipe-pendapatan';
                            elseif ($row->tipe_akun == 'biaya') $rowClass = 'tipe-biaya';
                        @endphp
                        <tr class="{{ $rowClass }}">
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center"><strong>{{ $row->kode_akun }}</strong></td>
                            <td>{{ $row->nama_akun }}</td>
                            <td class="text-center">
                                <span class="badge bg-{{ $row->tipe_akun == 'aktiva' ? 'success' : ($row->tipe_akun == 'passiva' ? 'primary' : ($row->tipe_akun == 'pendapatan' ? 'warning' : 'danger')) }}">
                                    {{ ucfirst($row->tipe_akun) }}
                                </span>
                            </td>
                            <td class="text-end">{{ number_format($row->total_debet, 2, ',', '.') }}</td>
                            <td class="text-end">{{ number_format($row->total_kredit, 2, ',', '.') }}</td>
                            <td class="text-center">{{ $row->jumlah_transaksi }}</td>
                            <td class="text-center">
                                <a href="{{ route('rekap.detail-akun', ['kode' => $row->kode_akun, 'jenis' => $jenis, 'periode' => $periode]) }}" 
                                   class="btn btn-sm btn-info" title="Lihat Detail">
                                    <i class="fas fa-eye"></i>
                                </a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada data transaksi</td>
                        </tr>
                    @endforelse
                </tbody>
                @if(count($data) > 0)
                <tfoot>
                    <tr class="total-row">
                        <td colspan="4" class="text-end"><strong>GRAND TOTAL:</strong></td>
                        <td class="text-end"><strong>{{ number_format($grandTotalDebet, 2, ',', '.') }}</strong></td>
                        <td class="text-end"><strong>{{ number_format($grandTotalKredit, 2, ',', '.') }}</strong></td>
                        <td colspan="2"></td>
                    </tr>
                </tfoot>
                @endif
            </table>
        </div>
    </div>
</div>

<div class="mt-3">
    <a href="{{ route('laporan.transaksi') }}" class="btn btn-secondary">
        <i class="fas fa-arrow-left"></i> Kembali ke Laporan Transaksi
    </a>
</div>
@endsection

@push('scripts')
<script>
function clearPeriode() {
    document.getElementById('periode').value = '';
    const form = document.getElementById('periode').closest('form');
    form.submit();
}
</script>
@endpush
