@extends('layouts.app')

@section('title', 'Detail Kode Akun')
@section('page-title', 'Detail Kode Akun')

@push('styles')
<style>
    @media print {
        .no-print { display: none !important; }
        .card { border: none !important; }
        .main-content { margin-left: 0 !important; }
    }
</style>
@endpush

@section('content')
<!-- Account Info Card -->
<div class="card mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <h4>{{ $akunInfo->kode_akun }} - {{ $akunInfo->nama_akun }}</h4>
                <span class="badge bg-{{ $akunInfo->tipe_akun == 'aktiva' ? 'success' : ($akunInfo->tipe_akun == 'passiva' ? 'primary' : ($akunInfo->tipe_akun == 'pendapatan' ? 'warning' : 'danger')) }}">
                    {{ ucfirst($akunInfo->tipe_akun) }}
                </span>
            </div>
            <div class="col-md-6 text-end">
                <p class="mb-1">Total Debet: <strong>Rp {{ number_format($totalDebet, 2, ',', '.') }}</strong></p>
                <p class="mb-1">Total Kredit: <strong>Rp {{ number_format($totalKredit, 2, ',', '.') }}</strong></p>
                <p class="mb-0">Saldo: <strong>Rp {{ number_format(abs($totalDebet - $totalKredit), 2, ',', '.') }}</strong></p>
            </div>
        </div>
    </div>
</div>

<!-- Transactions Table -->
<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h3><i class="fas fa-file-alt me-2"></i>Detail Transaksi</h3>
                @if($periode != 'semua')
                    @php
                        $bulanPeriode = substr($periode, 5, 2);
                        $tahunPeriode = substr($periode, 0, 4);
                    @endphp
                    <small>{{ $bulanNama[$bulanPeriode] ?? '' }} {{ $tahunPeriode }}</small>
                @endif
            </div>
            <div class="col-md-6 text-end no-print">
                <button class="btn btn-primary" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
                <a href="{{ route('rekap.akun', ['jenis' => $jenis, 'periode' => $periode]) }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th width="5%">No</th>
                        <th width="10%">Tanggal</th>
                        <th width="10%">Jenis</th>
                        <th width="35%">Uraian Kegiatan</th>
                        <th width="10%">Kas/Bank</th>
                        <th width="12%">Debet</th>
                        <th width="12%">Kredit</th>
                        <th width="6%" class="no-print">Input By</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $index => $trans)
                        @php
                            $jenisLabel = [
                                'penerimaan' => '<span class="badge bg-success">Penerimaan</span>',
                                'pengeluaran' => '<span class="badge bg-danger">Pengeluaran</span>',
                                'rupa_rupa' => '<span class="badge bg-info">Rupa-rupa</span>'
                            ];
                        @endphp
                        <tr>
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center">{{ \Carbon\Carbon::parse($trans->tanggal)->format('d/m/Y') }}</td>
                            <td class="text-center">{!! $jenisLabel[$trans->jenis_transaksi] ?? '-' !!}</td>
                            <td>{{ $trans->uraian_kegiatan }}</td>
                            <td class="text-center">
                                <span class="badge bg-secondary">{{ strtoupper($trans->jenis_masuk) }}</span>
                            </td>
                            <td class="text-end">{{ number_format($trans->debet, 2, ',', '.') }}</td>
                            <td class="text-end">{{ number_format($trans->kredit, 2, ',', '.') }}</td>
                            <td class="no-print">{{ $trans->full_name }}</td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center">Tidak ada transaksi</td>
                        </tr>
                    @endforelse
                </tbody>
                <tfoot>
                    <tr class="table-secondary">
                        <th colspan="5" class="text-end">TOTAL:</th>
                        <th class="text-end">{{ number_format($totalDebet, 2, ',', '.') }}</th>
                        <th class="text-end">{{ number_format($totalKredit, 2, ',', '.') }}</th>
                        <th class="no-print"></th>
                    </tr>
                </tfoot>
            </table>
        </div>
    </div>
</div>
@endsection
