@extends('layouts.app')

@section('title', 'Kas & Bank')
@section('page-title', 'Kas & Bank')

@push('styles')
<style>
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
        font-size: 0.85rem;
    }
    .kas-bank-table th {
        background-color: #0066cc !important;
        color: white !important;
        text-align: center;
        vertical-align: middle;
    }
    .text-right {
        text-align: right;
    }
    .total-row {
        font-weight: bold;
        background-color: #f0f0f0;
    }
    .total-row td {
        font-family: 'Courier New', monospace;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
@endpush

@section('content')
<!-- Filter Section -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="bulan" class="form-select" onchange="this.form.submit()">
                    @foreach($bulanNama as $key => $value)
                        <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>
                            {{ $value }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="{{ $tahun }}" 
                       min="2020" max="2030" onchange="this.form.submit()">
            </div>
        </form>
    </div>
</div>

<!-- Data Kas & Bank -->
<div class="card">
    <div class="card-header bg-primary text-white">
        <h5 class="mb-0">
            <i class="fas fa-money-bill-wave me-2"></i>
            Data Kas & Bank - {{ $bulanNama[$bulan] }} {{ $tahun }}
        </h5>
    </div>
    <div class="card-body">
        <form method="POST" id="formKasBank">
            @csrf
            <input type="hidden" name="periode" value="{{ $periode }}">
            
            <div class="table-responsive">
                <table class="table table-bordered kas-bank-table">
                    <thead>
                        <tr>
                            <th rowspan="2" style="width: 50px;">No</th>
                            <th rowspan="2">Nama</th>
                            <th rowspan="2">Saldo Awal (Rp)</th>
                            <th colspan="2">Mutasi</th>
                            <th rowspan="2">Saldo Akhir (Rp)</th>
                            <th rowspan="2" class="no-print">Aksi</th>
                        </tr>
                        <tr>
                            <th>Debet (Rp)</th>
                            <th>Kredit (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- KAS -->
                        <tr>
                            <td class="text-center">1</td>
                            <td>KAS</td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="saldo_awal_kas" class="form-control currency-input" 
                                           value="{{ number_format($kasData['saldo_awal'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="mutasi_debet_kas" class="form-control currency-input" 
                                           value="{{ number_format($kasData['mutasi_debet'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="mutasi_kredit_kas" class="form-control currency-input" 
                                           value="{{ number_format($kasData['mutasi_kredit'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td class="text-right currency-display" id="saldo_akhir_kas">
                                Rp {{ number_format($kasData['saldo_akhir'], 0, ',', '.') }}
                            </td>
                            <td rowspan="2" class="text-center no-print" style="vertical-align: middle;">
                                <button type="submit" formaction="{{ route('kas-bank.save-saldo-awal') }}" 
                                        class="btn btn-sm btn-success mb-1">
                                    <i class="fas fa-save"></i> Simpan Saldo Awal
                                </button>
                                <br>
                                <button type="submit" formaction="{{ route('kas-bank.update-mutasi') }}" 
                                        class="btn btn-sm btn-primary">
                                    <i class="fas fa-sync"></i> Update Mutasi
                                </button>
                            </td>
                        </tr>
                        
                        <!-- BANK -->
                        <tr>
                            <td class="text-center">2</td>
                            <td>BANK</td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="saldo_awal_bank" class="form-control currency-input" 
                                           value="{{ number_format($bankData['saldo_awal'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="mutasi_debet_bank" class="form-control currency-input" 
                                           value="{{ number_format($bankData['mutasi_debet'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="mutasi_kredit_bank" class="form-control currency-input" 
                                           value="{{ number_format($bankData['mutasi_kredit'], 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this); calculateSaldoAkhir();"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td class="text-right currency-display" id="saldo_akhir_bank">
                                Rp {{ number_format($bankData['saldo_akhir'], 0, ',', '.') }}
                            </td>
                        </tr>
                        
                        <!-- TOTAL -->
                        <tr class="total-row">
                            <td colspan="2" class="text-center"><strong>TOTAL</strong></td>
                            <td class="text-right" id="total_saldo_awal">
                                <strong>Rp {{ number_format($kasData['saldo_awal'] + $bankData['saldo_awal'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-right" id="total_mutasi_debet">
                                <strong>Rp {{ number_format($kasData['mutasi_debet'] + $bankData['mutasi_debet'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-right" id="total_mutasi_kredit">
                                <strong>Rp {{ number_format($kasData['mutasi_kredit'] + $bankData['mutasi_kredit'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-right" id="total_saldo_akhir">
                                <strong>Rp {{ number_format($kasData['saldo_akhir'] + $bankData['saldo_akhir'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="no-print"></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </form>
        
        <div class="mt-3 no-print">
            <form action="{{ route('kas-bank.copy-to-next') }}" method="POST" style="display: inline;">
                @csrf
                <input type="hidden" name="periode" value="{{ $periode }}">
                <button type="submit" class="btn btn-warning" 
                        onclick="return confirm('Copy saldo akhir ke bulan berikutnya?')">
                    <i class="fas fa-copy"></i> Copy Saldo Akhir ke Bulan Berikutnya
                </button>
            </form>
            <button type="button" class="btn btn-info" onclick="window.print()">
                <i class="fas fa-print"></i> Cetak
            </button>
        </div>
        
        <div class="alert alert-info mt-3">
            <strong>Catatan:</strong>
            <ul class="mb-0">
                <li>Input saldo awal untuk periode ini, kemudian klik "Simpan Saldo Awal"</li>
                <li>Input mutasi debet dan kredit, kemudian klik "Update Mutasi"</li>
                <li>Saldo akhir akan dihitung otomatis: Saldo Awal + Mutasi Debet - Mutasi Kredit</li>
                <li>Gunakan tombol "Copy Saldo Akhir" untuk menjadikan saldo akhir sebagai saldo awal bulan berikutnya</li>
            </ul>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

// Calculate saldo akhir
function calculateSaldoAkhir() {
    // KAS
    const saldoAwalKas = parseRupiah(document.querySelector('input[name="saldo_awal_kas"]').value);
    const mutasiDebetKas = parseRupiah(document.querySelector('input[name="mutasi_debet_kas"]').value);
    const mutasiKreditKas = parseRupiah(document.querySelector('input[name="mutasi_kredit_kas"]').value);
    const saldoAkhirKas = saldoAwalKas + mutasiDebetKas - mutasiKreditKas;
    
    // BANK
    const saldoAwalBank = parseRupiah(document.querySelector('input[name="saldo_awal_bank"]').value);
    const mutasiDebetBank = parseRupiah(document.querySelector('input[name="mutasi_debet_bank"]').value);
    const mutasiKreditBank = parseRupiah(document.querySelector('input[name="mutasi_kredit_bank"]').value);
    const saldoAkhirBank = saldoAwalBank + mutasiDebetBank - mutasiKreditBank;
    
    // Update display
    document.getElementById('saldo_akhir_kas').textContent = 'Rp ' + formatRupiah(saldoAkhirKas);
    document.getElementById('saldo_akhir_bank').textContent = 'Rp ' + formatRupiah(saldoAkhirBank);
    
    // Update totals
    document.getElementById('total_saldo_awal').innerHTML = '<strong>Rp ' + formatRupiah(saldoAwalKas + saldoAwalBank) + '</strong>';
    document.getElementById('total_mutasi_debet').innerHTML = '<strong>Rp ' + formatRupiah(mutasiDebetKas + mutasiDebetBank) + '</strong>';
    document.getElementById('total_mutasi_kredit').innerHTML = '<strong>Rp ' + formatRupiah(mutasiKreditKas + mutasiKreditBank) + '</strong>';
    document.getElementById('total_saldo_akhir').innerHTML = '<strong>Rp ' + formatRupiah(saldoAkhirKas + saldoAkhirBank) + '</strong>';
}
</script>
@endpush
