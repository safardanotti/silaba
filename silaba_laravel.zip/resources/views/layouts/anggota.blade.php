<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Portal Anggota') - SIKOPKAR</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    
    <style>
        :root {
            --primary-color: #2e7d32;
            --primary-dark: #1b5e20;
            --primary-light: #4caf50;
            --sidebar-width: 260px;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
        }
        
        /* Navbar */
        .navbar-anggota {
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .navbar-anggota .navbar-brand {
            font-weight: 700;
            color: white !important;
        }
        
        /* Sidebar */
        .sidebar-anggota {
            position: fixed;
            top: 56px;
            left: 0;
            width: var(--sidebar-width);
            height: calc(100vh - 56px);
            background: white;
            box-shadow: 2px 0 10px rgba(0,0,0,0.05);
            overflow-y: auto;
            z-index: 100;
            transition: transform 0.3s ease;
        }
        
        .sidebar-anggota .nav-link {
            color: #333;
            padding: 12px 20px;
            border-left: 3px solid transparent;
            transition: all 0.2s;
        }
        
        .sidebar-anggota .nav-link:hover,
        .sidebar-anggota .nav-link.active {
            background-color: #e8f5e9;
            color: var(--primary-color);
            border-left-color: var(--primary-color);
        }
        
        .sidebar-anggota .nav-link i {
            width: 24px;
            margin-right: 10px;
        }
        
        .sidebar-anggota .user-info {
            padding: 20px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white;
        }
        
        .sidebar-anggota .user-info img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            border: 3px solid rgba(255,255,255,0.3);
            object-fit: cover;
        }
        
        /* Main Content */
        .main-content-anggota {
            margin-left: var(--sidebar-width);
            padding: 20px;
            min-height: calc(100vh - 56px);
            margin-top: 56px;
        }
        
        /* Cards */
        .stat-card {
            border: none;
            border-radius: 15px;
            box-shadow: 0 2px 15px rgba(0,0,0,0.08);
            transition: transform 0.2s;
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
        }
        
        .stat-card .icon-box {
            width: 60px;
            height: 60px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }
        
        .stat-card.simpanan .icon-box { background: linear-gradient(135deg, #4caf50, #2e7d32); }
        .stat-card.pinjaman .icon-box { background: linear-gradient(135deg, #ff9800, #f57c00); }
        .stat-card.angsuran .icon-box { background: linear-gradient(135deg, #2196f3, #1565c0); }
        
        .currency-display {
            font-family: 'Courier New', monospace;
            font-weight: 600;
        }
        
        /* Badge Notification */
        .badge-notif {
            position: absolute;
            top: -5px;
            right: -5px;
            font-size: 10px;
            padding: 3px 6px;
        }
        
        /* Responsive */
        @media (max-width: 991px) {
            .sidebar-anggota {
                transform: translateX(-100%);
            }
            
            .sidebar-anggota.show {
                transform: translateX(0);
            }
            
            .main-content-anggota {
                margin-left: 0;
            }
        }
        
        @stack('styles')
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark navbar-anggota fixed-top">
        <div class="container-fluid">
            <button class="btn btn-link text-white d-lg-none me-2" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand" href="{{ route('anggota.dashboard') }}">
                <i class="fas fa-users me-2"></i>SIKOPKAR
            </a>
            
            <div class="d-flex align-items-center">
                <!-- Notification -->
                <div class="dropdown me-3">
                    <a href="#" class="text-white position-relative" data-bs-toggle="dropdown">
                        <i class="fas fa-bell fa-lg"></i>
                        @php
                            $notifCount = auth()->user()->notifikasiBelumDibaca()->count();
                        @endphp
                        @if($notifCount > 0)
                            <span class="badge bg-danger badge-notif">{{ $notifCount }}</span>
                        @endif
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" style="width: 300px; max-height: 400px; overflow-y: auto;">
                        <li class="dropdown-header d-flex justify-content-between align-items-center">
                            <span>Notifikasi</span>
                            @if($notifCount > 0)
                                <form action="{{ route('anggota.notifikasi.baca-semua') }}" method="POST" style="display: inline;">
                                    @csrf
                                    <button type="submit" class="btn btn-link btn-sm p-0">Tandai Semua Dibaca</button>
                                </form>
                            @endif
                        </li>
                        <li><hr class="dropdown-divider"></li>
                        @forelse(auth()->user()->notifikasiBelumDibaca()->limit(5)->get() as $notif)
                            <li>
                                <a class="dropdown-item" href="{{ route('anggota.notifikasi.baca', $notif->id) }}">
                                    <small class="text-muted">{{ $notif->created_at->diffForHumans() }}</small>
                                    <div class="fw-bold">{{ $notif->judul }}</div>
                                    <small>{{ Str::limit($notif->pesan, 50) }}</small>
                                </a>
                            </li>
                        @empty
                            <li><span class="dropdown-item text-muted">Tidak ada notifikasi baru</span></li>
                        @endforelse
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-center" href="{{ route('anggota.notifikasi') }}">Lihat Semua</a></li>
                    </ul>
                </div>
                
                <!-- User Dropdown -->
                <div class="dropdown">
                    <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle" data-bs-toggle="dropdown">
                        <span class="d-none d-md-inline me-2">{{ auth()->user()->full_name }}</span>
                        <i class="fas fa-user-circle fa-lg"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="{{ route('anggota.profil') }}"><i class="fas fa-user me-2"></i>Profil</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li>
                            <form action="{{ route('logout') }}" method="POST">
                                @csrf
                                <button type="submit" class="dropdown-item text-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                                </button>
                            </form>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Sidebar -->
    <aside class="sidebar-anggota" id="sidebar">
        <div class="user-info text-center">
            @php $anggota = auth()->user()->anggota; @endphp
            @if($anggota && $anggota->foto)
                <img src="{{ Storage::url($anggota->foto) }}" alt="Foto">
            @else
                <img src="https://ui-avatars.com/api/?name={{ urlencode(auth()->user()->full_name) }}&background=4caf50&color=fff&size=60" alt="Avatar">
            @endif
            <h6 class="mt-2 mb-0">{{ auth()->user()->full_name }}</h6>
            <small>{{ $anggota->no_anggota ?? '-' }}</small>
        </div>
        
        <nav class="nav flex-column mt-3">
            <a class="nav-link {{ request()->routeIs('anggota.dashboard') ? 'active' : '' }}" href="{{ route('anggota.dashboard') }}">
                <i class="fas fa-home"></i> Dashboard
            </a>
            <a class="nav-link {{ request()->routeIs('anggota.simpanan') ? 'active' : '' }}" href="{{ route('anggota.simpanan') }}">
                <i class="fas fa-piggy-bank"></i> Simpanan Saya
            </a>
            <a class="nav-link {{ request()->routeIs('anggota.pinjaman.*') ? 'active' : '' }}" href="{{ route('anggota.pinjaman.index') }}">
                <i class="fas fa-hand-holding-usd"></i> Pinjaman Saya
            </a>
            <a class="nav-link {{ request()->routeIs('anggota.pengajuan.*') ? 'active' : '' }}" href="{{ route('anggota.pengajuan.index') }}">
                <i class="fas fa-file-alt"></i> Pengajuan Pinjaman
            </a>
            <a class="nav-link {{ request()->routeIs('anggota.notifikasi') ? 'active' : '' }}" href="{{ route('anggota.notifikasi') }}">
                <i class="fas fa-bell"></i> Notifikasi
                @if($notifCount > 0)
                    <span class="badge bg-danger ms-2">{{ $notifCount }}</span>
                @endif
            </a>
            <hr class="mx-3">
            <a class="nav-link {{ request()->routeIs('anggota.profil') ? 'active' : '' }}" href="{{ route('anggota.profil') }}">
                <i class="fas fa-user-cog"></i> Profil Saya
            </a>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content-anggota">
        @if(session('success'))
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>{{ session('success') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-circle me-2"></i>{{ session('error') }}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        @endif
        
        @yield('content')
    </main>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Sidebar Toggle for Mobile
        document.getElementById('sidebarToggle')?.addEventListener('click', function() {
            document.getElementById('sidebar').classList.toggle('show');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.getElementById('sidebarToggle');
            
            if (window.innerWidth < 992 && sidebar.classList.contains('show')) {
                if (!sidebar.contains(e.target) && !toggle.contains(e.target)) {
                    sidebar.classList.remove('show');
                }
            }
        });
    </script>
    
    @stack('scripts')
</body>
</html>
