<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'SILABA') - Sistem Informasi Laporan Laba</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            --primary-color: #28a745;
            --secondary-color: #6c757d;
            --danger-color: #dc3545;
            --warning-color: #ffc107;
            --info-color: #17a2b8;
            --dark-color: #343a40;
            --light-color: #f8f9fa;
            --sidebar-width: 250px;
            --sidebar-collapsed-width: 60px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f6f9;
            color: #333;
            overflow-x: hidden;
        }

        /* Sidebar Styles */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background-color: var(--dark-color);
            transition: all 0.3s ease;
            z-index: 1050;
            overflow-x: hidden;
            overflow-y: auto;
        }

        .sidebar.collapsed {
            width: var(--sidebar-collapsed-width);
        }

        .sidebar-header {
            padding: 20px;
            background-color: rgba(0,0,0,0.2);
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }

        .sidebar-header h3 {
            color: white;
            margin: 0;
            font-size: 1.5rem;
            white-space: nowrap;
        }

        .sidebar.collapsed .sidebar-header h3 {
            display: none;
        }

        .sidebar-toggle-main {
            position: fixed;
            left: var(--sidebar-width);
            top: 0;
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 20px 15px;
            cursor: pointer;
            border-radius: 0;
            transition: all 0.3s ease;
            font-size: 20px;
            z-index: 1051;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            height: 60px;
            width: 60px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .sidebar.collapsed ~ .sidebar-toggle-main,
        .sidebar-toggle-main.collapsed {
            left: var(--sidebar-collapsed-width);
        }

        .sidebar-toggle-main:hover {
            background-color: #218838;
        }

        .sidebar-menu {
            list-style: none;
            padding: 20px 0;
        }

        .sidebar-menu li {
            margin-bottom: 5px;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            white-space: nowrap;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255,255,255,0.1);
            color: white;
        }

        .sidebar-menu a.active {
            background-color: var(--primary-color);
            color: white;
        }

        .sidebar-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .sidebar.collapsed .sidebar-menu span {
            display: none;
        }

        .sidebar.collapsed .sidebar-menu i {
            margin-right: 0;
        }

        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
            transition: margin-left 0.3s ease;
            min-height: 100vh;
        }

        .main-content.expanded {
            margin-left: var(--sidebar-collapsed-width);
        }

        /* Top Bar */
        .topbar {
            background-color: white;
            padding: 15px 30px;
            margin-bottom: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 10px;
        }

        .topbar h1 {
            font-size: 1.8rem;
            color: var(--dark-color);
            margin: 0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }

        /* Cards */
        .card {
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            border: none;
        }

        .card:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .card-header {
            border-bottom: 2px solid #f0f0f0;
            padding: 15px 25px;
            background: transparent;
        }

        .card-header h3, .card-header h5 {
            margin: 0;
            color: var(--dark-color);
        }

        .card-body {
            padding: 25px;
        }

        /* Dashboard Stats */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: linear-gradient(135deg, var(--primary-color) 0%, #20c997 100%);
            color: white;
            padding: 25px;
            border-radius: 10px;
            position: relative;
            overflow: hidden;
        }

        .stat-card.danger {
            background: linear-gradient(135deg, var(--danger-color) 0%, #e74c3c 100%);
        }

        .stat-card.warning {
            background: linear-gradient(135deg, var(--warning-color) 0%, #f39c12 100%);
        }

        .stat-card.info {
            background: linear-gradient(135deg, var(--info-color) 0%, #3498db 100%);
        }

        .stat-card h4 {
            margin: 0 0 10px 0;
            font-size: 0.9rem;
            opacity: 0.9;
        }

        .stat-card h2 {
            margin: 0;
            font-size: 1.8rem;
        }

        .stat-card i.stat-icon {
            position: absolute;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 3rem;
            opacity: 0.3;
        }

        /* Filter Section */
        .filter-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            color: white;
        }

        .filter-section label {
            color: white;
            font-weight: 500;
        }

        .period-info {
            background-color: rgba(255, 255, 255, 0.2);
            padding: 10px 20px;
            border-radius: 25px;
            display: inline-block;
        }

        /* Tables */
        .table-container {
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
        }

        .table th,
        .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #f0f0f0;
        }

        .table th {
            background-color: #f8f9fa;
            font-weight: 600;
            color: var(--dark-color);
            white-space: nowrap;
        }

        .table tr:hover {
            background-color: #f8f9fa;
        }

        /* Alert Messages */
        .alert {
            padding: 15px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        /* Buttons */
        .btn-primary {
            background-color: var(--primary-color);
            border-color: var(--primary-color);
        }

        .btn-primary:hover {
            background-color: #218838;
            border-color: #218838;
        }

        /* Mobile Overlay */
        .sidebar-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            z-index: 1040;
        }

        .sidebar-overlay.show {
            display: block;
        }

        /* ================================
           MOBILE RESPONSIVE STYLES
           ================================ */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                width: var(--sidebar-width);
            }
            
            .sidebar.show {
                transform: translateX(0);
            }
            
            .sidebar.collapsed {
                width: var(--sidebar-width);
                transform: translateX(-100%);
            }
            
            .sidebar.collapsed.show {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0 !important;
                padding: 15px;
            }
            
            .main-content.expanded {
                margin-left: 0 !important;
            }
            
            .sidebar-toggle-main {
                left: 0 !important;
                position: fixed;
                border-radius: 0 5px 5px 0;
            }
            
            .sidebar-toggle-main.collapsed {
                left: 0 !important;
            }
            
            .topbar {
                padding: 15px;
                margin-top: 50px;
                flex-direction: column;
                align-items: flex-start;
            }
            
            .topbar h1 {
                font-size: 1.4rem;
            }
            
            .stats-container {
                grid-template-columns: 1fr;
            }
            
            .stat-card h2 {
                font-size: 1.4rem;
            }
            
            .filter-section {
                padding: 15px;
            }
            
            .filter-section .row {
                flex-direction: column;
            }
            
            .filter-section .col-md-3,
            .filter-section .col-md-4,
            .filter-section .col-md-6 {
                width: 100%;
                margin-bottom: 10px;
            }
            
            .card-body {
                padding: 15px;
            }
            
            .card-header {
                padding: 12px 15px;
            }
        }

        @media (max-width: 576px) {
            .topbar h1 {
                font-size: 1.2rem;
            }
            
            .user-info {
                font-size: 0.85rem;
            }
            
            .stat-card {
                padding: 15px;
            }
            
            .stat-card h4 {
                font-size: 0.8rem;
            }
            
            .stat-card h2 {
                font-size: 1.2rem;
            }
            
            .stat-card i.stat-icon {
                font-size: 2rem;
                right: 10px;
            }
            
            .btn {
                padding: 8px 12px;
                font-size: 0.85rem;
            }
            
            .table th,
            .table td {
                padding: 8px 10px;
                font-size: 0.85rem;
            }
        }

        /* Utility Classes */
        .text-right { text-align: right; }
    </style>
    @stack('styles')
</head>
<body>
    <!-- Sidebar Overlay for Mobile -->
    <div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>
    
    @include('partials.sidebar')
    
    <button class="sidebar-toggle-main" id="sidebarToggle" onclick="toggleSidebar()">
        <i class="fas fa-bars"></i>
    </button>
    
    <div class="main-content" id="mainContent">
        <div class="topbar">
            <h1>@yield('page-title', 'Dashboard')</h1>
            <div class="user-info">
                <span class="badge bg-{{ auth()->user()->role == 'admin' ? 'primary' : 'secondary' }}">
                    {{ ucfirst(auth()->user()->role) }}
                </span>
                <span>Selamat datang, <strong>{{ auth()->user()->full_name }}</strong></span>
            </div>
        </div>
        
        @if(session('success'))
            <div class="alert alert-success">
                <i class="fas fa-check-circle"></i> {{ session('success') }}
            </div>
        @endif
        
        @if(session('error'))
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i> {{ session('error') }}
            </div>
        @endif
        
        @if($errors->any())
            <div class="alert alert-danger">
                <i class="fas fa-exclamation-circle"></i>
                <ul class="mb-0">
                    @foreach($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
        
        @yield('content')
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Check if mobile
        function isMobile() {
            return window.innerWidth <= 992;
        }

        // Toggle Sidebar
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const toggleBtn = document.getElementById('sidebarToggle');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (isMobile()) {
                // Mobile: show/hide sidebar dengan slide
                sidebar.classList.toggle('show');
                overlay.classList.toggle('show');
            } else {
                // Desktop: collapse/expand sidebar
                sidebar.classList.toggle('collapsed');
                mainContent.classList.toggle('expanded');
                toggleBtn.classList.toggle('collapsed');
                localStorage.setItem('sidebarCollapsed', sidebar.classList.contains('collapsed'));
            }
        }

        // Close Sidebar (for mobile)
        function closeSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
        }

        // Initialize sidebar state
        document.addEventListener('DOMContentLoaded', function() {
            const sidebar = document.getElementById('sidebar');
            const mainContent = document.getElementById('mainContent');
            const toggleBtn = document.getElementById('sidebarToggle');
            
            if (!isMobile()) {
                const sidebarCollapsed = localStorage.getItem('sidebarCollapsed') === 'true';
                if (sidebarCollapsed) {
                    sidebar.classList.add('collapsed');
                    mainContent.classList.add('expanded');
                    toggleBtn.classList.add('collapsed');
                }
            }
        });

        // Handle window resize
        window.addEventListener('resize', function() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (!isMobile()) {
                sidebar.classList.remove('show');
                overlay.classList.remove('show');
            }
        });

        // Close sidebar when clicking menu item on mobile
        document.querySelectorAll('.sidebar-menu a').forEach(function(link) {
            link.addEventListener('click', function() {
                if (isMobile()) {
                    closeSidebar();
                }
            });
        });

        // Format currency
        function formatCurrency(amount) {
            return new Intl.NumberFormat('id-ID', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(amount);
        }

        // Format number
        function formatNumber(num) {
            if (typeof num === 'string') {
                num = parseFloat(num);
            }
            return new Intl.NumberFormat('id-ID', {
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(num);
        }

        // Parse currency
        function parseCurrency(str) {
            if (!str) return 0;
            let value = str.toString().replace(/\./g, '');
            value = value.replace(',', '.');
            return parseFloat(value) || 0;
        }
    </script>
    @stack('scripts')
</body>
</html>
