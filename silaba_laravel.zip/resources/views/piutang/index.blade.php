@extends('layouts.app')

@section('title', 'Daftar Piutang')
@section('page-title', 'Daftar Saldo Piutang')

@push('styles')
<style>
    .table-piutang td input {
        border: 1px solid #dee2e6;
        background: transparent;
        width: 100%;
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .table-piutang td input:focus {
        outline: 2px solid #007bff;
        background: white;
    }
    .saldo-akhir {
        background-color: #f8f9fa;
        font-weight: bold;
        font-family: 'Courier New', monospace;
    }
    .total-row {
        background-color: #e9ecef;
        font-weight: bold;
    }
    .total-row td {
        font-family: 'Courier New', monospace;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
        font-size: 0.85rem;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
@endpush

@section('content')
@if($success)
    <div class="alert alert-success alert-dismissible fade show no-print">
        <i class="fas fa-check-circle"></i> {{ $success }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif

@if($error)
    <div class="alert alert-danger alert-dismissible fade show no-print">
        <i class="fas fa-exclamation-circle"></i> {{ $error }}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
@endif

<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h3>DAFTAR SALDO PIUTANG PT. PELINDO, PT. JAI, & PT. JPPI</h3>
                <h5>PERIODE {{ strtoupper($bulanNama[$bulan]) }} {{ $tahun }}</h5>
            </div>
            <div class="col-md-6">
                <form method="GET" class="d-flex justify-content-end gap-2 no-print">
                    <input type="month" name="periode" id="periode" class="form-control" 
                           value="{{ $periode }}" 
                           onchange="this.form.submit()"
                           style="width: auto;">
                    @if(auth()->user()->isAdmin())
                    <button type="submit" name="auto_saldo" value="1" class="btn btn-info" 
                            title="Ambil saldo awal dari saldo akhir bulan sebelumnya">
                        <i class="fas fa-sync"></i> Auto Saldo Awal
                    </button>
                    @endif
                </form>
            </div>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('piutang.store') }}" id="formPiutang">
            @csrf
            <input type="hidden" name="periode" value="{{ $periode }}">
            
            <div class="table-responsive">
                <table class="table table-bordered table-hover table-piutang">
                    <thead>
                        <tr class="table-dark">
                            <th rowspan="2" width="5%" class="text-center align-middle">NO</th>
                            <th rowspan="2" width="30%" class="text-center align-middle">URAIAN</th>
                            <th rowspan="2" width="15%" class="text-center align-middle">SALDO AWAL (Rp)</th>
                            <th colspan="2" width="30%" class="text-center">MUTASI</th>
                            <th rowspan="2" width="15%" class="text-center align-middle">SALDO AKHIR (Rp)</th>
                        </tr>
                        <tr class="table-dark">
                            <th width="15%" class="text-center">DEBET (Rp)</th>
                            <th width="15%" class="text-center">KREDIT (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($piutangData as $index => $data)
                            @php
                                $saldoAwal = $data->saldo_awal ?? 0;
                                $mutasiDebet = $data->mutasi_debet ?? 0;
                                $mutasiKredit = $data->mutasi_kredit ?? 0;
                                $saldoAkhir = $saldoAwal + $mutasiDebet - $mutasiKredit;
                            @endphp
                            <tr>
                                <td class="text-center">{{ $index + 1 }}</td>
                                <td>
                                    {{ $data->nama_debitur }}
                                    <input type="hidden" name="master_piutang_id[]" value="{{ $data->id }}">
                                </td>
                                <td>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text currency-prefix">Rp</span>
                                        <input type="text" name="saldo_awal[]" 
                                               class="form-control text-end currency-input saldo-awal" 
                                               value="{{ number_format($saldoAwal, 0, ',', '.') }}"
                                               data-row="{{ $index }}"
                                               onkeyup="formatCurrencyInput(this); calculateSaldoAkhir({{ $index }});"
                                               onfocus="this.select();"
                                               {{ !auth()->user()->isAdmin() ? 'readonly' : '' }}>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text currency-prefix">Rp</span>
                                        <input type="text" name="mutasi_debet[]" 
                                               class="form-control text-end currency-input mutasi-debet" 
                                               value="{{ number_format($mutasiDebet, 0, ',', '.') }}"
                                               data-row="{{ $index }}"
                                               onkeyup="formatCurrencyInput(this); calculateSaldoAkhir({{ $index }});"
                                               onfocus="this.select();"
                                               {{ !auth()->user()->isAdmin() ? 'readonly' : '' }}>
                                    </div>
                                </td>
                                <td>
                                    <div class="input-group input-group-sm">
                                        <span class="input-group-text currency-prefix">Rp</span>
                                        <input type="text" name="mutasi_kredit[]" 
                                               class="form-control text-end currency-input mutasi-kredit" 
                                               value="{{ number_format($mutasiKredit, 0, ',', '.') }}"
                                               data-row="{{ $index }}"
                                               onkeyup="formatCurrencyInput(this); calculateSaldoAkhir({{ $index }});"
                                               onfocus="this.select();"
                                               {{ !auth()->user()->isAdmin() ? 'readonly' : '' }}>
                                    </div>
                                </td>
                                <td class="saldo-akhir text-end" id="saldo-akhir-{{ $index }}">
                                    Rp {{ number_format($saldoAkhir, 0, ',', '.') }}
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr class="total-row">
                            <td colspan="2" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-end" id="total-saldo-awal">
                                <strong>Rp {{ number_format($totals['saldo_awal'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-end" id="total-mutasi-debet">
                                <strong>Rp {{ number_format($totals['mutasi_debet'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-end" id="total-mutasi-kredit">
                                <strong>Rp {{ number_format($totals['mutasi_kredit'], 0, ',', '.') }}</strong>
                            </td>
                            <td class="text-end" id="total-saldo-akhir">
                                <strong>Rp {{ number_format($totals['saldo_akhir'], 0, ',', '.') }}</strong>
                            </td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2 no-print">
                @if(auth()->user()->isAdmin())
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Data Piutang
                </button>
                @endif
                <a href="{{ route('ikhtisar.jurnal', ['bulan' => $bulan, 'tahun' => $tahun]) }}" class="btn btn-success">
                    <i class="fas fa-chart-bar"></i> Lihat Ikhtisar Jurnal
                </a>
                <button type="button" class="btn btn-warning" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

// Calculate saldo akhir for a row
function calculateSaldoAkhir(rowIndex) {
    const saldoAwal = parseRupiah(document.querySelector(`input[name="saldo_awal[]"][data-row="${rowIndex}"]`).value);
    const mutasiDebet = parseRupiah(document.querySelector(`input[name="mutasi_debet[]"][data-row="${rowIndex}"]`).value);
    const mutasiKredit = parseRupiah(document.querySelector(`input[name="mutasi_kredit[]"][data-row="${rowIndex}"]`).value);
    
    const saldoAkhir = saldoAwal + mutasiDebet - mutasiKredit;
    
    document.getElementById(`saldo-akhir-${rowIndex}`).textContent = 'Rp ' + formatRupiah(saldoAkhir);
    
    calculateTotals();
}

// Calculate all totals
function calculateTotals() {
    let totalSaldoAwal = 0;
    let totalMutasiDebet = 0;
    let totalMutasiKredit = 0;
    let totalSaldoAkhir = 0;
    
    document.querySelectorAll('.saldo-awal').forEach(input => {
        totalSaldoAwal += parseRupiah(input.value);
    });
    
    document.querySelectorAll('.mutasi-debet').forEach(input => {
        totalMutasiDebet += parseRupiah(input.value);
    });
    
    document.querySelectorAll('.mutasi-kredit').forEach(input => {
        totalMutasiKredit += parseRupiah(input.value);
    });
    
    totalSaldoAkhir = totalSaldoAwal + totalMutasiDebet - totalMutasiKredit;
    
    document.getElementById('total-saldo-awal').innerHTML = '<strong>Rp ' + formatRupiah(totalSaldoAwal) + '</strong>';
    document.getElementById('total-mutasi-debet').innerHTML = '<strong>Rp ' + formatRupiah(totalMutasiDebet) + '</strong>';
    document.getElementById('total-mutasi-kredit').innerHTML = '<strong>Rp ' + formatRupiah(totalMutasiKredit) + '</strong>';
    document.getElementById('total-saldo-akhir').innerHTML = '<strong>Rp ' + formatRupiah(totalSaldoAkhir) + '</strong>';
}
</script>
@endpush
