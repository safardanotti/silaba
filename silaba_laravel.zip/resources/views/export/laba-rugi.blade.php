<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; font-size: 10pt; }
        th { background-color: #f0f0f0; font-weight: bold; text-align: center; vertical-align: middle; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; }
        .section-header { font-weight: bold; }
        .sub-total { font-weight: bold; }
        .total-row { font-weight: bold; background-color: #e0e0e0; }
        .laba-rugi-row { background-color: #e6ffe6; font-weight: bold; }
        .grand-total { font-weight: bold; background-color: #ffffcc; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="7" class="header">KOPERASI KARYAWAN PELABUHAN<br>CABANG PALEMBANG</td>
        </tr>
        <tr>
            <td colspan="7" class="header">REALISASI PERHITUNGAN LABA-RUGI<br>BULAN {{ strtoupper($periodeName) }} {{ $tahun }}</td>
        </tr>
        <tr>
            <th rowspan="2">NO</th>
            <th rowspan="2">URAIAN</th>
            <th rowspan="2">Anggaran Tahun {{ $tahun }}</th>
            <th rowspan="2">Anggaran Triwulan IV</th>
            <th colspan="3">Realisasi</th>
        </tr>
        <tr>
            <th>S/D BULAN LALU</th>
            <th>BULAN INI</th>
            <th>S/D BULAN INI</th>
        </tr>
        
        <!-- I. PENDAPATAN -->
        <tr>
            <td colspan="7" class="section-header">I. PENDAPATAN</td>
        </tr>
        @foreach($pendapatan as $item)
        @php $item = is_array($item) ? (object)$item : $item; @endphp
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 1:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah1, 2, ',', '.') }}</td>
        </tr>
        
        <!-- PENDAPATAN USAHA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">PENDAPATAN USAHA DILUAR ANGGOTA</td>
        </tr>
        @foreach($pendapatanUsaha as $item)
        @php $item = is_array($item) ? (object)$item : $item; @endphp
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 2:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah2, 2, ',', '.') }}</td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Pendapatan (1+2)</td>
            <td colspan="5" class="text-right">{{ number_format($jumlahPendapatan, 2, ',', '.') }}</td>
        </tr>
        
        <!-- II. BIAYA - BIAYA -->
        <tr>
            <td colspan="7" class="section-header">II. BIAYA - BIAYA</td>
        </tr>
        
        <!-- BIAYA DENGAN ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA DENGAN ANGGOTA</td>
        </tr>
        @foreach($biayaDenganAnggota as $item)
        @php $item = is_array($item) ? (object)$item : $item; @endphp
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 3:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah3, 2, ',', '.') }}</td>
        </tr>
        
        <!-- BIAYA - BIAYA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA - BIAYA DILUAR ANGGOTA</td>
        </tr>
        @foreach($biayaDiluarAnggota as $item)
        @php $item = is_array($item) ? (object)$item : $item; @endphp
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 4:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah4, 2, ',', '.') }}</td>
        </tr>
        
        <!-- BIAYA ORGANISASI DAN MANAJEMEN -->
        <tr>
            <td colspan="7" class="section-header">BIAYA ORGANISASI DAN MANAJEMEN</td>
        </tr>
        @foreach($biayaOrganisasi as $item)
        @php $item = is_array($item) ? (object)$item : $item; @endphp
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 5:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah5, 2, ',', '.') }}</td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Biaya (3+4+5)</td>
            <td colspan="5" class="text-right">{{ number_format($jumlahBiaya, 2, ',', '.') }}</td>
        </tr>
        
        <!-- LABA RUGI CALCULATIONS -->
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (1-3)</td>
            <td colspan="5" class="text-right">{{ number_format($labaRugi1_3, 2, ',', '.') }}</td>
        </tr>
        
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (2-4)</td>
            <td colspan="5" class="text-right">{{ number_format($labaRugi2_4, 2, ',', '.') }}</td>
        </tr>
        
        <tr class="grand-total">
            <td colspan="2" class="text-center"><strong>Laba - Rugi (I-II)</strong></td>
            <td colspan="5" class="text-right"><strong>{{ number_format($labaRugiBersih, 2, ',', '.') }}</strong></td>
        </tr>
    </table>
</body>
</html>
