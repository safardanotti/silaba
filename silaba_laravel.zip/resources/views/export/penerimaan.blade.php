<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; vertical-align: middle; }
        th { background-color: #cccccc; font-weight: bold; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; background-color: #cccccc; }
        .merged { vertical-align: middle; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="8" class="header">PENERIMAAN KAS - BANK</td>
        </tr>
        <tr>
            <td colspan="8" class="header">PERIODE {{ $periodeName }}</td>
        </tr>
        <tr>
            <td colspan="8">&nbsp;</td>
        </tr>
        <tr>
            <th width="5%">NO</th>
            <th width="10%">KODE AKUN</th>
            <th width="25%">NAMA AKUN</th>
            <th width="30%">URAIAN KEGIATAN</th>
            <th width="10%">JENIS MASUK</th>
            <th width="10%">TANGGAL</th>
            <th width="10%">DEBET</th>
            <th width="10%">KREDIT</th>
        </tr>
        @php $no = 1; @endphp
        @foreach($transactions as $transId => $trans)
            @php 
                $detailCount = count($trans['details']);
                $isFirst = true;
            @endphp
            @foreach($trans['details'] as $index => $detail)
        <tr>
            <td class="text-center">{{ $no++ }}</td>
            <td class="text-center">{{ $detail['kode_akun'] }}</td>
            <td>{{ $detail['nama_akun'] }}</td>
            @if($isFirst)
            <td class="merged" rowspan="{{ $detailCount }}">{{ $trans['uraian_kegiatan'] }}</td>
            <td class="text-center merged" rowspan="{{ $detailCount }}">{{ strtoupper($trans['jenis_masuk']) }}</td>
            <td class="text-center merged" rowspan="{{ $detailCount }}">{{ date('d-M-y', strtotime($trans['tanggal'])) }}</td>
            @endif
            <td class="text-right">{{ number_format($detail['debet'], 2, ',', '.') }}</td>
            <td class="text-right">{{ number_format($detail['kredit'], 2, ',', '.') }}</td>
        </tr>
            @php $isFirst = false; @endphp
            @endforeach
        @endforeach
        <tr>
            <th colspan="6" class="text-right">TOTAL:</th>
            <th class="text-right">{{ number_format($totalDebet, 2, ',', '.') }}</th>
            <th class="text-right">{{ number_format($totalKredit, 2, ',', '.') }}</th>
        </tr>
        <tr>
            <td colspan="8">&nbsp;</td>
        </tr>
        <tr>
            <td colspan="8" style="border: none; font-weight: bold;">KETERANGAN PENERIMAAN :</td>
        </tr>
        <tr>
            <td colspan="4" style="border: none;">1. KAS</td>
            <td colspan="4" style="border: none; text-align: right;">{{ number_format($totalKas, 2, ',', '.') }}</td>
        </tr>
        <tr>
            <td colspan="4" style="border: none;">2. BANK</td>
            <td colspan="4" style="border: none; text-align: right;">{{ number_format($totalBank, 2, ',', '.') }}</td>
        </tr>
    </table>
</body>
</html>
