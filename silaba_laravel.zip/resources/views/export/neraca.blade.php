<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <style>
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid black; padding: 5px; }
        th { background-color: #f0f0f0; font-weight: bold; text-align: center; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .header { font-weight: bold; text-align: center; }
        .section-header { font-weight: bold; text-decoration: underline; }
        .sub-total { font-weight: bold; border-top: 1px solid #000; }
        .grand-total { font-weight: bold; background-color: #e0e0e0; }
    </style>
</head>
<body>
    <table>
        <tr>
            <td colspan="6" class="header">KOPERASI KARYAWAN PELABUHAN</td>
        </tr>
        <tr>
            <td colspan="6" class="header">CABANG PALEMBANG</td>
        </tr>
        <tr>
            <td colspan="6" class="header">NERACA</td>
        </tr>
        <tr>
            <td colspan="6" class="header">PER {{ strtoupper($periodeName) }} {{ $tahun }}</td>
        </tr>
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        <tr>
            <th colspan="3">AKTIVA</th>
            <th colspan="3">PASSIVA</th>
        </tr>
        <tr>
            <th width="10%">NO<br>REK</th>
            <th width="30%">URAIAN</th>
            <th width="15%">JUMLAH</th>
            <th width="10%">NO<br>REK</th>
            <th width="30%">URAIAN</th>
            <th width="15%">JUMLAH</th>
        </tr>
        
        <!-- AKTIVA LANCAR & HUTANG -->
        <tr>
            <td colspan="3" class="section-header">AKTIVA LANCAR :</td>
            <td colspan="3" class="section-header">HUTANG :</td>
        </tr>
        
        @php
            $maxRows = max(count($aktiva['lancar']), count($passiva['hutang']));
        @endphp
        
        @for($i = 0; $i < $maxRows; $i++)
        <tr>
            @if(isset($aktiva['lancar'][$i]))
                <td class="text-center">{{ $aktiva['lancar'][$i]['kode'] }}</td>
                <td>{{ $aktiva['lancar'][$i]['nama'] }}</td>
                <td class="text-right">{{ number_format($aktiva['lancar'][$i]['jumlah'], 2, ',', '.') }}</td>
            @else
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            @endif
            
            @if(isset($passiva['hutang'][$i]))
                <td class="text-center">{{ $passiva['hutang'][$i]['kode'] }}</td>
                <td>{{ $passiva['hutang'][$i]['nama'] }}</td>
                <td class="text-right">{{ number_format($passiva['hutang'][$i]['jumlah'], 2, ',', '.') }}</td>
            @else
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            @endif
        </tr>
        @endfor
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalAktivaLancar, 2, ',', '.') }}</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalHutang, 2, ',', '.') }}</td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- AKTIVA TETAP & DANA-DANA -->
        <tr>
            <td colspan="3" class="section-header">AKTIVA TETAP :</td>
            <td colspan="3" class="section-header">DANA - DANA :</td>
        </tr>
        
        @php
            $maxRows = max(count($aktiva['tetap']), count($passiva['dana']));
        @endphp
        
        @for($i = 0; $i < $maxRows; $i++)
        <tr>
            @if(isset($aktiva['tetap'][$i]))
                <td class="text-center">{{ $aktiva['tetap'][$i]['kode'] }}</td>
                <td>{{ $aktiva['tetap'][$i]['nama'] }}</td>
                <td class="text-right">
                    @if($aktiva['tetap'][$i]['is_negative'] ?? false)
                        ({{ number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.') }})
                    @else
                        {{ number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.') }}
                    @endif
                </td>
            @else
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            @endif
            
            @if(isset($passiva['dana'][$i]))
                <td class="text-center">{{ $passiva['dana'][$i]['kode'] }}</td>
                <td>{{ $passiva['dana'][$i]['nama'] }}</td>
                <td class="text-right">{{ number_format($passiva['dana'][$i]['jumlah'], 2, ',', '.') }}</td>
            @else
                <td>&nbsp;</td>
                <td>&nbsp;</td>
                <td>&nbsp;</td>
            @endif
        </tr>
        @endfor
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalAktivaTetap, 2, ',', '.') }}</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalDana, 2, ',', '.') }}</td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- MODAL -->
        <tr>
            <td colspan="3">&nbsp;</td>
            <td colspan="3" class="section-header">MODAL :</td>
        </tr>
        
        @foreach($passiva['modal'] as $item)
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="text-center">{{ $item['kode'] }}</td>
            <td>{{ $item['nama'] }}</td>
            <td class="text-right">{{ number_format($item['jumlah'], 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="3">&nbsp;</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalModal, 2, ',', '.') }}</td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- SISA HASIL USAHA -->
        <tr>
            <td colspan="3">&nbsp;</td>
            <td colspan="3" class="section-header">SISA HASIL USAHA :</td>
        </tr>
        
        @foreach($passiva['shu'] as $item)
        <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
            <td class="text-center">{{ $item['kode'] }}</td>
            <td>{{ $item['nama'] }}</td>
            <td class="text-right">{{ number_format($item['jumlah'], 2, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="3">&nbsp;</td>
            <td colspan="2" class="text-right">Jumlah .....</td>
            <td class="text-right">{{ number_format($totalSHU, 2, ',', '.') }}</td>
        </tr>
        
        <tr>
            <td colspan="6">&nbsp;</td>
        </tr>
        
        <!-- GRAND TOTAL -->
        <tr class="grand-total">
            <td colspan="2" class="text-center">JUMLAH AKTIVA</td>
            <td class="text-right">{{ number_format($totalAktiva, 2, ',', '.') }}</td>
            <td colspan="2" class="text-center">JUMLAH PASSIVA</td>
            <td class="text-right">{{ number_format($totalPassiva, 2, ',', '.') }}</td>
        </tr>
    </table>
</body>
</html>
