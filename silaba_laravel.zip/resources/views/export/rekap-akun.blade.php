<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
        }
        th, td {
            border: 1px solid #000;
            padding: 5px;
        }
        th {
            background-color: #f0f0f0;
            font-weight: bold;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
        .total-row {
            background-color: #e0e0e0;
            font-weight: bold;
        }
        .header {
            text-align: center;
            font-weight: bold;
            font-size: 14px;
            margin-bottom: 20px;
        }
        .tipe-aktiva { background-color: #d4edda; }
        .tipe-passiva { background-color: #cce5ff; }
        .tipe-pendapatan { background-color: #fff3cd; }
        .tipe-biaya { background-color: #f8d7da; }
    </style>
</head>
<body>
    <div class="header">
        <p>KOPERASI KARYAWAN PELABUHAN</p>
        <p>CABANG PALEMBANG</p>
        <p>&nbsp;</p>
        <p>REKAP PER KODE AKUN - {{ $jenisName }}</p>
        <p>PERIODE: {{ $periodeName }}</p>
    </div>

    <table>
        <thead>
            <tr>
                <th class="text-center" width="5%">No</th>
                <th class="text-center" width="10%">Kode Akun</th>
                <th width="30%">Nama Akun</th>
                <th class="text-center" width="12%">Tipe Akun</th>
                <th class="text-right" width="15%">Total Debet</th>
                <th class="text-right" width="15%">Total Kredit</th>
                <th class="text-center" width="13%">Jumlah Transaksi</th>
            </tr>
        </thead>
        <tbody>
            @php $no = 1; @endphp
            @forelse($data as $row)
                @php
                    $rowClass = '';
                    if ($row->tipe_akun == 'aktiva') $rowClass = 'tipe-aktiva';
                    elseif ($row->tipe_akun == 'passiva') $rowClass = 'tipe-passiva';
                    elseif ($row->tipe_akun == 'pendapatan') $rowClass = 'tipe-pendapatan';
                    elseif ($row->tipe_akun == 'biaya') $rowClass = 'tipe-biaya';
                @endphp
                <tr class="{{ $rowClass }}">
                    <td class="text-center">{{ $no++ }}</td>
                    <td class="text-center">{{ $row->kode_akun }}</td>
                    <td>{{ $row->nama_akun }}</td>
                    <td class="text-center">{{ ucfirst($row->tipe_akun) }}</td>
                    <td class="text-right">{{ number_format($row->total_debet, 2, ',', '.') }}</td>
                    <td class="text-right">{{ number_format($row->total_kredit, 2, ',', '.') }}</td>
                    <td class="text-center">{{ $row->jumlah_transaksi }}</td>
                </tr>
            @empty
                <tr>
                    <td colspan="7" class="text-center">Tidak ada data transaksi</td>
                </tr>
            @endforelse
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="4" class="text-right">GRAND TOTAL:</td>
                <td class="text-right">{{ number_format($grandTotalDebet, 2, ',', '.') }}</td>
                <td class="text-right">{{ number_format($grandTotalKredit, 2, ',', '.') }}</td>
                <td></td>
            </tr>
        </tfoot>
    </table>
</body>
</html>
