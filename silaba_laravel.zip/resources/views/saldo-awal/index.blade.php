@extends('layouts.app')

@section('title', 'Input Saldo Awal')
@section('page-title')
    <i class="fas fa-wallet"></i> Input Saldo Awal
@endsection

@push('styles')
<style>
    .table-container {
        max-height: 60vh;
        overflow-y: auto;
    }
    .sticky-top {
        position: sticky;
        top: 0;
        z-index: 10;
    }
    .sticky-bottom {
        position: sticky;
        bottom: 0;
    }
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
        font-size: 0.85rem;
    }
</style>
@endpush

@section('content')
<div class="card">
    <div class="card-header">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h3>Saldo Awal Periode</h3>
            </div>
            <div class="col-md-6">
                <div class="d-flex justify-content-end gap-2">
                    <input type="month" class="form-control" id="filterPeriode" value="{{ $periode }}" style="width: auto;" onchange="changePeriode()">
                </div>
            </div>
        </div>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('saldo-awal.store') }}">
            @csrf
            <input type="hidden" name="periode" value="{{ $periode }}">
            
            <div class="alert alert-info mb-3">
                <i class="fas fa-info-circle"></i> 
                <strong>Petunjuk:</strong> Input saldo awal untuk periode {{ \Carbon\Carbon::createFromFormat('Y-m', $periode)->translatedFormat('F Y') }}. 
                Saldo awal ini akan digunakan sebagai dasar perhitungan neraca.
            </div>
            
            <div class="table-container">
                <table class="table table-sm">
                    <thead class="sticky-top bg-white">
                        <tr>
                            <th width="100">Kode Akun</th>
                            <th>Nama Akun</th>
                            <th width="100">Tipe</th>
                            <th width="220">Debet (Rp)</th>
                            <th width="220">Kredit (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($saldoData as $row)
                        <tr>
                            <td>
                                <input type="hidden" name="kode_akun[]" value="{{ $row->kode_akun }}">
                                {{ $row->kode_akun }}
                            </td>
                            <td>{{ $row->nama_akun }}</td>
                            <td>
                                @php
                                    $badgeClass = match($row->tipe_akun) {
                                        'aktiva' => 'bg-success',
                                        'passiva' => 'bg-info',
                                        'pendapatan' => 'bg-warning',
                                        'biaya' => 'bg-danger',
                                        default => 'bg-secondary'
                                    };
                                @endphp
                                <span class="badge {{ $badgeClass }}">{{ ucfirst($row->tipe_akun) }}</span>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="debet[]" class="form-control form-control-sm currency-input" 
                                           value="{{ number_format($row->debet, 0, ',', '.') }}">
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="kredit[]" class="form-control form-control-sm currency-input" 
                                           value="{{ number_format($row->kredit, 0, ',', '.') }}">
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot class="table-secondary sticky-bottom">
                        <tr>
                            <th colspan="3">TOTAL</th>
                            <th class="text-end"><span class="currency-display">Rp <span id="totalDebet">0</span></span></th>
                            <th class="text-end"><span class="currency-display">Rp <span id="totalKredit">0</span></span></th>
                        </tr>
                        <tr>
                            <th colspan="3">SELISIH</th>
                            <th colspan="2" class="text-center">
                                <span id="selisihAmount" class="fw-bold currency-display">Rp 0</span>
                            </th>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Saldo Awal
                </button>
                <a href="{{ route('neraca.index') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </form>
    </div>
</div>
@endsection

@push('scripts')
<script>
function changePeriode() {
    const periode = document.getElementById('filterPeriode').value;
    window.location.href = '{{ route("saldo-awal.index") }}?periode=' + periode;
}

// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

function calculateTotalSaldo() {
    let totalDebet = 0;
    let totalKredit = 0;
    
    document.querySelectorAll('input[name="debet[]"]').forEach(input => {
        totalDebet += parseRupiah(input.value);
    });
    
    document.querySelectorAll('input[name="kredit[]"]').forEach(input => {
        totalKredit += parseRupiah(input.value);
    });
    
    document.getElementById('totalDebet').textContent = formatRupiah(totalDebet);
    document.getElementById('totalKredit').textContent = formatRupiah(totalKredit);
    
    const selisih = Math.abs(totalDebet - totalKredit);
    const selisihElement = document.getElementById('selisihAmount');
    selisihElement.textContent = 'Rp ' + formatRupiah(selisih);
    
    if (selisih > 0.01) {
        selisihElement.classList.remove('text-success');
        selisihElement.classList.add('text-danger');
    } else {
        selisihElement.classList.remove('text-danger');
        selisihElement.classList.add('text-success');
    }
}

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Add event listeners to all currency inputs
    document.querySelectorAll('input.currency-input').forEach(input => {
        input.addEventListener('input', function() {
            formatCurrencyInput(this);
            calculateTotalSaldo();
        });
        
        input.addEventListener('blur', function() {
            if (this.value === '') {
                this.value = '0';
            }
            formatCurrencyInput(this);
            calculateTotalSaldo();
        });
        
        input.addEventListener('focus', function() {
            this.select();
        });
    });
    
    calculateTotalSaldo();
});
</script>
@endpush
