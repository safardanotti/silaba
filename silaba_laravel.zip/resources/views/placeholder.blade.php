@extends('layouts.app')

@section('title', $title ?? 'Coming Soon')
@section('page-title', $title ?? 'Coming Soon')

@section('content')
<div class="card">
    <div class="card-body text-center py-5">
        <i class="fas fa-cog fa-5x text-muted mb-4"></i>
        <h2>{{ $title ?? 'Halaman' }}</h2>
        <p class="text-muted">{{ $message ?? 'Halaman ini sedang dalam pengembangan.' }}</p>
        <a href="{{ route('dashboard') }}" class="btn btn-primary mt-3">
            <i class="fas fa-home"></i> Kembali ke Dashboard
        </a>
    </div>
</div>
@endsection
