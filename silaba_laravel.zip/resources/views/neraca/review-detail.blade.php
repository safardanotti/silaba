@extends('layouts.app')

@section('title', 'Review Detail Neraca')
@section('page-title', 'Review Detail Neraca')

@push('styles')
<style>
    .neraca-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 11pt;
    }
    .neraca-table td, .neraca-table th {
        padding: 5px;
        border: 1px solid #000;
    }
    .neraca-table th {
        background-color: #f0f0f0;
        text-align: center;
        font-weight: bold;
    }
    .section-header {
        font-weight: bold;
        text-decoration: underline;
    }
    .text-right {
        text-align: right;
    }
    .text-center {
        text-align: center;
    }
    .total-row {
        font-weight: bold;
    }
    .sub-total {
        font-weight: bold;
        border-top: 1px solid #000;
    }
    .grand-total {
        font-weight: bold;
        background-color: #e0e0e0;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        body {
            font-size: 11pt;
        }
        .main-content {
            margin-left: 0 !important;
            padding: 0 !important;
        }
    }
</style>
@endpush

@php
    $periode = \Carbon\Carbon::parse($posting->periode);
    $bulan = $periode->format('m');
    $tahun = $periode->format('Y');
@endphp

@section('content')
<!-- Status Info -->
<div class="card mb-3 no-print">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p><strong>Periode:</strong> {{ $bulanNama[$bulan] ?? '' }} {{ $tahun }}</p>
                <p><strong>Status:</strong> 
                    <span class="badge bg-{{ $posting->status_badge }}">
                        {{ strtoupper($posting->status) }}
                    </span>
                </p>
                <p><strong>Diposting Oleh:</strong> {{ $posting->postedBy->full_name ?? '-' }}</p>
                <p><strong>Tanggal Posting:</strong> {{ $posting->posted_at ? $posting->posted_at->format('d/m/Y H:i') : '-' }}</p>
            </div>
            <div class="col-md-6">
                @if($posting->catatan_revisi)
                <div class="alert alert-warning">
                    <strong>Catatan Revisi Terakhir:</strong><br>
                    {!! nl2br(e($posting->catatan_revisi)) !!}
                </div>
                @endif
                
                @if($posting->approved_at)
                <div class="alert alert-success">
                    <strong>Disetujui pada:</strong> {{ $posting->approved_at->format('d/m/Y H:i') }}
                </div>
                @endif
            </div>
        </div>
        
        <div class="mt-3">
            <a href="{{ route('neraca.review') }}" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Kembali
            </a>
            <button type="button" class="btn btn-info" onclick="window.print()">
                <i class="fas fa-print"></i> Cetak
            </button>
            
            @if(auth()->user()->isPimpinan() && $posting->status == 'posted')
            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#revisiModal">
                <i class="fas fa-undo"></i> Minta Revisi
            </button>
            <button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#approveModal">
                <i class="fas fa-check"></i> Setujui
            </button>
            @endif
        </div>
    </div>
</div>

<!-- Neraca Header -->
<div class="text-center mb-3">
    <h4>NERACA<br>PER {{ strtoupper($bulanNama[$bulan] ?? '') }} {{ $tahun }}</h4>
</div>

<!-- Neraca Table -->
<div class="card">
    <div class="card-body p-2">
        <table class="neraca-table">
            <!-- Header -->
            <tr>
                <th colspan="3">AKTIVA</th>
                <th colspan="3">PASSIVA</th>
            </tr>
            <tr>
                <th width="8%">NO<br>REK</th>
                <th width="25%">URAIAN</th>
                <th width="17%">JUMLAH</th>
                <th width="8%">NO<br>REK</th>
                <th width="25%">URAIAN</th>
                <th width="17%">JUMLAH</th>
            </tr>
            
            <!-- Content -->
            <tr>
                <td colspan="3" class="section-header">AKTIVA LANCAR :</td>
                <td colspan="3" class="section-header">HUTANG :</td>
            </tr>
            
            @php
                $maxRows = max(count($aktiva['lancar']), count($passiva['hutang']));
            @endphp
            
            @for($i = 0; $i < $maxRows; $i++)
            <tr>
                @if(isset($aktiva['lancar'][$i]))
                    <td class="text-center">{{ $aktiva['lancar'][$i]['kode'] }}</td>
                    <td>{{ $aktiva['lancar'][$i]['nama'] }}</td>
                    <td class="text-right">{{ number_format($aktiva['lancar'][$i]['jumlah'], 2, ',', '.') }}</td>
                @else
                    <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                @endif
                
                @if(isset($passiva['hutang'][$i]))
                    <td class="text-center">{{ $passiva['hutang'][$i]['kode'] }}</td>
                    <td>{{ $passiva['hutang'][$i]['nama'] }}</td>
                    <td class="text-right">{{ number_format($passiva['hutang'][$i]['jumlah'], 2, ',', '.') }}</td>
                @else
                    <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                @endif
            </tr>
            @endfor
            
            <tr class="sub-total">
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalAktivaLancar, 2, ',', '.') }}</td>
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalHutang, 2, ',', '.') }}</td>
            </tr>
            
            <tr><td colspan="6">&nbsp;</td></tr>
            
            <!-- Aktiva Tetap & Dana -->
            <tr>
                <td colspan="3" class="section-header">AKTIVA TETAP :</td>
                <td colspan="3" class="section-header">DANA - DANA :</td>
            </tr>
            
            @php
                $maxRows = max(count($aktiva['tetap']), count($passiva['dana']));
            @endphp
            
            @for($i = 0; $i < $maxRows; $i++)
            <tr>
                @if(isset($aktiva['tetap'][$i]))
                    <td class="text-center">{{ $aktiva['tetap'][$i]['kode'] }}</td>
                    <td>{{ $aktiva['tetap'][$i]['nama'] }}</td>
                    <td class="text-right">
                        @if($aktiva['tetap'][$i]['is_negative'] ?? false)
                            ({{ number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.') }})
                        @else
                            {{ number_format($aktiva['tetap'][$i]['jumlah'], 2, ',', '.') }}
                        @endif
                    </td>
                @else
                    <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                @endif
                
                @if(isset($passiva['dana'][$i]))
                    <td class="text-center">{{ $passiva['dana'][$i]['kode'] }}</td>
                    <td>{{ $passiva['dana'][$i]['nama'] }}</td>
                    <td class="text-right">{{ number_format($passiva['dana'][$i]['jumlah'], 2, ',', '.') }}</td>
                @else
                    <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                @endif
            </tr>
            @endfor
            
            <tr class="sub-total">
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalAktivaTetap, 2, ',', '.') }}</td>
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalDana, 2, ',', '.') }}</td>
            </tr>
            
            <tr><td colspan="6">&nbsp;</td></tr>
            
            <!-- Modal -->
            <tr>
                <td colspan="3">&nbsp;</td>
                <td colspan="3" class="section-header">MODAL :</td>
            </tr>
            
            @foreach($passiva['modal'] as $item)
            <tr>
                <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                <td class="text-center">{{ $item['kode'] }}</td>
                <td>{{ $item['nama'] }}</td>
                <td class="text-right">{{ number_format($item['jumlah'], 2, ',', '.') }}</td>
            </tr>
            @endforeach
            
            <tr class="sub-total">
                <td colspan="3">&nbsp;</td>
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalModal, 2, ',', '.') }}</td>
            </tr>
            
            <tr><td colspan="6">&nbsp;</td></tr>
            
            <!-- SHU -->
            <tr>
                <td colspan="3">&nbsp;</td>
                <td colspan="3" class="section-header">SISA HASIL USAHA :</td>
            </tr>
            
            @foreach($passiva['shu'] as $item)
            <tr>
                <td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>
                <td class="text-center">{{ $item['kode'] }}</td>
                <td>{{ $item['nama'] }}</td>
                <td class="text-right">{{ number_format($item['jumlah'], 2, ',', '.') }}</td>
            </tr>
            @endforeach
            
            <tr class="sub-total">
                <td colspan="3">&nbsp;</td>
                <td colspan="2" class="text-right">Jumlah .....</td>
                <td class="text-right">{{ number_format($totalSHU, 2, ',', '.') }}</td>
            </tr>
            
            <!-- Grand Total -->
            <tr class="grand-total">
                <td colspan="2" class="text-center">JUMLAH AKTIVA</td>
                <td class="text-right">{{ number_format($totalAktiva, 2, ',', '.') }}</td>
                <td colspan="2" class="text-center">JUMLAH PASSIVA</td>
                <td class="text-right">{{ number_format($totalPassiva, 2, ',', '.') }}</td>
            </tr>
        </table>
    </div>
</div>

@if(abs($totalAktiva - $totalPassiva) > 0.01)
<div class="alert alert-warning mt-3">
    <strong>Peringatan:</strong> Neraca tidak balance. 
    Selisih: Rp {{ number_format(abs($totalAktiva - $totalPassiva), 2, ',', '.') }}
</div>
@endif

<!-- History -->
<div class="card mt-4 no-print">
    <div class="card-body">
        <h5 class="card-title">Riwayat Review</h5>
        <div class="table-responsive">
            <table class="table table-sm">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>User</th>
                        <th>Aksi</th>
                        <th>Catatan</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($posting->history->sortByDesc('created_at') as $h)
                    <tr>
                        <td>{{ $h->created_at->format('d/m/Y H:i') }}</td>
                        <td>{{ $h->user->full_name ?? '-' }}</td>
                        <td>
                            <span class="badge bg-{{ $h->action_badge }}">
                                {{ strtoupper($h->action) }}
                            </span>
                        </td>
                        <td>{{ $h->catatan }}</td>
                    </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal Revisi -->
<div class="modal fade" id="revisiModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('neraca.revisi', $posting->id) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Minta Revisi</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Catatan Revisi</label>
                        <textarea name="catatan" class="form-control" rows="4" required 
                                  placeholder="Jelaskan apa yang perlu direvisi..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-warning">Kirim Revisi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal Approve -->
<div class="modal fade" id="approveModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST" action="{{ route('neraca.approve', $posting->id) }}">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Setujui Neraca</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p>Apakah Anda yakin ingin menyetujui neraca periode ini?</p>
                    <div class="mb-3">
                        <label class="form-label">Catatan (Opsional)</label>
                        <textarea name="catatan" class="form-control" rows="3" 
                                  placeholder="Tambahkan catatan jika diperlukan..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-success">Setujui</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
