@extends('layouts.app')

@section('title', 'Neraca Mutasi')
@section('page-title', 'Neraca Mutasi')

@push('styles')
<style>
    .table-neraca-mutasi {
        font-size: 12px;
    }
    .table-neraca-mutasi th {
        background-color: #f8f9fa;
        text-align: center;
        vertical-align: middle;
        font-weight: bold;
    }
    .table-neraca-mutasi td {
        vertical-align: middle;
    }
    .table-neraca-mutasi td.text-right,
    .table-neraca-mutasi th.text-right {
        font-family: 'Courier New', monospace;
    }
    .text-right {
        text-align: right;
    }
    .total-row {
        font-weight: bold;
        background-color: #e9ecef;
    }
    .total-row td {
        font-family: 'Courier New', monospace;
    }
    .balance-check {
        margin-top: 20px;
        padding: 15px;
        background-color: #f8f9fa;
        border-radius: 5px;
    }
    .balance-ok {
        color: green;
        font-weight: bold;
    }
    .balance-error {
        color: red;
        font-weight: bold;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
    }
    @media print {
        .no-print {
            display: none;
        }
        .table-neraca-mutasi {
            font-size: 10px;
        }
        .main-content {
            margin-left: 0 !important;
            padding: 0 !important;
        }
    }
</style>
@endpush

@section('content')
<!-- Filter Section -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" action="{{ route('neraca.mutasi') }}" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="bulan" class="form-select">
                    @foreach($bulanNama as $key => $value)
                        <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>
                            {{ $value }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="{{ $tahun }}" min="2020" max="2030">
            </div>
            <div class="col-md-6 d-flex align-items-end gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-filter"></i> Tampilkan
                </button>
                <a href="{{ route('export.neraca-mutasi', ['bulan' => $bulan, 'tahun' => $tahun]) }}" class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <button type="button" class="btn btn-warning text-white" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
            </div>
        </form>
    </div>
</div>

<!-- Header for Print -->
<div class="text-center mb-4">
    <h3>KOPERASI KARYAWAN PELABUHAN</h3>
    <h4>CABANG PALEMBANG</h4>
    <h5>NERACA MUTASI</h5>
    <h6>PER {{ strtoupper($periodeDisplay) }}</h6>
</div>

<!-- Neraca Mutasi Table -->
<div class="card">
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered table-neraca-mutasi">
                <thead>
                    <tr>
                        <th rowspan="2" width="80">KODE<br>REK</th>
                        <th rowspan="2" width="250">URAIAN</th>
                        <th colspan="2">SALDO AWAL (Rp)</th>
                        <th colspan="2">MUTASI (Rp)</th>
                        <th colspan="2">SALDO AKHIR (Rp)</th>
                    </tr>
                    <tr>
                        <th width="120">DEBET</th>
                        <th width="120">KREDIT</th>
                        <th width="120">DEBET</th>
                        <th width="120">KREDIT</th>
                        <th width="120">DEBET</th>
                        <th width="120">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($neracaMutasi as $row)
                    <tr>
                        <td class="text-center">{{ $row->kode_akun }}</td>
                        <td>{{ $row->nama_akun }}</td>
                        <td class="text-right">
                            {{ $row->saldo_awal_debet > 0 ? number_format($row->saldo_awal_debet, 0, ',', '.') : '' }}
                        </td>
                        <td class="text-right">
                            {{ $row->saldo_awal_kredit > 0 ? number_format($row->saldo_awal_kredit, 0, ',', '.') : '' }}
                        </td>
                        <td class="text-right">
                            {{ $row->mutasi_debet > 0 ? number_format($row->mutasi_debet, 0, ',', '.') : '' }}
                        </td>
                        <td class="text-right">
                            {{ $row->mutasi_kredit > 0 ? number_format($row->mutasi_kredit, 0, ',', '.') : '' }}
                        </td>
                        <td class="text-right">
                            {{ $row->saldo_akhir_debet > 0 ? number_format($row->saldo_akhir_debet, 0, ',', '.') : '' }}
                        </td>
                        <td class="text-right">
                            {{ $row->saldo_akhir_kredit > 0 ? number_format($row->saldo_akhir_kredit, 0, ',', '.') : '' }}
                        </td>
                    </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr class="total-row">
                        <td colspan="2" class="text-center"><strong>TOTAL</strong></td>
                        <td class="text-right">Rp {{ number_format($totals['saldo_awal_debet'], 0, ',', '.') }}</td>
                        <td class="text-right">Rp {{ number_format($totals['saldo_awal_kredit'], 0, ',', '.') }}</td>
                        <td class="text-right">Rp {{ number_format($totals['mutasi_debet'], 0, ',', '.') }}</td>
                        <td class="text-right">Rp {{ number_format($totals['mutasi_kredit'], 0, ',', '.') }}</td>
                        <td class="text-right">Rp {{ number_format($totals['saldo_akhir_debet'], 0, ',', '.') }}</td>
                        <td class="text-right">Rp {{ number_format($totals['saldo_akhir_kredit'], 0, ',', '.') }}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
        
        <!-- Balance Check -->
        <div class="balance-check">
            <h6><strong>Pemeriksaan Balance:</strong></h6>
            <div class="row">
                <div class="col-md-4">
                    @php
                        $selisihAwal = $totals['saldo_awal_debet'] - $totals['saldo_awal_kredit'];
                    @endphp
                    <strong>Saldo Awal:</strong><br>
                    <span class="currency-display">Debet - Kredit = Rp {{ number_format($selisihAwal, 0, ',', '.') }}</span>
                    @if(abs($selisihAwal) < 0.01)
                        <span class="balance-ok">✓ Balance</span>
                    @else
                        <span class="balance-error">✗ Tidak Balance</span>
                    @endif
                </div>
                <div class="col-md-4">
                    @php
                        $selisihMutasi = $totals['mutasi_debet'] - $totals['mutasi_kredit'];
                    @endphp
                    <strong>Mutasi:</strong><br>
                    <span class="currency-display">Debet - Kredit = Rp {{ number_format($selisihMutasi, 0, ',', '.') }}</span>
                    @if(abs($selisihMutasi) < 0.01)
                        <span class="balance-ok">✓ Balance</span>
                    @else
                        <span class="balance-error">✗ Tidak Balance</span>
                    @endif
                </div>
                <div class="col-md-4">
                    @php
                        $selisihAkhir = $totals['saldo_akhir_debet'] - $totals['saldo_akhir_kredit'];
                    @endphp
                    <strong>Saldo Akhir:</strong><br>
                    <span class="currency-display">Debet - Kredit = Rp {{ number_format($selisihAkhir, 0, ',', '.') }}</span>
                    @if(abs($selisihAkhir) < 0.01)
                        <span class="balance-ok">✓ Balance</span>
                    @else
                        <span class="balance-error">✗ Tidak Balance</span>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
