@extends('layouts.app')

@section('title', 'Neraca')

@push('styles')
<style>
    .currency-display {
        font-family: 'Courier New', monospace;
    }
    .table-neraca td.text-end,
    .table-neraca th.text-end {
        font-family: 'Courier New', monospace;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
@endpush

@section('content')
<div class="container-fluid">
    <h1 class="h3 mb-4">Neraca</h1>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Filter Form -->
    <div class="card mb-4 no-print">
        <div class="card-body">
            <form method="GET" action="{{ route('neraca.index') }}" class="row g-3 align-items-end">
                <div class="col-md-3">
                    <label class="form-label">Bulan</label>
                    <select name="bulan" class="form-select">
                        @foreach($bulanNama as $key => $nama)
                            <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>{{ $nama }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-2">
                    <label class="form-label">Tahun</label>
                    <input type="number" name="tahun" class="form-control" value="{{ $tahun }}" min="2020" max="2099">
                </div>
                <div class="col-md-7">
                    <button type="submit" class="btn btn-success">
                        <i class="fas fa-sync"></i> Generate Neraca
                    </button>
                    @if($showNeraca ?? false)
                        <a href="{{ route('export.neraca', ['bulan' => $bulan, 'tahun' => $tahun]) }}" class="btn btn-primary">
                            <i class="fas fa-file-excel"></i> Export Excel
                        </a>
                        <button type="button" class="btn btn-secondary" onclick="window.print()">
                            <i class="fas fa-print"></i> Cetak
                        </button>
                        <a href="{{ route('laba-rugi.index', ['bulan' => $bulan, 'tahun' => $tahun]) }}" class="btn btn-info">
                            <i class="fas fa-chart-line"></i> Lihat Laba Rugi
                        </a>
                        
                        @if(Auth::user()->role == 'admin')
                            @if(!$postingData || $postingData->status == 'draft' || $postingData->status == 'revisi')
                                <button type="button" class="btn btn-warning" onclick="postNeraca()">
                                    <i class="fas fa-paper-plane"></i> Post Neraca
                                </button>
                            @endif
                        @endif
                        
                        @if($postingData)
                            <span class="badge bg-{{ $postingData->status == 'posted' ? 'info' : ($postingData->status == 'revisi' ? 'warning' : ($postingData->status == 'approved' ? 'success' : 'secondary')) }} fs-6 ms-2">
                                Status: {{ strtoupper($postingData->status) }}
                            </span>
                        @endif
                    @endif
                </div>
            </form>
        </div>
    </div>

    @if($showNeraca ?? false)
    <!-- Neraca Table -->
    <div class="card">
        <div class="card-body">
            <h4 class="text-center mb-1"><strong>NERACA</strong></h4>
            <h5 class="text-center mb-4">PER {{ $bulanNama[$bulan] }} {{ $tahun }}</h5>

            @if($postingData && $postingData->status == 'revisi')
                <div class="alert alert-warning">
                    <strong><i class="fas fa-exclamation-triangle"></i> Perlu Revisi!</strong><br>
                    Catatan: {{ $postingData->catatan_revisi }}
                </div>
            @endif

            <div class="table-responsive">
                <table class="table table-bordered table-sm table-neraca">
                    <thead class="table-light">
                        <tr>
                            <th colspan="3" class="text-center">AKTIVA</th>
                            <th colspan="3" class="text-center">PASSIVA</th>
                        </tr>
                        <tr>
                            <th width="8%" class="text-center">NO REK</th>
                            <th width="25%">URAIAN</th>
                            <th width="17%" class="text-end">JUMLAH (Rp)</th>
                            <th width="8%" class="text-center">NO REK</th>
                            <th width="25%">URAIAN</th>
                            <th width="17%" class="text-end">JUMLAH (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- AKTIVA LANCAR & HUTANG -->
                        <tr>
                            <td colspan="3"><strong><u>AKTIVA LANCAR :</u></strong></td>
                            <td colspan="3"><strong><u>HUTANG :</u></strong></td>
                        </tr>
                        @php
                            $maxRowsLancarHutang = max(count($aktiva['lancar'] ?? []), count($passiva['hutang'] ?? []));
                        @endphp
                        @for($i = 0; $i < $maxRowsLancarHutang; $i++)
                            <tr>
                                @if(isset($aktiva['lancar'][$i]))
                                    <td class="text-center">{{ $aktiva['lancar'][$i]['kode'] }}</td>
                                    <td>{{ $aktiva['lancar'][$i]['nama'] }}</td>
                                    <td class="text-end">{{ number_format($aktiva['lancar'][$i]['jumlah'], 0, ',', '.') }}</td>
                                @else
                                    <td></td><td></td><td></td>
                                @endif
                                @if(isset($passiva['hutang'][$i]))
                                    <td class="text-center">{{ $passiva['hutang'][$i]['kode'] }}</td>
                                    <td>{{ $passiva['hutang'][$i]['nama'] }}</td>
                                    <td class="text-end">{{ number_format($passiva['hutang'][$i]['jumlah'], 0, ',', '.') }}</td>
                                @else
                                    <td></td><td></td><td></td>
                                @endif
                            </tr>
                        @endfor
                        <tr class="table-secondary">
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalAktivaLancar ?? 0, 0, ',', '.') }}</strong></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalHutang ?? 0, 0, ',', '.') }}</strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- AKTIVA TETAP & DANA-DANA -->
                        <tr>
                            <td colspan="3"><strong><u>AKTIVA TETAP :</u></strong></td>
                            <td colspan="3"><strong><u>DANA - DANA :</u></strong></td>
                        </tr>
                        @php
                            $maxRowsTetapDana = max(count($aktiva['tetap'] ?? []), count($passiva['dana'] ?? []));
                        @endphp
                        @for($i = 0; $i < $maxRowsTetapDana; $i++)
                            <tr>
                                @if(isset($aktiva['tetap'][$i]))
                                    <td class="text-center">{{ $aktiva['tetap'][$i]['kode'] }}</td>
                                    <td>{{ $aktiva['tetap'][$i]['nama'] }}</td>
                                    <td class="text-end">
                                        @if($aktiva['tetap'][$i]['is_negative'] ?? false)
                                            ({{ number_format($aktiva['tetap'][$i]['jumlah'], 0, ',', '.') }})
                                        @else
                                            {{ number_format($aktiva['tetap'][$i]['jumlah'], 0, ',', '.') }}
                                        @endif
                                    </td>
                                @else
                                    <td></td><td></td><td></td>
                                @endif
                                @if(isset($passiva['dana'][$i]))
                                    <td class="text-center">{{ $passiva['dana'][$i]['kode'] }}</td>
                                    <td>{{ $passiva['dana'][$i]['nama'] }}</td>
                                    <td class="text-end">{{ number_format($passiva['dana'][$i]['jumlah'], 0, ',', '.') }}</td>
                                @else
                                    <td></td><td></td><td></td>
                                @endif
                            </tr>
                        @endfor
                        <tr class="table-secondary">
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalAktivaTetap ?? 0, 0, ',', '.') }}</strong></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalDana ?? 0, 0, ',', '.') }}</strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- MODAL -->
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="3"><strong><u>MODAL :</u></strong></td>
                        </tr>
                        @foreach($passiva['modal'] ?? [] as $item)
                            <tr>
                                <td></td><td></td><td></td>
                                <td class="text-center">{{ $item['kode'] }}</td>
                                <td>{{ $item['nama'] }}</td>
                                <td class="text-end">{{ number_format($item['jumlah'], 0, ',', '.') }}</td>
                            </tr>
                        @endforeach
                        <tr class="table-secondary">
                            <td></td><td></td><td></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalModal ?? 0, 0, ',', '.') }}</strong></td>
                        </tr>

                        <!-- Blank row -->
                        <tr><td colspan="6">&nbsp;</td></tr>

                        <!-- SHU -->
                        <tr>
                            <td colspan="3"></td>
                            <td colspan="3"><strong><u>SISA HASIL USAHA :</u></strong></td>
                        </tr>
                        @foreach($passiva['shu'] ?? [] as $item)
                            <tr>
                                <td></td><td></td><td></td>
                                <td class="text-center">{{ $item['kode'] }}</td>
                                <td>{{ $item['nama'] }}</td>
                                <td class="text-end">{{ number_format($item['jumlah'], 0, ',', '.') }}</td>
                            </tr>
                        @endforeach
                        <tr class="table-secondary">
                            <td></td><td></td><td></td>
                            <td></td>
                            <td class="text-end"><strong>Jumlah .....</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalSHU ?? 0, 0, ',', '.') }}</strong></td>
                        </tr>

                        <!-- TOTAL -->
                        <tr class="table-dark">
                            <td colspan="2" class="text-center"><strong>JUMLAH AKTIVA</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalAktiva ?? 0, 0, ',', '.') }}</strong></td>
                            <td colspan="2" class="text-center"><strong>JUMLAH PASSIVA</strong></td>
                            <td class="text-end"><strong>Rp {{ number_format($totalPassiva ?? 0, 0, ',', '.') }}</strong></td>
                        </tr>

                        @if(abs(($totalAktiva ?? 0) - ($totalPassiva ?? 0)) > 0.01)
                        <tr class="table-danger">
                            <td colspan="6" class="text-center">
                                <strong><i class="fas fa-exclamation-triangle"></i> TIDAK BALANCE! Selisih: Rp {{ number_format(abs($totalAktiva - $totalPassiva), 0, ',', '.') }}</strong>
                            </td>
                        </tr>
                        @endif
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    @endif
</div>

@push('scripts')
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
function postNeraca() {
    Swal.fire({
        title: 'Post Neraca',
        text: 'Apakah Anda yakin ingin memposting neraca periode {{ $bulanNama[$bulan] }} {{ $tahun }} untuk direview pimpinan?',
        icon: 'question',
        showCancelButton: true,
        confirmButtonText: 'Ya, Post',
        cancelButtonText: 'Batal'
    }).then((result) => {
        if (result.isConfirmed) {
            window.location.href = "{{ route('neraca.post', ['bulan' => $bulan, 'tahun' => $tahun]) }}";
        }
    });
}
</script>
@endpush
@endsection
