@extends('layouts.app')

@section('title', 'Review Neraca')

@section('content')
<div class="container-fluid">
    <h1 class="h3 mb-4"><i class="fas fa-clipboard-check"></i> Review Neraca</h1>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    @if(session('error'))
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            {{ session('error') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    @endif

    <!-- Daftar Neraca -->
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title">Daftar Neraca untuk Direview</h5>
            
            @if($postingList->isEmpty())
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> Tidak ada neraca yang perlu direview saat ini.
                </div>
            @else
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Periode</th>
                                <th>Status</th>
                                <th>Diposting Oleh</th>
                                <th>Tanggal Posting</th>
                                <th>Catatan Revisi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($postingList as $posting)
                            @php
                                $periodeDate = \Carbon\Carbon::parse($posting->periode);
                                $bulanKey = $periodeDate->format('m');
                                $tahunVal = $periodeDate->format('Y');
                            @endphp
                            <tr>
                                <td>
                                    <strong>{{ $bulanNama[$bulanKey] ?? $bulanKey }} {{ $tahunVal }}</strong>
                                </td>
                                <td>
                                    <span class="badge bg-{{ $posting->status == 'posted' ? 'info' : ($posting->status == 'revisi' ? 'warning' : 'success') }}">
                                        {{ strtoupper($posting->status) }}
                                    </span>
                                </td>
                                <td>{{ $posting->postedBy->full_name ?? '-' }}</td>
                                <td>{{ $posting->posted_at ? \Carbon\Carbon::parse($posting->posted_at)->format('d/m/Y H:i') : '-' }}</td>
                                <td>
                                    @if($posting->catatan_revisi)
                                        <small class="text-muted">{{ $posting->catatan_revisi }}</small>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('neraca.review.detail', $posting->id) }}" class="btn btn-sm btn-primary">
                                        <i class="fas fa-eye"></i> Review
                                    </a>
                                    
                                    @if($posting->status == 'approved')
                                        <a href="{{ route('export.neraca-approved', $posting->id) }}" class="btn btn-sm btn-success">
                                            <i class="fas fa-file-excel"></i> Export
                                        </a>
                                    @endif
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>

    <!-- Riwayat Review -->
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Riwayat Review Terakhir</h5>
            
            @if($recentHistory->isEmpty())
                <p class="text-muted">Belum ada riwayat review.</p>
            @else
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Tanggal</th>
                                <th>Periode</th>
                                <th>User</th>
                                <th>Aksi</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($recentHistory as $h)
                            @php
                                $periodeDate = $h->posting ? \Carbon\Carbon::parse($h->posting->periode) : null;
                                $bulanKey = $periodeDate ? $periodeDate->format('m') : '01';
                                $tahunVal = $periodeDate ? $periodeDate->format('Y') : '-';
                            @endphp
                            <tr>
                                <td>{{ \Carbon\Carbon::parse($h->created_at)->format('d/m/Y H:i') }}</td>
                                <td>{{ ($bulanNama[$bulanKey] ?? $bulanKey) . ' ' . $tahunVal }}</td>
                                <td>{{ $h->user->full_name ?? '-' }}</td>
                                <td>
                                    <span class="badge bg-{{ $h->action == 'post' ? 'primary' : ($h->action == 'revisi' ? 'warning' : 'success') }}">
                                        {{ strtoupper($h->action) }}
                                    </span>
                                </td>
                                <td><small>{{ $h->catatan }}</small></td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection
