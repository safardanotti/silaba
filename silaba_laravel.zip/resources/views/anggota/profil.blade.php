@extends('layouts.anggota')

@section('title', 'Profil Saya')

@section('content')
<div class="container-fluid">
    <h4 class="mb-4"><i class="fas fa-user me-2"></i>Profil Saya</h4>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    @if($anggota->foto)
                        <img src="{{ Storage::url($anggota->foto) }}" class="rounded-circle mb-3" style="width: 150px; height: 150px; object-fit: cover;">
                    @else
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($anggota->nama_anggota) }}&size=150&background=4caf50&color=fff" class="rounded-circle mb-3">
                    @endif
                    <h5>{{ $anggota->nama_anggota }}</h5>
                    <p class="text-muted mb-0">{{ $anggota->no_anggota }}</p>
                    <span class="badge bg-success">{{ ucfirst($anggota->status_anggota) }}</span>
                </div>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-white">
                    <h5 class="mb-0">Data Pribadi</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('anggota.profil.update') }}" method="POST" enctype="multipart/form-data">
                        @csrf
                        @method('PUT')

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Nama Lengkap</label>
                                <input type="text" class="form-control" value="{{ $anggota->nama_anggota }}" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No. Anggota</label>
                                <input type="text" class="form-control" value="{{ $anggota->no_anggota }}" disabled>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">NIK</label>
                                <input type="text" class="form-control" value="{{ $anggota->nik ?? '-' }}" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="text" class="form-control" value="{{ $anggota->tanggal_lahir ? \Carbon\Carbon::parse($anggota->tanggal_lahir)->format('d/m/Y') : '-' }}" disabled>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Unit Kerja</label>
                                <input type="text" class="form-control" value="{{ $anggota->unit_kerja ?? '-' }}" disabled>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Jabatan</label>
                                <input type="text" class="form-control" value="{{ $anggota->jabatan ?? '-' }}" disabled>
                            </div>
                        </div>

                        <hr>
                        <h6 class="mb-3">Data yang dapat diubah:</h6>

                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <textarea name="alamat" class="form-control" rows="2">{{ old('alamat', $anggota->alamat) }}</textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No. HP</label>
                                <input type="text" name="no_hp" class="form-control" value="{{ old('no_hp', $anggota->no_hp) }}">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" value="{{ old('email', $anggota->email) }}">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Foto Profil</label>
                            <input type="file" name="foto" class="form-control" accept="image/*">
                            <small class="text-muted">Format: JPG, PNG. Max 2MB</small>
                        </div>

                        <button type="submit" class="btn btn-success">
                            <i class="fas fa-save me-2"></i>Simpan Perubahan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
