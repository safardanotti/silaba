@extends('layouts.anggota')

@section('title', 'Notifikasi')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-bell me-2"></i>Notifikasi</h4>
        @if($notifikasi->where('dibaca', false)->count() > 0)
            <form action="{{ route('anggota.notifikasi.baca-semua') }}" method="POST">
                @csrf
                <button type="submit" class="btn btn-outline-primary btn-sm">
                    <i class="fas fa-check-double me-1"></i>Tandai Semua Dibaca
                </button>
            </form>
        @endif
    </div>

    <div class="card">
        <div class="card-body">
            @forelse($notifikasi as $n)
                <div class="d-flex align-items-start border-bottom py-3 {{ !$n->dibaca ? 'bg-light' : '' }}">
                    <div class="flex-shrink-0 me-3">
                        @if($n->tipe == 'success')
                            <i class="fas fa-check-circle fa-2x text-success"></i>
                        @elseif($n->tipe == 'danger')
                            <i class="fas fa-times-circle fa-2x text-danger"></i>
                        @elseif($n->tipe == 'warning')
                            <i class="fas fa-exclamation-circle fa-2x text-warning"></i>
                        @else
                            <i class="fas fa-info-circle fa-2x text-info"></i>
                        @endif
                    </div>
                    <div class="flex-grow-1">
                        <div class="d-flex justify-content-between">
                            <h6 class="mb-1 {{ !$n->dibaca ? 'fw-bold' : '' }}">{{ $n->judul }}</h6>
                            <small class="text-muted">{{ $n->created_at->diffForHumans() }}</small>
                        </div>
                        <p class="mb-1 text-muted">{{ $n->pesan }}</p>
                        @if($n->link && !$n->dibaca)
                            <form action="{{ route('anggota.notifikasi.baca', $n->id) }}" method="POST" class="d-inline">
                                @csrf
                                <button type="submit" class="btn btn-sm btn-outline-primary">Lihat Detail</button>
                            </form>
                        @elseif($n->link)
                            <a href="{{ $n->link }}" class="btn btn-sm btn-outline-secondary">Lihat Detail</a>
                        @endif
                    </div>
                </div>
            @empty
                <div class="text-center py-5 text-muted">
                    <i class="fas fa-bell-slash fa-4x mb-3"></i>
                    <p>Tidak ada notifikasi</p>
                </div>
            @endforelse

            {{ $notifikasi->links() }}
        </div>
    </div>
</div>
@endsection
