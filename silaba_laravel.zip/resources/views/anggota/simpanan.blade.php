@extends('layouts.anggota')

@section('title', 'Simpanan Saya')

@section('content')
<div class="container-fluid">
    <h4 class="mb-4"><i class="fas fa-piggy-bank me-2"></i>Simpanan Saya</h4>

    <!-- Saldo Simpanan -->
    <div class="row mb-4">
        @forelse($saldoSimpanan as $saldo)
            <div class="col-md-4 mb-3">
                <div class="card border-success h-100">
                    <div class="card-body">
                        <h6 class="text-muted">{{ $saldo->jenisSimpanan->nama_simpanan }}</h6>
                        <h3 class="text-success currency-display">Rp {{ number_format($saldo->total_saldo, 0, ',', '.') }}</h3>
                        <small class="text-muted">{{ $saldo->jenisSimpanan->keterangan }}</small>
                    </div>
                </div>
            </div>
        @empty
            <div class="col-12">
                <div class="alert alert-info">Belum ada data simpanan</div>
            </div>
        @endforelse
    </div>

    <!-- Riwayat Transaksi -->
    <div class="card">
        <div class="card-header bg-white">
            <h5 class="mb-0">Riwayat Transaksi Simpanan</h5>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Jenis Simpanan</th>
                            <th>Transaksi</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-end">Saldo</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($riwayatSimpanan as $r)
                            <tr>
                                <td>{{ \Carbon\Carbon::parse($r->tanggal_transaksi)->format('d/m/Y') }}</td>
                                <td>{{ $r->jenisSimpanan->nama_simpanan }}</td>
                                <td>
                                    <span class="badge {{ $r->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger' }}">
                                        {{ ucfirst($r->jenis_transaksi) }}
                                    </span>
                                </td>
                                <td class="text-end currency-display {{ $r->jenis_transaksi == 'setor' ? 'text-success' : 'text-danger' }}">
                                    {{ $r->jenis_transaksi == 'setor' ? '+' : '-' }}Rp {{ number_format($r->jumlah, 0, ',', '.') }}
                                </td>
                                <td class="text-end currency-display">Rp {{ number_format($r->saldo_sesudah, 0, ',', '.') }}</td>
                                <td>{{ $r->keterangan ?? '-' }}</td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-4 text-muted">Belum ada transaksi simpanan</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            {{ $riwayatSimpanan->links() }}
        </div>
    </div>
</div>
@endsection
