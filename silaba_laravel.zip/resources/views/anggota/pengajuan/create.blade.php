@extends('layouts.anggota')

@section('title', 'Ajukan Pinjaman')

@push('styles')
<style>
    .product-card {
        cursor: pointer;
        transition: all 0.2s;
        border: 2px solid transparent;
    }
    .product-card:hover {
        border-color: #4caf50;
    }
    .product-card.selected {
        border-color: #2e7d32;
        background-color: #e8f5e9;
    }
    .product-card input[type="radio"] {
        display: none;
    }
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
    }
</style>
@endpush

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('anggota.pengajuan.index') }}">Pengajuan Pinjaman</a></li>
            <li class="breadcrumb-item active">Form Pengajuan</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-file-alt me-2"></i>Form Pengajuan Pinjaman</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('anggota.pengajuan.store') }}" method="POST" enctype="multipart/form-data">
                        @csrf

                        <!-- Pilih Produk -->
                        <div class="mb-4">
                            <label class="form-label fw-bold">Pilih Produk Pinjaman <span class="text-danger">*</span></label>
                            <div class="row">
                                @foreach($produk as $p)
                                    <div class="col-md-6 mb-3">
                                        <label class="product-card card h-100 {{ old('produk_pinjaman_id') == $p->id ? 'selected' : '' }}">
                                            <input type="radio" name="produk_pinjaman_id" value="{{ $p->id }}" 
                                                   data-bunga="{{ $p->bunga_persen }}"
                                                   data-min="{{ $p->min_pinjaman }}"
                                                   data-max="{{ $p->max_pinjaman }}"
                                                   data-max-tenor="{{ $p->max_tenor }}"
                                                   {{ old('produk_pinjaman_id') == $p->id ? 'checked' : '' }}
                                                   required>
                                            <div class="card-body">
                                                <h6 class="card-title text-success">{{ $p->nama_produk }}</h6>
                                                <p class="card-text small text-muted">{{ $p->kode_produk }}</p>
                                                <hr>
                                                <ul class="list-unstyled small mb-0">
                                                    <li><i class="fas fa-percent text-success me-2"></i>Bunga: {{ $p->bunga_persen }}% / tahun</li>
                                                    <li><i class="fas fa-calendar text-success me-2"></i>Max Tenor: {{ $p->max_tenor }} bulan</li>
                                                    <li><i class="fas fa-money-bill text-success me-2"></i>Min: Rp {{ number_format($p->min_pinjaman, 0, ',', '.') }}</li>
                                                    <li><i class="fas fa-money-bill text-success me-2"></i>Max: Rp {{ number_format($p->max_pinjaman, 0, ',', '.') }}</li>
                                                </ul>
                                            </div>
                                        </label>
                                    </div>
                                @endforeach
                            </div>
                            @error('produk_pinjaman_id')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Jumlah Pinjaman -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Jumlah Pinjaman <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text currency-prefix">Rp</span>
                                <input type="text" name="jumlah_pinjaman" id="jumlah_pinjaman" 
                                       class="form-control currency-input @error('jumlah_pinjaman') is-invalid @enderror"
                                       value="{{ old('jumlah_pinjaman') }}"
                                       placeholder="0"
                                       onkeyup="formatCurrencyInput(this); hitungSimulasi();"
                                       onfocus="this.select();"
                                       required>
                            </div>
                            <small class="text-muted" id="rangeInfo">Pilih produk pinjaman terlebih dahulu</small>
                            @error('jumlah_pinjaman')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Tenor -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Jangka Waktu (Tenor) <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <input type="number" name="tenor" id="tenor" 
                                       class="form-control @error('tenor') is-invalid @enderror"
                                       value="{{ old('tenor', 12) }}"
                                       min="1"
                                       onchange="hitungSimulasi();"
                                       required>
                                <span class="input-group-text">bulan</span>
                            </div>
                            <small class="text-muted" id="tenorInfo">Max tenor akan ditampilkan setelah memilih produk</small>
                            @error('tenor')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Keperluan -->
                        <div class="mb-3">
                            <label class="form-label fw-bold">Keperluan/Tujuan Pinjaman <span class="text-danger">*</span></label>
                            <textarea name="keperluan" class="form-control @error('keperluan') is-invalid @enderror" 
                                      rows="3" required>{{ old('keperluan') }}</textarea>
                            @error('keperluan')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <hr>
                        <h6 class="mb-3"><i class="fas fa-file-upload me-2"></i>Upload Dokumen Persyaratan</h6>

                        <!-- Dokumen KTP -->
                        <div class="mb-3">
                            <label class="form-label">Foto KTP <span class="text-danger">*</span></label>
                            <input type="file" name="dok_ktp" class="form-control @error('dok_ktp') is-invalid @enderror" 
                                   accept="image/*,application/pdf" required>
                            <small class="text-muted">Format: JPG, PNG, PDF. Max 2MB</small>
                            @error('dok_ktp')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Dokumen KK -->
                        <div class="mb-3">
                            <label class="form-label">Foto Kartu Keluarga</label>
                            <input type="file" name="dok_kk" class="form-control @error('dok_kk') is-invalid @enderror" 
                                   accept="image/*,application/pdf">
                            <small class="text-muted">Format: JPG, PNG, PDF. Max 2MB</small>
                            @error('dok_kk')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <!-- Dokumen Slip Gaji -->
                        <div class="mb-3">
                            <label class="form-label">Slip Gaji 3 Bulan Terakhir</label>
                            <input type="file" name="dok_slip_gaji" class="form-control @error('dok_slip_gaji') is-invalid @enderror" 
                                   accept="image/*,application/pdf">
                            <small class="text-muted">Format: JPG, PNG, PDF. Max 2MB</small>
                            @error('dok_slip_gaji')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <hr>

                        <div class="d-flex gap-2">
                            <a href="{{ route('anggota.pengajuan.index') }}" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-paper-plane me-2"></i>Ajukan Pinjaman
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Simulasi Angsuran -->
        <div class="col-lg-4">
            <div class="card sticky-top" style="top: 80px;">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Simulasi Angsuran</h6>
                </div>
                <div class="card-body" id="simulasiResult">
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-calculator fa-3x mb-3"></i>
                        <p>Pilih produk dan masukkan jumlah pinjaman untuk melihat simulasi</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d]/g, '');
    
    if (value) {
        value = parseInt(value).toLocaleString('id-ID');
    }
    
    input.value = value;
}

// Parse currency to number
function parseCurrency(value) {
    return parseInt(value.replace(/\./g, '')) || 0;
}

// Product selection
document.querySelectorAll('.product-card').forEach(card => {
    card.addEventListener('click', function() {
        document.querySelectorAll('.product-card').forEach(c => c.classList.remove('selected'));
        this.classList.add('selected');
        
        const radio = this.querySelector('input[type="radio"]');
        const min = parseInt(radio.dataset.min);
        const max = parseInt(radio.dataset.max);
        const maxTenor = parseInt(radio.dataset.maxTenor);
        
        document.getElementById('rangeInfo').textContent = 
            `Range: Rp ${min.toLocaleString('id-ID')} - Rp ${max.toLocaleString('id-ID')}`;
        document.getElementById('tenorInfo').textContent = 
            `Max tenor: ${maxTenor} bulan`;
        document.getElementById('tenor').max = maxTenor;
        
        hitungSimulasi();
    });
});

// Hitung simulasi
function hitungSimulasi() {
    const produkRadio = document.querySelector('input[name="produk_pinjaman_id"]:checked');
    const jumlahInput = document.getElementById('jumlah_pinjaman');
    const tenorInput = document.getElementById('tenor');
    
    if (!produkRadio || !jumlahInput.value || !tenorInput.value) {
        return;
    }
    
    const jumlah = parseCurrency(jumlahInput.value);
    const tenor = parseInt(tenorInput.value);
    const bunga = parseFloat(produkRadio.dataset.bunga);
    
    if (jumlah <= 0 || tenor <= 0) {
        return;
    }
    
    // Hitung flat rate
    const bungaPerBulan = bunga / 100 / 12;
    const totalBunga = jumlah * bungaPerBulan * tenor;
    const angsuranPokok = jumlah / tenor;
    const angsuranBunga = totalBunga / tenor;
    const totalAngsuran = angsuranPokok + angsuranBunga;
    
    // Update hasil
    document.getElementById('simulasiResult').innerHTML = `
        <table class="table table-sm mb-0">
            <tr>
                <td>Jumlah Pinjaman</td>
                <td class="text-end currency-display fw-bold">Rp ${jumlah.toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Bunga per Tahun</td>
                <td class="text-end">${bunga}%</td>
            </tr>
            <tr>
                <td>Tenor</td>
                <td class="text-end">${tenor} bulan</td>
            </tr>
            <tr class="table-light">
                <td colspan="2" class="fw-bold">Perhitungan</td>
            </tr>
            <tr>
                <td>Angsuran Pokok/bln</td>
                <td class="text-end currency-display">Rp ${Math.round(angsuranPokok).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Angsuran Bunga/bln</td>
                <td class="text-end currency-display">Rp ${Math.round(angsuranBunga).toLocaleString('id-ID')}</td>
            </tr>
            <tr class="table-success">
                <td class="fw-bold">Total Angsuran/bln</td>
                <td class="text-end currency-display fw-bold fs-5">Rp ${Math.round(totalAngsuran).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Total Bunga</td>
                <td class="text-end currency-display">Rp ${Math.round(totalBunga).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Total Bayar</td>
                <td class="text-end currency-display fw-bold">Rp ${Math.round(jumlah + totalBunga).toLocaleString('id-ID')}</td>
            </tr>
        </table>
    `;
}

// Initial calculation if old values exist
document.addEventListener('DOMContentLoaded', function() {
    const selectedProduct = document.querySelector('input[name="produk_pinjaman_id"]:checked');
    if (selectedProduct) {
        selectedProduct.closest('.product-card').click();
    }
});
</script>
@endpush
