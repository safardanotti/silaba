@extends('layouts.anggota')

@section('title', 'Pengajuan Pinjaman')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0"><i class="fas fa-file-alt me-2"></i>Pengajuan Pinjaman Saya</h4>
        <a href="{{ route('anggota.pengajuan.create') }}" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Ajukan Pinjaman Baru
        </a>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pengajuan</th>
                            <th>Tanggal</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-center">Tenor</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pengajuan as $p)
                            <tr>
                                <td><strong>{{ $p->no_pengajuan }}</strong></td>
                                <td>{{ $p->created_at->format('d/m/Y H:i') }}</td>
                                <td>{{ $p->produkPinjaman->nama_produk }}</td>
                                <td class="text-end currency-display">Rp {{ number_format($p->jumlah_pinjaman, 0, ',', '.') }}</td>
                                <td class="text-center">{{ $p->tenor }} bulan</td>
                                <td class="text-center">{!! $p->status_label !!}</td>
                                <td>
                                    <a href="{{ route('anggota.pengajuan.show', $p->id) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4">
                                    <div class="text-muted">
                                        <i class="fas fa-file-alt fa-3x mb-3"></i>
                                        <p>Belum ada pengajuan pinjaman</p>
                                        <a href="{{ route('anggota.pengajuan.create') }}" class="btn btn-success">
                                            <i class="fas fa-plus me-2"></i>Ajukan Pinjaman
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            {{ $pengajuan->links() }}
        </div>
    </div>
</div>
@endsection
