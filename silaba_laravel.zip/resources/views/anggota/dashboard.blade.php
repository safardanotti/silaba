@extends('layouts.anggota')

@section('title', 'Dashboard')

@section('content')
<div class="container-fluid">
    <!-- Welcome Section -->
    <div class="row mb-4">
        <div class="col-12">
            <div class="card border-0 bg-gradient" style="background: linear-gradient(135deg, #2e7d32, #4caf50);">
                <div class="card-body text-white py-4">
                    <div class="row align-items-center">
                        <div class="col-md-8">
                            <h4 class="mb-1">Selamat Datang, {{ $anggota->nama_anggota }}!</h4>
                            <p class="mb-0 opacity-75">No. Anggota: {{ $anggota->no_anggota }} | {{ $anggota->unit_kerja ?? '-' }}</p>
                        </div>
                        <div class="col-md-4 text-md-end mt-3 mt-md-0">
                            <a href="{{ route('anggota.pengajuan.create') }}" class="btn btn-light">
                                <i class="fas fa-plus me-2"></i>Ajukan Pinjaman
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Stats Cards -->
    <div class="row mb-4">
        <div class="col-md-4 mb-3">
            <div class="card stat-card simpanan h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-piggy-bank"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Total Simpanan</p>
                            <h4 class="mb-0 currency-display">Rp {{ number_format($totalSimpanan, 0, ',', '.') }}</h4>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="{{ route('anggota.simpanan') }}" class="btn btn-sm btn-outline-success">
                        Lihat Detail <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card stat-card pinjaman h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Sisa Pinjaman</p>
                            <h4 class="mb-0 currency-display">Rp {{ number_format($totalPinjaman, 0, ',', '.') }}</h4>
                            <small class="text-muted">{{ $pinjamanAktif }} pinjaman aktif</small>
                        </div>
                    </div>
                </div>
                <div class="card-footer bg-transparent border-0 pt-0">
                    <a href="{{ route('anggota.pinjaman.index') }}" class="btn btn-sm btn-outline-warning">
                        Lihat Detail <i class="fas fa-arrow-right ms-1"></i>
                    </a>
                </div>
            </div>
        </div>
        
        <div class="col-md-4 mb-3">
            <div class="card stat-card angsuran h-100">
                <div class="card-body">
                    <div class="d-flex align-items-center">
                        <div class="icon-box me-3">
                            <i class="fas fa-calendar-check"></i>
                        </div>
                        <div>
                            <p class="text-muted mb-0">Angsuran Bulan Ini</p>
                            <h4 class="mb-0 currency-display">Rp {{ number_format($angsuranBulanIni->sum('total_angsuran'), 0, ',', '.') }}</h4>
                            <small class="text-muted">{{ $angsuranBulanIni->count() }} angsuran</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Angsuran Jatuh Tempo -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-exclamation-triangle text-warning me-2"></i>Angsuran Bulan Ini</h6>
                </div>
                <div class="card-body">
                    @if($angsuranBulanIni->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-sm">
                                <thead>
                                    <tr>
                                        <th>No. Pinjaman</th>
                                        <th>Ke-</th>
                                        <th>Jatuh Tempo</th>
                                        <th class="text-end">Jumlah</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($angsuranBulanIni as $ang)
                                        <tr>
                                            <td>
                                                <a href="{{ route('anggota.pinjaman.show', $ang->pinjaman_id) }}">
                                                    {{ $ang->pinjaman->no_pinjaman }}
                                                </a>
                                            </td>
                                            <td>{{ $ang->angsuran_ke }}</td>
                                            <td>
                                                {{ \Carbon\Carbon::parse($ang->tanggal_jatuh_tempo)->format('d/m/Y') }}
                                            </td>
                                            <td class="text-end currency-display">
                                                Rp {{ number_format($ang->total_angsuran, 0, ',', '.') }}
                                            </td>
                                        </tr>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-check-circle fa-3x mb-3 text-success"></i>
                            <p class="mb-0">Tidak ada angsuran bulan ini</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Saldo Simpanan -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-wallet text-success me-2"></i>Saldo Simpanan</h6>
                    <a href="{{ route('anggota.simpanan') }}" class="btn btn-sm btn-outline-success">Lihat Semua</a>
                </div>
                <div class="card-body">
                    @if($saldoSimpanan->count() > 0)
                        @foreach($saldoSimpanan as $saldo)
                            <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                                <div>
                                    <strong>{{ $saldo->jenisSimpanan->nama_simpanan }}</strong>
                                    <br>
                                    <small class="text-muted">{{ $saldo->jenisSimpanan->kode_simpanan }}</small>
                                </div>
                                <div class="text-end">
                                    <span class="currency-display fs-5 text-success">
                                        Rp {{ number_format($saldo->total_saldo, 0, ',', '.') }}
                                    </span>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-piggy-bank fa-3x mb-3"></i>
                            <p class="mb-0">Belum ada data simpanan</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <!-- Pinjaman Aktif -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h6 class="mb-0"><i class="fas fa-hand-holding-usd text-warning me-2"></i>Pinjaman Aktif</h6>
                    <a href="{{ route('anggota.pinjaman.index') }}" class="btn btn-sm btn-outline-warning">Lihat Semua</a>
                </div>
                <div class="card-body">
                    @if($pinjamanList->count() > 0)
                        @foreach($pinjamanList as $pinj)
                            <div class="border rounded p-3 mb-2">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <strong>{{ $pinj->no_pinjaman }}</strong>
                                        <br>
                                        <small class="text-muted">{{ $pinj->produkPinjaman->nama_produk }}</small>
                                    </div>
                                    <div class="text-end">
                                        {!! $pinj->status_label !!}
                                    </div>
                                </div>
                                <hr class="my-2">
                                <div class="row small">
                                    <div class="col-6">
                                        <span class="text-muted">Pinjaman:</span><br>
                                        <strong class="currency-display">Rp {{ number_format($pinj->jumlah_pinjaman, 0, ',', '.') }}</strong>
                                    </div>
                                    <div class="col-6 text-end">
                                        <span class="text-muted">Sisa:</span><br>
                                        <strong class="currency-display text-danger">Rp {{ number_format($pinj->saldo_pokok, 0, ',', '.') }}</strong>
                                    </div>
                                </div>
                                <div class="progress mt-2" style="height: 6px;">
                                    <div class="progress-bar bg-success" style="width: {{ $pinj->persentase_lunas }}%"></div>
                                </div>
                                <small class="text-muted">{{ $pinj->persentase_lunas }}% terbayar ({{ $pinj->angsuran_ke }}/{{ $pinj->tenor }})</small>
                            </div>
                        @endforeach
                    @else
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-hand-holding-usd fa-3x mb-3"></i>
                            <p class="mb-0">Tidak ada pinjaman aktif</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Riwayat Simpanan Terakhir -->
        <div class="col-lg-6 mb-4">
            <div class="card h-100">
                <div class="card-header bg-white">
                    <h6 class="mb-0"><i class="fas fa-history text-info me-2"></i>Transaksi Simpanan Terakhir</h6>
                </div>
                <div class="card-body">
                    @if($riwayatSimpanan->count() > 0)
                        @foreach($riwayatSimpanan as $riwayat)
                            <div class="d-flex justify-content-between py-2 border-bottom">
                                <div>
                                    <span class="badge {{ $riwayat->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger' }}">
                                        {{ ucfirst($riwayat->jenis_transaksi) }}
                                    </span>
                                    <span class="ms-2">{{ $riwayat->jenisSimpanan->nama_simpanan }}</span>
                                    <br>
                                    <small class="text-muted">{{ \Carbon\Carbon::parse($riwayat->tanggal_transaksi)->format('d/m/Y') }}</small>
                                </div>
                                <div class="text-end">
                                    <span class="currency-display {{ $riwayat->jenis_transaksi == 'setor' ? 'text-success' : 'text-danger' }}">
                                        {{ $riwayat->jenis_transaksi == 'setor' ? '+' : '-' }}Rp {{ number_format($riwayat->jumlah, 0, ',', '.') }}
                                    </span>
                                </div>
                            </div>
                        @endforeach
                    @else
                        <div class="text-center py-4 text-muted">
                            <i class="fas fa-history fa-3x mb-3"></i>
                            <p class="mb-0">Belum ada transaksi</p>
                        </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
