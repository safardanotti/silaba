@extends('layouts.app')

@section('title', 'Manajemen Anggota')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-users me-2"></i>Manajemen Anggota</h4>
        <div>
            <a href="{{ route('admin.anggota.pendaftaran') }}" class="btn btn-warning me-2">
                <i class="fas fa-user-plus me-2"></i>Pendaftaran Baru
                @php
                    $countPending = \App\Models\PendaftaranAnggota::pending()->count();
                @endphp
                @if($countPending > 0)
                    <span class="badge bg-danger">{{ $countPending }}</span>
                @endif
            </a>
            <a href="{{ route('admin.anggota.create') }}" class="btn btn-success">
                <i class="fas fa-plus me-2"></i>Tambah Anggota
            </a>
        </div>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <input type="text" name="search" class="form-control" placeholder="Cari nama/no anggota..." value="{{ request('search') }}">
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="aktif" {{ request('status') == 'aktif' ? 'selected' : '' }}>Aktif</option>
                        <option value="tidak_aktif" {{ request('status') == 'tidak_aktif' ? 'selected' : '' }}>Tidak Aktif</option>
                        <option value="keluar" {{ request('status') == 'keluar' ? 'selected' : '' }}>Keluar</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="unit_kerja" class="form-select">
                        <option value="">Semua Unit Kerja</option>
                        @foreach($unitKerja as $uk)
                            <option value="{{ $uk }}" {{ request('unit_kerja') == $uk ? 'selected' : '' }}>{{ $uk }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="{{ route('admin.anggota.index') }}" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Anggota</th>
                            <th>Nama</th>
                            <th>Unit Kerja</th>
                            <th>No. HP</th>
                            <th class="text-center">Pinjaman Aktif</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Akun</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($anggota as $a)
                            <tr>
                                <td><strong>{{ $a->no_anggota }}</strong></td>
                                <td>
                                    {{ $a->nama_anggota }}
                                    <br><small class="text-muted">{{ $a->jabatan ?? '-' }}</small>
                                </td>
                                <td>{{ $a->unit_kerja ?? '-' }}</td>
                                <td>{{ $a->no_hp ?? '-' }}</td>
                                <td class="text-center">
                                    @if($a->pinjaman_aktif_count > 0)
                                        <span class="badge bg-warning">{{ $a->pinjaman_aktif_count }}</span>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($a->status_anggota == 'aktif')
                                        <span class="badge bg-success">Aktif</span>
                                    @elseif($a->status_anggota == 'tidak_aktif')
                                        <span class="badge bg-secondary">Tidak Aktif</span>
                                    @else
                                        <span class="badge bg-danger">Keluar</span>
                                    @endif
                                </td>
                                <td class="text-center">
                                    @if($a->user)
                                        <span class="badge bg-info">{{ $a->user->username }}</span>
                                    @else
                                        <span class="text-muted">-</span>
                                    @endif
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <a href="{{ route('admin.anggota.show', $a->id) }}" class="btn btn-info" title="Detail">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="{{ route('admin.anggota.edit', $a->id) }}" class="btn btn-warning" title="Edit">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <button type="button" class="btn btn-danger" title="Hapus" 
                                                onclick="confirmDelete({{ $a->id }})">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                    <form id="deleteForm{{ $a->id }}" action="{{ route('admin.anggota.destroy', $a->id) }}" 
                                          method="POST" style="display: none;">
                                        @csrf
                                        @method('DELETE')
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada data anggota
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            {{ $anggota->withQueryString()->links() }}
        </div>
    </div>
</div>

@push('scripts')
<script>
function confirmDelete(id) {
    if (confirm('Apakah Anda yakin ingin menghapus anggota ini?')) {
        document.getElementById('deleteForm' + id).submit();
    }
}
</script>
@endpush
@endsection
