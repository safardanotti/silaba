@extends('layouts.app')

@section('title', 'Detail Anggota')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.anggota.index') }}">Manajemen Anggota</a></li>
            <li class="breadcrumb-item active">Detail Anggota</li>
        </ol>
    </nav>

    <div class="row">
        <!-- Profil Anggota -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-body text-center">
                    @if($anggota->foto)
                        <img src="{{ Storage::url($anggota->foto) }}" class="rounded-circle mb-3" style="width: 120px; height: 120px; object-fit: cover;">
                    @else
                        <img src="https://ui-avatars.com/api/?name={{ urlencode($anggota->nama_anggota) }}&size=120&background=4caf50&color=fff" class="rounded-circle mb-3">
                    @endif
                    <h5 class="mb-1">{{ $anggota->nama_anggota }}</h5>
                    <p class="text-muted mb-2">{{ $anggota->no_anggota }}</p>
                    @if($anggota->status_anggota == 'aktif')
                        <span class="badge bg-success">Aktif</span>
                    @elseif($anggota->status_anggota == 'tidak_aktif')
                        <span class="badge bg-secondary">Tidak Aktif</span>
                    @else
                        <span class="badge bg-danger">Keluar</span>
                    @endif
                </div>
                <div class="card-footer">
                    <a href="{{ route('admin.anggota.edit', $anggota->id) }}" class="btn btn-warning btn-sm w-100">
                        <i class="fas fa-edit me-2"></i>Edit Data
                    </a>
                </div>
            </div>

            <!-- Info Singkat -->
            <div class="card mt-3">
                <div class="card-header"><strong>Informasi</strong></div>
                <div class="card-body">
                    <table class="table table-sm table-borderless mb-0">
                        <tr>
                            <td class="text-muted">NIK</td>
                            <td>{{ $anggota->nik ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">TTL</td>
                            <td>{{ $anggota->tempat_lahir ?? '' }}{{ $anggota->tanggal_lahir ? ', ' . $anggota->tanggal_lahir->format('d/m/Y') : '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">No. HP</td>
                            <td>{{ $anggota->no_hp ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Email</td>
                            <td>{{ $anggota->email ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Unit Kerja</td>
                            <td>{{ $anggota->unit_kerja ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Jabatan</td>
                            <td>{{ $anggota->jabatan ?? '-' }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tgl Masuk</td>
                            <td>{{ $anggota->tanggal_masuk ? $anggota->tanggal_masuk->format('d/m/Y') : '-' }}</td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Akun -->
            <div class="card mt-3">
                <div class="card-header"><strong>Akun Login</strong></div>
                <div class="card-body">
                    @if($anggota->user)
                        <p class="mb-2"><i class="fas fa-user me-2"></i>Username: <strong>{{ $anggota->user->username }}</strong></p>
                        <p class="mb-0"><i class="fas fa-circle me-2 {{ $anggota->user->status == 'active' ? 'text-success' : 'text-danger' }}"></i>
                            Status: {{ ucfirst($anggota->user->status) }}
                        </p>
                    @else
                        <p class="text-muted mb-3">Belum memiliki akun</p>
                        <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#modalBuatAkun">
                            <i class="fas fa-user-plus me-2"></i>Buat Akun
                        </button>
                    @endif
                </div>
            </div>
        </div>

        <!-- Data Simpanan & Pinjaman -->
        <div class="col-lg-8">
            <!-- Ringkasan -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card bg-success text-white">
                        <div class="card-body">
                            <h6>Total Simpanan</h6>
                            <h4 class="mb-0">Rp {{ number_format($anggota->total_simpanan, 0, ',', '.') }}</h4>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="card bg-warning text-white">
                        <div class="card-body">
                            <h6>Total Pinjaman Aktif</h6>
                            <h4 class="mb-0">Rp {{ number_format($anggota->total_pinjaman_aktif, 0, ',', '.') }}</h4>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Tabs -->
            <div class="card">
                <div class="card-header">
                    <ul class="nav nav-tabs card-header-tabs">
                        <li class="nav-item">
                            <a class="nav-link active" data-bs-toggle="tab" href="#simpanan">
                                <i class="fas fa-piggy-bank me-2"></i>Simpanan
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" data-bs-toggle="tab" href="#pinjaman">
                                <i class="fas fa-hand-holding-usd me-2"></i>Pinjaman
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="card-body">
                    <div class="tab-content">
                        <!-- Tab Simpanan -->
                        <div class="tab-pane fade show active" id="simpanan">
                            <h6 class="mb-3">Saldo Simpanan</h6>
                            @if($anggota->saldoSimpanan->count() > 0)
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Jenis Simpanan</th>
                                                <th class="text-end">Saldo</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($anggota->saldoSimpanan as $saldo)
                                                <tr>
                                                    <td>{{ $saldo->jenisSimpanan->nama_simpanan }}</td>
                                                    <td class="text-end">Rp {{ number_format($saldo->total_saldo, 0, ',', '.') }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <p class="text-muted">Belum ada data simpanan</p>
                            @endif

                            <hr>
                            <h6 class="mb-3">Riwayat Transaksi Simpanan</h6>
                            @if($anggota->simpanan->count() > 0)
                                <div class="table-responsive">
                                    <table class="table table-sm">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Jenis</th>
                                                <th>Transaksi</th>
                                                <th class="text-end">Jumlah</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            @foreach($anggota->simpanan as $s)
                                                <tr>
                                                    <td>{{ $s->tanggal_transaksi->format('d/m/Y') }}</td>
                                                    <td>{{ $s->jenisSimpanan->nama_simpanan }}</td>
                                                    <td>
                                                        <span class="badge {{ $s->jenis_transaksi == 'setor' ? 'bg-success' : 'bg-danger' }}">
                                                            {{ ucfirst($s->jenis_transaksi) }}
                                                        </span>
                                                    </td>
                                                    <td class="text-end">Rp {{ number_format($s->jumlah, 0, ',', '.') }}</td>
                                                </tr>
                                            @endforeach
                                        </tbody>
                                    </table>
                                </div>
                            @else
                                <p class="text-muted">Belum ada transaksi simpanan</p>
                            @endif
                        </div>

                        <!-- Tab Pinjaman -->
                        <div class="tab-pane fade" id="pinjaman">
                            @if($anggota->pinjaman->count() > 0)
                                @foreach($anggota->pinjaman as $p)
                                    <div class="card mb-3">
                                        <div class="card-header d-flex justify-content-between">
                                            <span>
                                                <strong>{{ $p->no_pinjaman }}</strong>
                                                <small class="text-muted ms-2">{{ $p->produkPinjaman->nama_produk }}</small>
                                            </span>
                                            {!! $p->status_label !!}
                                        </div>
                                        <div class="card-body">
                                            <div class="row">
                                                <div class="col-md-4">
                                                    <small class="text-muted">Jumlah Pinjaman</small>
                                                    <p class="mb-0"><strong>Rp {{ number_format($p->jumlah_pinjaman, 0, ',', '.') }}</strong></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <small class="text-muted">Sisa Pokok</small>
                                                    <p class="mb-0 text-danger"><strong>Rp {{ number_format($p->saldo_pokok, 0, ',', '.') }}</strong></p>
                                                </div>
                                                <div class="col-md-4">
                                                    <small class="text-muted">Progress</small>
                                                    <div class="progress" style="height: 20px;">
                                                        <div class="progress-bar bg-success" style="width: {{ $p->persentase_lunas }}%">
                                                            {{ $p->persentase_lunas }}%
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <hr>
                                            <small class="text-muted">Angsuran: {{ $p->angsuran_ke }}/{{ $p->tenor }} | Rp {{ number_format($p->total_angsuran, 0, ',', '.') }}/bulan</small>
                                            <br>
                                            <a href="{{ route('admin.pinjaman.show', $p->id) }}" class="btn btn-sm btn-outline-primary mt-2">
                                                <i class="fas fa-eye me-1"></i>Detail Pinjaman
                                            </a>
                                        </div>
                                    </div>
                                @endforeach
                            @else
                                <p class="text-muted">Tidak ada data pinjaman</p>
                            @endif
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal Buat Akun -->
@if(!$anggota->user)
<div class="modal fade" id="modalBuatAkun" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="{{ route('admin.anggota.buat-akun', $anggota->id) }}" method="POST">
                @csrf
                <div class="modal-header">
                    <h5 class="modal-title">Buat Akun untuk {{ $anggota->nama_anggota }}</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label">Username</label>
                        <input type="text" name="username" class="form-control" 
                               value="{{ strtolower(str_replace(' ', '', $anggota->nama_anggota)) . $anggota->id }}" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label">Password</label>
                        <input type="password" name="password" class="form-control" value="password123" required>
                        <small class="text-muted">Default: password123</small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary">Buat Akun</button>
                </div>
            </form>
        </div>
    </div>
</div>
@endif
@endsection
