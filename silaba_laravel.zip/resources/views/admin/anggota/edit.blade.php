@extends('layouts.app')

@section('title', 'Edit Anggota')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.anggota.index') }}">Manajemen Anggota</a></li>
            <li class="breadcrumb-item active">Edit {{ $anggota->nama_anggota }}</li>
        </ol>
    </nav>

    <div class="card">
        <div class="card-header bg-warning">
            <h5 class="mb-0"><i class="fas fa-edit me-2"></i>Edit Data Anggota</h5>
        </div>
        <div class="card-body">
            <form action="{{ route('admin.anggota.update', $anggota->id) }}" method="POST" enctype="multipart/form-data">
                @csrf
                @method('PUT')

                <div class="row">
                    <div class="col-md-6">
                        <h6 class="mb-3 text-primary"><i class="fas fa-user me-2"></i>Data Pribadi</h6>
                        
                        <div class="mb-3">
                            <label class="form-label">No. Anggota</label>
                            <input type="text" class="form-control" value="{{ $anggota->no_anggota }}" disabled>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap <span class="text-danger">*</span></label>
                            <input type="text" name="nama_anggota" class="form-control @error('nama_anggota') is-invalid @enderror" 
                                   value="{{ old('nama_anggota', $anggota->nama_anggota) }}" required>
                            @error('nama_anggota')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">NIK</label>
                            <input type="text" name="nik" class="form-control @error('nik') is-invalid @enderror" 
                                   value="{{ old('nik', $anggota->nik) }}" maxlength="16">
                            @error('nik')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tempat Lahir</label>
                                <input type="text" name="tempat_lahir" class="form-control" value="{{ old('tempat_lahir', $anggota->tempat_lahir) }}">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Lahir</label>
                                <input type="date" name="tanggal_lahir" class="form-control" value="{{ old('tanggal_lahir', $anggota->tanggal_lahir ? $anggota->tanggal_lahir->format('Y-m-d') : '') }}">
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jenis Kelamin</label>
                            <select name="jenis_kelamin" class="form-select">
                                <option value="">-- Pilih --</option>
                                <option value="L" {{ old('jenis_kelamin', $anggota->jenis_kelamin) == 'L' ? 'selected' : '' }}>Laki-laki</option>
                                <option value="P" {{ old('jenis_kelamin', $anggota->jenis_kelamin) == 'P' ? 'selected' : '' }}>Perempuan</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Alamat</label>
                            <textarea name="alamat" class="form-control" rows="2">{{ old('alamat', $anggota->alamat) }}</textarea>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">No. HP</label>
                                <input type="text" name="no_hp" class="form-control" value="{{ old('no_hp', $anggota->no_hp) }}">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control" value="{{ old('email', $anggota->email) }}">
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <h6 class="mb-3 text-primary"><i class="fas fa-id-card me-2"></i>Data Keanggotaan</h6>

                        <div class="mb-3">
                            <label class="form-label">Unit Kerja</label>
                            <input type="text" name="unit_kerja" class="form-control" value="{{ old('unit_kerja', $anggota->unit_kerja) }}">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jabatan</label>
                            <input type="text" name="jabatan" class="form-control" value="{{ old('jabatan', $anggota->jabatan) }}">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Tanggal Masuk</label>
                            <input type="date" name="tanggal_masuk" class="form-control" value="{{ old('tanggal_masuk', $anggota->tanggal_masuk ? $anggota->tanggal_masuk->format('Y-m-d') : '') }}">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Status Anggota</label>
                            <select name="status_anggota" class="form-select">
                                <option value="aktif" {{ old('status_anggota', $anggota->status_anggota) == 'aktif' ? 'selected' : '' }}>Aktif</option>
                                <option value="tidak_aktif" {{ old('status_anggota', $anggota->status_anggota) == 'tidak_aktif' ? 'selected' : '' }}>Tidak Aktif</option>
                                <option value="keluar" {{ old('status_anggota', $anggota->status_anggota) == 'keluar' ? 'selected' : '' }}>Keluar</option>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Foto</label>
                            @if($anggota->foto)
                                <div class="mb-2">
                                    <img src="{{ Storage::url($anggota->foto) }}" class="img-thumbnail" style="max-width: 150px;">
                                </div>
                            @endif
                            <input type="file" name="foto" class="form-control" accept="image/*">
                            <small class="text-muted">Kosongkan jika tidak ingin mengubah foto</small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Keterangan</label>
                            <textarea name="keterangan" class="form-control" rows="2">{{ old('keterangan', $anggota->keterangan) }}</textarea>
                        </div>
                    </div>
                </div>

                <hr>
                <div class="d-flex gap-2">
                    <a href="{{ route('admin.anggota.index') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left me-2"></i>Kembali
                    </a>
                    <button type="submit" class="btn btn-warning">
                        <i class="fas fa-save me-2"></i>Update Anggota
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
