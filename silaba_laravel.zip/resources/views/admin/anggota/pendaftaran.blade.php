@extends('layouts.app')

@section('title', 'Pendaftaran Anggota')

@section('content')
<div class="container-fluid">
    @php
        $countPending = \App\Models\PendaftaranAnggota::pending()->count();
    @endphp
    
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="fas fa-user-plus me-2"></i>Pendaftaran Anggota Baru
            @if($countPending > 0)
                <span class="badge bg-danger">{{ $countPending }} Pending</span>
            @endif
        </h4>
        <a href="{{ route('admin.anggota.index') }}" class="btn btn-secondary">
            <i class="fas fa-arrow-left me-2"></i>Kembali
        </a>
    </div>

    <!-- Filter -->
    <div class="card mb-3">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="disetujui" {{ request('status') == 'disetujui' ? 'selected' : '' }}>Disetujui</option>
                        <option value="ditolak" {{ request('status') == 'ditolak' ? 'selected' : '' }}>Ditolak</option>
                    </select>
                </div>
                <div class="col-md-8">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="{{ route('admin.anggota.pendaftaran') }}" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>Tanggal</th>
                            <th>Nama</th>
                            <th>NIK</th>
                            <th>No. HP</th>
                            <th>Unit Kerja</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pendaftaran as $p)
                            <tr class="{{ $p->status == 'pending' ? 'table-warning' : '' }}">
                                <td>{{ $p->created_at->format('d/m/Y H:i') }}</td>
                                <td><strong>{{ $p->nama_lengkap }}</strong></td>
                                <td>{{ $p->nik }}</td>
                                <td>{{ $p->no_hp }}</td>
                                <td>{{ $p->unit_kerja ?? '-' }}</td>
                                <td class="text-center">
                                    @if($p->status == 'pending')
                                        <span class="badge bg-warning">Pending</span>
                                    @elseif($p->status == 'disetujui')
                                        <span class="badge bg-success">Disetujui</span>
                                    @else
                                        <span class="badge bg-danger">Ditolak</span>
                                    @endif
                                </td>
                                <td>
                                    <a href="{{ route('admin.anggota.pendaftaran-detail', $p->id) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center py-4 text-muted">Tidak ada pendaftaran</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            {{ $pendaftaran->links() }}
        </div>
    </div>
</div>
@endsection
