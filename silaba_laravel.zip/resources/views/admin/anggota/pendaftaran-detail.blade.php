@extends('layouts.app')

@section('title', 'Detail Pendaftaran')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.anggota.pendaftaran') }}">Pendaftaran Anggota</a></li>
            <li class="breadcrumb-item active">{{ $pendaftaran->nama_lengkap }}</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">Detail Pendaftaran</h5>
                    @if($pendaftaran->status == 'pending')
                        <span class="badge bg-warning">Pending</span>
                    @elseif($pendaftaran->status == 'disetujui')
                        <span class="badge bg-success">Disetujui</span>
                    @else
                        <span class="badge bg-danger">Ditolak</span>
                    @endif
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-6">
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td class="text-muted" width="150">Nama Lengkap</td>
                                    <td><strong>{{ $pendaftaran->nama_lengkap }}</strong></td>
                                </tr>
                                <tr>
                                    <td class="text-muted">NIK</td>
                                    <td>{{ $pendaftaran->nik }}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">TTL</td>
                                    <td>{{ $pendaftaran->tempat_lahir ?? '' }}{{ $pendaftaran->tanggal_lahir ? ', ' . \Carbon\Carbon::parse($pendaftaran->tanggal_lahir)->format('d/m/Y') : '-' }}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Jenis Kelamin</td>
                                    <td>{{ $pendaftaran->jenis_kelamin == 'L' ? 'Laki-laki' : ($pendaftaran->jenis_kelamin == 'P' ? 'Perempuan' : '-') }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td class="text-muted" width="150">No. HP</td>
                                    <td>{{ $pendaftaran->no_hp }}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Email</td>
                                    <td>{{ $pendaftaran->email }}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Unit Kerja</td>
                                    <td>{{ $pendaftaran->unit_kerja ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <td class="text-muted">Jabatan</td>
                                    <td>{{ $pendaftaran->jabatan ?? '-' }}</td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="text-muted">Alamat</label>
                        <p>{{ $pendaftaran->alamat ?? '-' }}</p>
                    </div>

                    <h6 class="text-muted">Dokumen</h6>
                    <div class="row">
                        @if($pendaftaran->dok_ktp)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-id-card fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">KTP</p>
                                    <a href="{{ Storage::url($pendaftaran->dok_ktp) }}" target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                                </div>
                            </div>
                        @endif
                        @if($pendaftaran->dok_kk)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-users fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Kartu Keluarga</p>
                                    <a href="{{ Storage::url($pendaftaran->dok_kk) }}" target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                                </div>
                            </div>
                        @endif
                        @if($pendaftaran->dok_foto)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-user fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Foto</p>
                                    <a href="{{ Storage::url($pendaftaran->dok_foto) }}" target="_blank" class="btn btn-sm btn-outline-primary">Lihat</a>
                                </div>
                            </div>
                        @endif
                    </div>

                    @if($pendaftaran->catatan)
                        <div class="alert alert-{{ $pendaftaran->status == 'ditolak' ? 'danger' : 'info' }}">
                            <strong>Catatan:</strong> {{ $pendaftaran->catatan }}
                        </div>
                    @endif

                    @if($pendaftaran->status == 'pending')
                        <hr>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <form action="{{ route('admin.anggota.pendaftaran-approve', $pendaftaran->id) }}" method="POST">
                                    @csrf
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Catatan (opsional)"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fas fa-check me-2"></i>Setujui & Buat Anggota
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-6 mb-3">
                                <form action="{{ route('admin.anggota.pendaftaran-tolak', $pendaftaran->id) }}" method="POST">
                                    @csrf
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Alasan penolakan (wajib)" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100">
                                        <i class="fas fa-times me-2"></i>Tolak Pendaftaran
                                    </button>
                                </form>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Informasi</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-muted">Tanggal Daftar</td>
                            <td>{{ $pendaftaran->created_at->format('d/m/Y H:i') }}</td>
                        </tr>
                        @if($pendaftaran->approved_at)
                            <tr>
                                <td class="text-muted">Tanggal Proses</td>
                                <td>{{ \Carbon\Carbon::parse($pendaftaran->approved_at)->format('d/m/Y H:i') }}</td>
                            </tr>
                        @endif
                        @if($pendaftaran->approver)
                            <tr>
                                <td class="text-muted">Diproses Oleh</td>
                                <td>{{ $pendaftaran->approver->full_name }}</td>
                            </tr>
                        @endif
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
