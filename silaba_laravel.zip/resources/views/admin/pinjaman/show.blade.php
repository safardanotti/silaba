@extends('layouts.app')

@section('title', 'Detail Pinjaman')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.pinjaman.index') }}">Manajemen Pinjaman</a></li>
            <li class="breadcrumb-item active">{{ $pinjaman->no_pinjaman }}</li>
        </ol>
    </nav>

    <div class="row">
        <!-- Info Pinjaman -->
        <div class="col-lg-4 mb-4">
            <div class="card">
                <div class="card-header bg-{{ $pinjaman->status == 'aktif' ? 'warning' : ($pinjaman->status == 'lunas' ? 'success' : 'danger') }} text-white">
                    <h5 class="mb-0">{{ $pinjaman->no_pinjaman }}</h5>
                </div>
                <div class="card-body">
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-muted">Anggota</td>
                            <td>
                                <a href="{{ route('admin.anggota.show', $pinjaman->anggota_id) }}">
                                    <strong>{{ $pinjaman->anggota->nama_anggota }}</strong>
                                </a>
                                <br><small class="text-muted">{{ $pinjaman->anggota->no_anggota }}</small>
                            </td>
                        </tr>
                        <tr>
                            <td class="text-muted">Produk</td>
                            <td><strong>{{ $pinjaman->produkPinjaman->nama_produk }}</strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Status</td>
                            <td>{!! $pinjaman->status_label !!}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tanggal Pinjaman</td>
                            <td>{{ \Carbon\Carbon::parse($pinjaman->tanggal_pinjaman)->format('d/m/Y') }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Jatuh Tempo</td>
                            <td>{{ \Carbon\Carbon::parse($pinjaman->tanggal_jatuh_tempo)->format('d/m/Y') }}</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Bunga</td>
                            <td>{{ $pinjaman->bunga_persen }}% / tahun</td>
                        </tr>
                        <tr>
                            <td class="text-muted">Tenor</td>
                            <td>{{ $pinjaman->tenor }} bulan</td>
                        </tr>
                    </table>
                    <hr>
                    <table class="table table-sm table-borderless">
                        <tr>
                            <td class="text-muted">Jumlah Pinjaman</td>
                            <td class="text-end"><strong>Rp {{ number_format($pinjaman->jumlah_pinjaman, 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Sisa Pokok</td>
                            <td class="text-end text-danger"><strong>Rp {{ number_format($pinjaman->saldo_pokok, 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td class="text-muted">Angsuran/bulan</td>
                            <td class="text-end">Rp {{ number_format($pinjaman->total_angsuran, 0, ',', '.') }}</td>
                        </tr>
                    </table>
                    <hr>
                    <div class="progress mb-2" style="height: 25px;">
                        <div class="progress-bar bg-success" style="width: {{ $pinjaman->persentase_lunas }}%">
                            {{ $pinjaman->persentase_lunas }}%
                        </div>
                    </div>
                    <p class="text-center text-muted mb-0">{{ $pinjaman->angsuran_ke }} / {{ $pinjaman->tenor }} angsuran terbayar</p>
                </div>
            </div>
        </div>

        <!-- Jadwal Angsuran -->
        <div class="col-lg-8 mb-4">
            <div class="card">
                <div class="card-header bg-white d-flex justify-content-between align-items-center">
                    <h5 class="mb-0"><i class="fas fa-calendar-alt me-2"></i>Jadwal Angsuran</h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th class="text-center">Ke-</th>
                                    <th>Jatuh Tempo</th>
                                    <th class="text-end">Pokok</th>
                                    <th class="text-end">Bunga</th>
                                    <th class="text-end">Total</th>
                                    <th class="text-center">Status</th>
                                    <th>Tanggal Bayar</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($pinjaman->angsuran as $ang)
                                    <tr class="{{ $ang->status == 'lunas' ? 'table-success' : ($ang->status == 'terlambat' ? 'table-danger' : '') }}">
                                        <td class="text-center">{{ $ang->angsuran_ke }}</td>
                                        <td>{{ \Carbon\Carbon::parse($ang->tanggal_jatuh_tempo)->format('d/m/Y') }}</td>
                                        <td class="text-end">Rp {{ number_format($ang->angsuran_pokok, 0, ',', '.') }}</td>
                                        <td class="text-end">Rp {{ number_format($ang->angsuran_bunga, 0, ',', '.') }}</td>
                                        <td class="text-end"><strong>Rp {{ number_format($ang->total_angsuran, 0, ',', '.') }}</strong></td>
                                        <td class="text-center">
                                            @if($ang->status == 'lunas')
                                                <span class="badge bg-success">Lunas</span>
                                            @elseif($ang->status == 'terlambat')
                                                <span class="badge bg-danger">Terlambat</span>
                                            @elseif($ang->status == 'sebagian')
                                                <span class="badge bg-warning">Sebagian</span>
                                            @else
                                                <span class="badge bg-secondary">Belum Bayar</span>
                                            @endif
                                        </td>
                                        <td>{{ $ang->tanggal_bayar ? \Carbon\Carbon::parse($ang->tanggal_bayar)->format('d/m/Y') : '-' }}</td>
                                        <td>
                                            @if($ang->status != 'lunas' && $pinjaman->status == 'aktif')
                                                <a href="{{ route('admin.pinjaman.bayar-angsuran', [$pinjaman->id, $ang->id]) }}" class="btn btn-sm btn-success">
                                                    <i class="fas fa-money-bill"></i> Bayar
                                                </a>
                                            @endif
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
