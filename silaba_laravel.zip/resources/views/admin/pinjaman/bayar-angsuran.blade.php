@extends('layouts.app')

@section('title', 'Bayar Angsuran')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.pinjaman.index') }}">Pinjaman</a></li>
            <li class="breadcrumb-item"><a href="{{ route('admin.pinjaman.show', $pinjaman->id) }}">{{ $pinjaman->no_pinjaman }}</a></li>
            <li class="breadcrumb-item active">Bayar Angsuran ke-{{ $angsuran->angsuran_ke }}</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-6">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-money-bill me-2"></i>Form Pembayaran Angsuran</h5>
                </div>
                <div class="card-body">
                    <div class="alert alert-info">
                        <strong>Info Pinjaman:</strong><br>
                        Anggota: {{ $pinjaman->anggota->nama_anggota }}<br>
                        No. Pinjaman: {{ $pinjaman->no_pinjaman }}<br>
                        Produk: {{ $pinjaman->produkPinjaman->nama_produk }}
                    </div>

                    <form action="{{ route('admin.pinjaman.proses-bayar-angsuran', [$pinjaman->id, $angsuran->id]) }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label">Angsuran Ke</label>
                            <input type="text" class="form-control" value="{{ $angsuran->angsuran_ke }} dari {{ $pinjaman->tenor }}" disabled>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jatuh Tempo</label>
                            <input type="text" class="form-control" value="{{ \Carbon\Carbon::parse($angsuran->tanggal_jatuh_tempo)->format('d/m/Y') }}" disabled>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-4">
                                <label class="form-label">Angsuran Pokok</label>
                                <input type="text" class="form-control" value="Rp {{ number_format($angsuran->angsuran_pokok, 0, ',', '.') }}" disabled>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Angsuran Bunga</label>
                                <input type="text" class="form-control" value="Rp {{ number_format($angsuran->angsuran_bunga, 0, ',', '.') }}" disabled>
                            </div>
                            <div class="col-md-4">
                                <label class="form-label">Total Angsuran</label>
                                <input type="text" class="form-control bg-success text-white" value="Rp {{ number_format($angsuran->total_angsuran, 0, ',', '.') }}" disabled>
                            </div>
                        </div>

                        <hr>

                        <div class="mb-3">
                            <label class="form-label">Tanggal Bayar <span class="text-danger">*</span></label>
                            <input type="date" name="tanggal_bayar" class="form-control @error('tanggal_bayar') is-invalid @enderror"
                                   value="{{ old('tanggal_bayar', date('Y-m-d')) }}" required>
                            @error('tanggal_bayar')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jumlah Bayar <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="number" name="jumlah_bayar" class="form-control @error('jumlah_bayar') is-invalid @enderror"
                                       value="{{ old('jumlah_bayar', $angsuran->total_angsuran) }}" required>
                            </div>
                            @error('jumlah_bayar')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Sumber Dana</label>
                            <select name="jenis_masuk" class="form-select">
                                <option value="kas">Kas</option>
                                <option value="bank">Bank</option>
                            </select>
                        </div>

                        <hr>
                        <div class="d-flex gap-2">
                            <a href="{{ route('admin.pinjaman.show', $pinjaman->id) }}" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-check me-2"></i>Proses Pembayaran
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-6">
            <div class="card">
                <div class="card-header">
                    <h6 class="mb-0">Sisa Pinjaman</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <td>Sisa Pokok Saat Ini</td>
                            <td class="text-end text-danger"><strong>Rp {{ number_format($pinjaman->saldo_pokok, 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td>Setelah Bayar Angsuran Ini</td>
                            <td class="text-end text-success"><strong>Rp {{ number_format($pinjaman->saldo_pokok - $angsuran->angsuran_pokok, 0, ',', '.') }}</strong></td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
