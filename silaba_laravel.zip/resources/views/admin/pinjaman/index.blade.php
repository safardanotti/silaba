@extends('layouts.app')

@section('title', 'Manajemen Pinjaman')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4><i class="fas fa-hand-holding-usd me-2"></i>Manajemen Pinjaman</h4>
        <a href="{{ route('admin.pinjaman.create') }}" class="btn btn-success">
            <i class="fas fa-plus me-2"></i>Buat Pinjaman Baru
        </a>
    </div>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h6>Total Pinjaman Disalurkan</h6>
                    <h4 class="mb-0">Rp {{ number_format($summary['total_pinjaman'], 0, ',', '.') }}</h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-danger text-white">
                <div class="card-body">
                    <h6>Total Sisa Piutang</h6>
                    <h4 class="mb-0">Rp {{ number_format($summary['total_saldo'], 0, ',', '.') }}</h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h6>Pinjaman Aktif</h6>
                    <h4 class="mb-0">{{ $summary['jumlah_aktif'] }} pinjaman</h4>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h6>Pinjaman Lunas</h6>
                    <h4 class="mb-0">{{ $summary['jumlah_lunas'] }} pinjaman</h4>
                </div>
            </div>
        </div>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Cari no pinjaman / nama anggota..." value="{{ request('search') }}">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="aktif" {{ request('status') == 'aktif' ? 'selected' : '' }}>Aktif</option>
                        <option value="lunas" {{ request('status') == 'lunas' ? 'selected' : '' }}>Lunas</option>
                        <option value="macet" {{ request('status') == 'macet' ? 'selected' : '' }}>Macet</option>
                    </select>
                </div>
                <div class="col-md-5">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="{{ route('admin.pinjaman.index') }}" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pinjaman</th>
                            <th>Anggota</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-end">Sisa Pokok</th>
                            <th class="text-center">Progress</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pinjaman as $p)
                            <tr>
                                <td><strong>{{ $p->no_pinjaman }}</strong></td>
                                <td>
                                    {{ $p->anggota->nama_anggota }}
                                    <br><small class="text-muted">{{ $p->anggota->no_anggota }}</small>
                                </td>
                                <td>{{ $p->produkPinjaman->nama_produk }}</td>
                                <td class="text-end">Rp {{ number_format($p->jumlah_pinjaman, 0, ',', '.') }}</td>
                                <td class="text-end text-danger">Rp {{ number_format($p->saldo_pokok, 0, ',', '.') }}</td>
                                <td class="text-center">
                                    <div class="progress" style="height: 20px; width: 100px;">
                                        <div class="progress-bar bg-success" style="width: {{ $p->persentase_lunas }}%">
                                            {{ $p->persentase_lunas }}%
                                        </div>
                                    </div>
                                    <small>{{ $p->angsuran_ke }}/{{ $p->tenor }}</small>
                                </td>
                                <td class="text-center">{!! $p->status_label !!}</td>
                                <td>
                                    <a href="{{ route('admin.pinjaman.show', $p->id) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada data pinjaman
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            {{ $pinjaman->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
