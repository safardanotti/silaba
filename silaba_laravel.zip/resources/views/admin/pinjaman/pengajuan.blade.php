@extends('layouts.app')

@section('title', 'Pengajuan Pinjaman')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4>
            <i class="fas fa-file-alt me-2"></i>Pengajuan Pinjaman
            @if($countPending > 0)
                <span class="badge bg-danger">{{ $countPending }} Pending</span>
            @endif
        </h4>
    </div>

    <!-- Filter -->
    <div class="card mb-4">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <select name="status" class="form-select">
                        <option value="">Semua Status</option>
                        <option value="pending" {{ request('status') == 'pending' ? 'selected' : '' }}>Pending</option>
                        <option value="diproses" {{ request('status') == 'diproses' ? 'selected' : '' }}>Diproses</option>
                        <option value="disetujui" {{ request('status') == 'disetujui' ? 'selected' : '' }}>Disetujui</option>
                        <option value="ditolak" {{ request('status') == 'ditolak' ? 'selected' : '' }}>Ditolak</option>
                        <option value="dicairkan" {{ request('status') == 'dicairkan' ? 'selected' : '' }}>Dicairkan</option>
                    </select>
                </div>
                <div class="col-md-8">
                    <button type="submit" class="btn btn-primary"><i class="fas fa-filter me-2"></i>Filter</button>
                    <a href="{{ route('admin.pinjaman.pengajuan') }}" class="btn btn-secondary">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Tabel -->
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>No. Pengajuan</th>
                            <th>Tanggal</th>
                            <th>Anggota</th>
                            <th>Produk</th>
                            <th class="text-end">Jumlah</th>
                            <th class="text-center">Tenor</th>
                            <th class="text-center">Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pengajuan as $p)
                            <tr class="{{ $p->status == 'pending' ? 'table-warning' : '' }}">
                                <td><strong>{{ $p->no_pengajuan }}</strong></td>
                                <td>{{ $p->created_at->format('d/m/Y H:i') }}</td>
                                <td>
                                    {{ $p->anggota->nama_anggota }}
                                    <br><small class="text-muted">{{ $p->anggota->no_anggota }}</small>
                                </td>
                                <td>{{ $p->produkPinjaman->nama_produk }}</td>
                                <td class="text-end">Rp {{ number_format($p->jumlah_pinjaman, 0, ',', '.') }}</td>
                                <td class="text-center">{{ $p->tenor }} bln</td>
                                <td class="text-center">{!! $p->status_label !!}</td>
                                <td>
                                    <a href="{{ route('admin.pinjaman.pengajuan-detail', $p->id) }}" class="btn btn-sm btn-info">
                                        <i class="fas fa-eye"></i> Proses
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="8" class="text-center py-4 text-muted">
                                    Tidak ada pengajuan pinjaman
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
            
            {{ $pengajuan->withQueryString()->links() }}
        </div>
    </div>
</div>
@endsection
