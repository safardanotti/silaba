@extends('layouts.app')

@section('title', 'Buat Pinjaman Baru')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.pinjaman.index') }}">Manajemen Pinjaman</a></li>
            <li class="breadcrumb-item active">Buat Pinjaman Baru</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h5 class="mb-0"><i class="fas fa-plus me-2"></i>Form Pinjaman Baru</h5>
                </div>
                <div class="card-body">
                    <form action="{{ route('admin.pinjaman.store') }}" method="POST">
                        @csrf

                        <div class="mb-3">
                            <label class="form-label">Anggota <span class="text-danger">*</span></label>
                            <select name="anggota_id" id="anggota_id" class="form-select @error('anggota_id') is-invalid @enderror" required>
                                <option value="">-- Pilih Anggota --</option>
                                @foreach($anggota as $a)
                                    <option value="{{ $a->id }}" {{ old('anggota_id') == $a->id ? 'selected' : '' }}>
                                        {{ $a->no_anggota }} - {{ $a->nama_anggota }}
                                    </option>
                                @endforeach
                            </select>
                            @error('anggota_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Produk Pinjaman <span class="text-danger">*</span></label>
                            <select name="produk_pinjaman_id" id="produk_pinjaman_id" class="form-select @error('produk_pinjaman_id') is-invalid @enderror" required>
                                <option value="">-- Pilih Produk --</option>
                                @foreach($produk as $p)
                                    <option value="{{ $p->id }}" 
                                            data-bunga="{{ $p->bunga_persen }}"
                                            data-min="{{ $p->min_pinjaman }}"
                                            data-max="{{ $p->max_pinjaman }}"
                                            data-max-tenor="{{ $p->max_tenor }}"
                                            {{ old('produk_pinjaman_id') == $p->id ? 'selected' : '' }}>
                                        {{ $p->kode_produk }} - {{ $p->nama_produk }} ({{ $p->bunga_persen }}%/tahun)
                                    </option>
                                @endforeach
                            </select>
                            @error('produk_pinjaman_id')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                            <small class="text-muted" id="produkInfo"></small>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Jumlah Pinjaman <span class="text-danger">*</span></label>
                            <div class="input-group">
                                <span class="input-group-text">Rp</span>
                                <input type="text" name="jumlah_pinjaman" id="jumlah_pinjaman" 
                                       class="form-control @error('jumlah_pinjaman') is-invalid @enderror"
                                       value="{{ old('jumlah_pinjaman') }}"
                                       onkeyup="formatCurrency(this); hitungSimulasi();"
                                       required>
                            </div>
                            @error('jumlah_pinjaman')
                                <div class="text-danger small">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tenor (bulan) <span class="text-danger">*</span></label>
                                <input type="number" name="tenor" id="tenor" class="form-control @error('tenor') is-invalid @enderror"
                                       value="{{ old('tenor', 12) }}" min="1" onchange="hitungSimulasi();" required>
                                @error('tenor')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Tanggal Pencairan <span class="text-danger">*</span></label>
                                <input type="date" name="tanggal_pinjaman" class="form-control @error('tanggal_pinjaman') is-invalid @enderror"
                                       value="{{ old('tanggal_pinjaman', date('Y-m-d')) }}" required>
                                @error('tanggal_pinjaman')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Sumber Dana</label>
                            <select name="jenis_keluar" class="form-select">
                                <option value="kas">Kas</option>
                                <option value="bank">Bank</option>
                            </select>
                        </div>

                        <hr>
                        <div class="d-flex gap-2">
                            <a href="{{ route('admin.pinjaman.index') }}" class="btn btn-secondary">
                                <i class="fas fa-arrow-left me-2"></i>Kembali
                            </a>
                            <button type="submit" class="btn btn-success">
                                <i class="fas fa-save me-2"></i>Simpan & Cairkan
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Simulasi -->
        <div class="col-lg-4">
            <div class="card sticky-top" style="top: 20px;">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Simulasi Angsuran</h6>
                </div>
                <div class="card-body" id="simulasiResult">
                    <div class="text-center text-muted py-4">
                        <i class="fas fa-calculator fa-3x mb-3"></i>
                        <p>Pilih produk dan jumlah untuk melihat simulasi</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@push('scripts')
<script>
function formatCurrency(input) {
    let value = input.value.replace(/[^\d]/g, '');
    if (value) {
        value = parseInt(value).toLocaleString('id-ID');
    }
    input.value = value;
}

function parseCurrency(value) {
    return parseInt(value.replace(/\./g, '')) || 0;
}

document.getElementById('produk_pinjaman_id').addEventListener('change', function() {
    const option = this.options[this.selectedIndex];
    if (option.value) {
        const min = parseInt(option.dataset.min).toLocaleString('id-ID');
        const max = parseInt(option.dataset.max).toLocaleString('id-ID');
        const maxTenor = option.dataset.maxTenor;
        document.getElementById('produkInfo').innerHTML = 
            `Range: Rp ${min} - Rp ${max} | Max tenor: ${maxTenor} bulan`;
        document.getElementById('tenor').max = maxTenor;
    }
    hitungSimulasi();
});

function hitungSimulasi() {
    const produkSelect = document.getElementById('produk_pinjaman_id');
    const option = produkSelect.options[produkSelect.selectedIndex];
    const jumlahInput = document.getElementById('jumlah_pinjaman');
    const tenorInput = document.getElementById('tenor');
    
    if (!option.value || !jumlahInput.value || !tenorInput.value) return;
    
    const jumlah = parseCurrency(jumlahInput.value);
    const tenor = parseInt(tenorInput.value);
    const bunga = parseFloat(option.dataset.bunga);
    
    if (jumlah <= 0 || tenor <= 0) return;
    
    const bungaPerBulan = bunga / 100 / 12;
    const totalBunga = jumlah * bungaPerBulan * tenor;
    const angsuranPokok = jumlah / tenor;
    const angsuranBunga = totalBunga / tenor;
    const totalAngsuran = angsuranPokok + angsuranBunga;
    
    document.getElementById('simulasiResult').innerHTML = `
        <table class="table table-sm mb-0">
            <tr>
                <td>Jumlah Pinjaman</td>
                <td class="text-end"><strong>Rp ${jumlah.toLocaleString('id-ID')}</strong></td>
            </tr>
            <tr>
                <td>Bunga/tahun</td>
                <td class="text-end">${bunga}%</td>
            </tr>
            <tr>
                <td>Tenor</td>
                <td class="text-end">${tenor} bulan</td>
            </tr>
            <tr class="table-light">
                <td colspan="2"><strong>Perhitungan</strong></td>
            </tr>
            <tr>
                <td>Angsuran Pokok/bln</td>
                <td class="text-end">Rp ${Math.round(angsuranPokok).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Angsuran Bunga/bln</td>
                <td class="text-end">Rp ${Math.round(angsuranBunga).toLocaleString('id-ID')}</td>
            </tr>
            <tr class="table-success">
                <td><strong>Total/bulan</strong></td>
                <td class="text-end fs-5"><strong>Rp ${Math.round(totalAngsuran).toLocaleString('id-ID')}</strong></td>
            </tr>
            <tr>
                <td>Total Bunga</td>
                <td class="text-end">Rp ${Math.round(totalBunga).toLocaleString('id-ID')}</td>
            </tr>
            <tr>
                <td>Total Bayar</td>
                <td class="text-end"><strong>Rp ${Math.round(jumlah + totalBunga).toLocaleString('id-ID')}</strong></td>
            </tr>
        </table>
    `;
}
</script>
@endpush
@endsection
