@extends('layouts.app')

@section('title', 'Detail Pengajuan Pinjaman')

@section('content')
<div class="container-fluid">
    <nav aria-label="breadcrumb" class="mb-3">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.pinjaman.pengajuan') }}">Pengajuan Pinjaman</a></li>
            <li class="breadcrumb-item active">{{ $pengajuan->no_pengajuan }}</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ $pengajuan->no_pengajuan }}</h5>
                    {!! $pengajuan->status_label !!}
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="text-muted">Data Anggota</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td>No. Anggota</td>
                                    <td><strong>{{ $pengajuan->anggota->no_anggota }}</strong></td>
                                </tr>
                                <tr>
                                    <td>Nama</td>
                                    <td><strong>{{ $pengajuan->anggota->nama_anggota }}</strong></td>
                                </tr>
                                <tr>
                                    <td>Unit Kerja</td>
                                    <td>{{ $pengajuan->anggota->unit_kerja ?? '-' }}</td>
                                </tr>
                                <tr>
                                    <td>No. HP</td>
                                    <td>{{ $pengajuan->anggota->no_hp ?? '-' }}</td>
                                </tr>
                            </table>
                        </div>
                        <div class="col-md-6">
                            <h6 class="text-muted">Data Pengajuan</h6>
                            <table class="table table-sm table-borderless">
                                <tr>
                                    <td>Tanggal Pengajuan</td>
                                    <td>{{ $pengajuan->created_at->format('d/m/Y H:i') }}</td>
                                </tr>
                                <tr>
                                    <td>Produk</td>
                                    <td><strong>{{ $pengajuan->produkPinjaman->nama_produk }}</strong></td>
                                </tr>
                                <tr>
                                    <td>Jumlah</td>
                                    <td class="fs-5 text-primary"><strong>Rp {{ number_format($pengajuan->jumlah_pinjaman, 0, ',', '.') }}</strong></td>
                                </tr>
                                <tr>
                                    <td>Tenor</td>
                                    <td><strong>{{ $pengajuan->tenor }} bulan</strong></td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <div class="mb-4">
                        <h6 class="text-muted">Keperluan</h6>
                        <p class="border rounded p-3 bg-light">{{ $pengajuan->keperluan }}</p>
                    </div>

                    <!-- Dokumen -->
                    <h6 class="text-muted">Dokumen Persyaratan</h6>
                    <div class="row">
                        @if($pengajuan->dok_ktp)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-id-card fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">KTP</p>
                                    <a href="{{ Storage::url($pengajuan->dok_ktp) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        @endif
                        @if($pengajuan->dok_kk)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-users fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Kartu Keluarga</p>
                                    <a href="{{ Storage::url($pengajuan->dok_kk) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        @endif
                        @if($pengajuan->dok_slip_gaji)
                            <div class="col-md-4 mb-3">
                                <div class="border rounded p-3 text-center">
                                    <i class="fas fa-file-invoice-dollar fa-2x mb-2 text-muted"></i>
                                    <p class="mb-2">Slip Gaji</p>
                                    <a href="{{ Storage::url($pengajuan->dok_slip_gaji) }}" target="_blank" class="btn btn-sm btn-outline-primary">
                                        <i class="fas fa-eye me-1"></i>Lihat
                                    </a>
                                </div>
                            </div>
                        @endif
                    </div>

                    @if($pengajuan->catatan_approval)
                        <div class="alert alert-{{ $pengajuan->status == 'ditolak' ? 'danger' : 'info' }} mt-3">
                            <strong>Catatan:</strong> {{ $pengajuan->catatan_approval }}
                        </div>
                    @endif

                    <!-- Actions -->
                    @if($pengajuan->status == 'pending' || $pengajuan->status == 'diproses')
                        <hr>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <form action="{{ route('admin.pinjaman.pengajuan-approve', $pengajuan->id) }}" method="POST">
                                    @csrf
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Catatan (opsional)"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-success w-100">
                                        <i class="fas fa-check me-2"></i>Setujui Pengajuan
                                    </button>
                                </form>
                            </div>
                            <div class="col-md-6 mb-3">
                                <form action="{{ route('admin.pinjaman.pengajuan-tolak', $pengajuan->id) }}" method="POST">
                                    @csrf
                                    <div class="mb-2">
                                        <textarea name="catatan" class="form-control" rows="2" placeholder="Alasan penolakan (wajib)" required></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-danger w-100">
                                        <i class="fas fa-times me-2"></i>Tolak Pengajuan
                                    </button>
                                </form>
                            </div>
                        </div>
                    @endif

                    <!-- Cairkan -->
                    @if($pengajuan->status == 'disetujui')
                        <hr>
                        <div class="alert alert-success">
                            <strong><i class="fas fa-check-circle me-2"></i>Pengajuan Disetujui</strong>
                            <p class="mb-0">Silakan cairkan pinjaman ini.</p>
                        </div>
                        <form action="{{ route('admin.pinjaman.cairkan', $pengajuan->id) }}" method="POST" class="row">
                            @csrf
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Tanggal Pencairan</label>
                                <input type="date" name="tanggal_pinjaman" class="form-control" value="{{ date('Y-m-d') }}" required>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label">Sumber Dana</label>
                                <select name="jenis_keluar" class="form-select" required>
                                    <option value="kas">Kas</option>
                                    <option value="bank">Bank</option>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100">
                                    <i class="fas fa-money-bill-wave me-2"></i>Cairkan Pinjaman
                                </button>
                            </div>
                        </form>
                    @endif
                </div>
            </div>
        </div>

        <!-- Simulasi -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-header bg-info text-white">
                    <h6 class="mb-0"><i class="fas fa-calculator me-2"></i>Simulasi Angsuran</h6>
                </div>
                <div class="card-body">
                    <table class="table table-sm">
                        <tr>
                            <td>Jumlah Pinjaman</td>
                            <td class="text-end"><strong>Rp {{ number_format($pengajuan->jumlah_pinjaman, 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td>Bunga/tahun</td>
                            <td class="text-end">{{ $pengajuan->produkPinjaman->bunga_persen }}%</td>
                        </tr>
                        <tr>
                            <td>Tenor</td>
                            <td class="text-end">{{ $pengajuan->tenor }} bulan</td>
                        </tr>
                        <tr class="table-light">
                            <td colspan="2"><strong>Perhitungan</strong></td>
                        </tr>
                        <tr>
                            <td>Angsuran Pokok/bln</td>
                            <td class="text-end">Rp {{ number_format($simulasi['angsuran_pokok'], 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <td>Angsuran Bunga/bln</td>
                            <td class="text-end">Rp {{ number_format($simulasi['angsuran_bunga'], 0, ',', '.') }}</td>
                        </tr>
                        <tr class="table-success">
                            <td><strong>Total Angsuran/bln</strong></td>
                            <td class="text-end fs-5"><strong>Rp {{ number_format($simulasi['total_angsuran'], 0, ',', '.') }}</strong></td>
                        </tr>
                        <tr>
                            <td>Total Bunga</td>
                            <td class="text-end">Rp {{ number_format($simulasi['total_bunga'], 0, ',', '.') }}</td>
                        </tr>
                        <tr>
                            <td>Total Bayar</td>
                            <td class="text-end"><strong>Rp {{ number_format($pengajuan->jumlah_pinjaman + $simulasi['total_bunga'], 0, ',', '.') }}</strong></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Riwayat Anggota -->
            <div class="card mt-3">
                <div class="card-header">
                    <h6 class="mb-0">Riwayat Pinjaman Anggota</h6>
                </div>
                <div class="card-body">
                    @php
                        $riwayatPinjaman = $pengajuan->anggota->pinjaman ?? collect();
                    @endphp
                    @if($riwayatPinjaman->count() > 0)
                        @foreach($riwayatPinjaman->take(3) as $pinj)
                            <div class="border-bottom pb-2 mb-2">
                                <div class="d-flex justify-content-between">
                                    <small>{{ $pinj->no_pinjaman }}</small>
                                    {!! $pinj->status_label !!}
                                </div>
                                <small class="text-muted">Rp {{ number_format($pinj->jumlah_pinjaman, 0, ',', '.') }}</small>
                            </div>
                        @endforeach
                    @else
                        <p class="text-muted mb-0">Belum ada riwayat pinjaman</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
