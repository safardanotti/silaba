@extends('layouts.app')

@section('title', 'Input Transaksi Rupa-rupa')
@section('page-title')
    <i class="fas fa-exchange-alt text-info"></i> Input Transaksi Rupa-rupa
@endsection

@push('styles')
<style>
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
    }
</style>
@endpush

@section('content')
<form method="POST" action="{{ route('transaksi.rupa-rupa.store') }}" id="formRupaRupa">
    @csrf
    <input type="hidden" id="jenis_transaksi" value="rupa_rupa">
    
    <div class="card">
        <div class="card-header">
            <h3 class="mb-0">Form Input Rupa-rupa</h3>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Tanggal Transaksi *</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" 
                               value="{{ old('tanggal', date('Y-m-d')) }}" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Uraian Kegiatan *</label>
                        <input type="text" class="form-control" id="uraian_kegiatan" name="uraian_kegiatan" 
                               placeholder="Contoh: JURNAL PENYESUAIAN" 
                               value="{{ old('uraian_kegiatan') }}" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Jenis (Opsional)</label>
                        <select class="form-select" id="jenis_masuk" name="jenis_masuk">
                            <option value="">-- Tidak Ada --</option>
                            <option value="kas" {{ old('jenis_masuk') == 'kas' ? 'selected' : '' }}>KAS</option>
                            <option value="bank" {{ old('jenis_masuk') == 'bank' ? 'selected' : '' }}>BANK</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>Detail Jurnal Transaksi</h4>
                <button type="button" class="btn btn-primary btn-sm" onclick="addTransactionRow()">
                    <i class="fas fa-plus"></i> Tambah Baris
                </button>
            </div>
            
            <div class="alert alert-warning mb-3" id="balanceWarning" style="display: none;">
                <i class="fas fa-exclamation-triangle"></i> Perhatian: Total Debet dan Kredit harus balance!
            </div>
            
            <div class="alert alert-info mb-3">
                <i class="fas fa-info-circle"></i> <strong>Tips:</strong> Transaksi Rupa-rupa digunakan untuk jurnal penyesuaian, koreksi, atau transaksi non-kas/bank.
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">NO</th>
                            <th width="200">KODE AKUN</th>
                            <th>NAMA AKUN</th>
                            <th width="120">TANGGAL</th>
                            <th width="180">DEBET (Rp)</th>
                            <th width="180">KREDIT (Rp)</th>
                            <th width="50">AKSI</th>
                        </tr>
                    </thead>
                    <tbody id="transactionDetails">
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="4" class="text-end"><strong>TOTAL:</strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalDebet">0</span></strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalKredit">0</span></strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end"><strong>SELISIH:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong class="currency-display">Rp <span id="selisih">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Simpan Transaksi
                </button>
                <a href="{{ route('laporan.transaksi') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</form>
@endsection

@push('scripts')
<script>
const kodeAkunData = @json($kodeAkun);

// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format input saat mengetik
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

function addTransactionRow() {
    const tbody = document.getElementById('transactionDetails');
    const rowCount = tbody.rows.length + 1;
    const tanggal = document.getElementById('tanggal').value;
    
    const row = tbody.insertRow();
    row.innerHTML = `
        <td>${rowCount}</td>
        <td>
            <select name="kode_akun[]" class="form-select kode-akun-select" required onchange="updateAccountName(this)">
                <option value="">Pilih Kode Akun</option>
                ${kodeAkunData.map(akun => 
                    `<option value="${akun.kode_akun}" data-nama="${akun.nama_akun}">${akun.kode_akun} - ${akun.nama_akun}</option>`
                ).join('')}
            </select>
        </td>
        <td class="nama-akun">-</td>
        <td>${tanggal}</td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="debet[]" class="form-control currency-input" 
                       onkeyup="formatCurrencyInput(this); calculateTotal();" 
                       onfocus="this.select();" value="0" placeholder="0">
            </div>
        </td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="kredit[]" class="form-control currency-input" 
                       onkeyup="formatCurrencyInput(this); calculateTotal();" 
                       onfocus="this.select();" value="0" placeholder="0">
            </div>
        </td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
}

function updateAccountName(select) {
    const namaAkun = select.options[select.selectedIndex].dataset.nama || '-';
    select.closest('tr').querySelector('.nama-akun').textContent = namaAkun;
}

function removeRow(btn) {
    btn.closest('tr').remove();
    updateRowNumbers();
    calculateTotal();
}

function updateRowNumbers() {
    const tbody = document.getElementById('transactionDetails');
    tbody.querySelectorAll('tr').forEach((row, index) => {
        row.cells[0].textContent = index + 1;
    });
}

function calculateTotal() {
    let totalDebet = 0;
    let totalKredit = 0;
    
    document.querySelectorAll('input[name="debet[]"]').forEach(input => {
        totalDebet += parseRupiah(input.value);
    });
    
    document.querySelectorAll('input[name="kredit[]"]').forEach(input => {
        totalKredit += parseRupiah(input.value);
    });
    
    document.getElementById('totalDebet').textContent = formatRupiah(totalDebet);
    document.getElementById('totalKredit').textContent = formatRupiah(totalKredit);
    document.getElementById('selisih').textContent = formatRupiah(Math.abs(totalDebet - totalKredit));
    
    const selisihElement = document.getElementById('selisih');
    const warningElement = document.getElementById('balanceWarning');
    
    if (Math.abs(totalDebet - totalKredit) > 0.01) {
        selisihElement.style.color = 'red';
        warningElement.style.display = 'block';
    } else {
        selisihElement.style.color = 'green';
        warningElement.style.display = 'none';
    }
}

function updateAllDetailRows() {
    const tanggal = document.getElementById('tanggal').value;
    document.querySelectorAll('#transactionDetails tr').forEach(row => {
        if (row.cells[3]) row.cells[3].textContent = tanggal;
    });
}

document.addEventListener('DOMContentLoaded', function() {
    addTransactionRow();
    addTransactionRow(); // Add 2 rows by default for rupa-rupa
    document.getElementById('tanggal').addEventListener('change', updateAllDetailRows);
});
</script>
@endpush
