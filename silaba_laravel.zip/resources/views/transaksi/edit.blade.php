@extends('layouts.app')

@section('title', 'Edit Transaksi')
@section('page-title')
    <i class="fas fa-edit"></i> Edit Transaksi
@endsection

@push('styles')
<style>
    .table-container {
        overflow-x: auto;
    }
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .currency-display {
        font-family: 'Courier New', monospace;
        font-weight: 600;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
    }
    #balanceWarning {
        display: none;
    }
    #balanceWarning.show {
        display: block;
    }
</style>
@endpush

@section('content')
<form method="POST" action="{{ route('transaksi.update', $transaksi->id) }}">
    @csrf
    @method('PUT')
    <input type="hidden" id="jenis_transaksi" value="{{ $transaksi->jenis_transaksi }}">
    
    <div class="card">
        <div class="card-header">
            <h3>Form Edit Transaksi 
                @php
                    $jenisLabel = [
                        'penerimaan' => '<span class="badge bg-success">Penerimaan</span>',
                        'pengeluaran' => '<span class="badge bg-danger">Pengeluaran</span>',
                        'rupa_rupa' => '<span class="badge bg-info">Rupa-rupa</span>'
                    ];
                @endphp
                {!! $jenisLabel[$transaksi->jenis_transaksi] ?? '' !!}
            </h3>
        </div>
        <div class="card-body">
            <div class="row mb-3">
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Tanggal Transaksi *</label>
                        <input type="date" class="form-control" id="tanggal" name="tanggal" 
                               value="{{ old('tanggal', $transaksi->tanggal->format('Y-m-d')) }}" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Uraian Kegiatan *</label>
                        <input type="text" class="form-control" id="uraian_kegiatan" name="uraian_kegiatan" 
                               value="{{ old('uraian_kegiatan', $transaksi->uraian_kegiatan) }}" required>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label class="form-label">Jenis Masuk *</label>
                        <select class="form-select" id="jenis_masuk" name="jenis_masuk" required>
                            <option value="kas" {{ old('jenis_masuk', $transaksi->jenis_masuk) == 'kas' ? 'selected' : '' }}>KAS</option>
                            <option value="bank" {{ old('jenis_masuk', $transaksi->jenis_masuk) == 'bank' ? 'selected' : '' }}>BANK</option>
                        </select>
                    </div>
                </div>
            </div>
            
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h4>Detail Jurnal Transaksi</h4>
                <button type="button" class="btn btn-primary btn-sm" onclick="addTransactionRow()">
                    <i class="fas fa-plus"></i> Tambah Baris
                </button>
            </div>
            
            <div class="alert alert-warning mb-3" id="balanceWarning">
                <i class="fas fa-exclamation-triangle"></i> Perhatian: Total Debet dan Kredit harus balance!
            </div>
            
            <div class="table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th width="50">NO</th>
                            <th width="200">KODE AKUN</th>
                            <th>NAMA AKUN</th>
                            <th width="100">JENIS MASUK</th>
                            <th width="120">TANGGAL</th>
                            <th width="180">DEBET (Rp)</th>
                            <th width="180">KREDIT (Rp)</th>
                            <th width="50">AKSI</th>
                        </tr>
                    </thead>
                    <tbody id="transactionDetails">
                        @foreach($transaksi->detailTransaksi as $index => $detail)
                        <tr>
                            <td>{{ $index + 1 }}</td>
                            <td>
                                <select name="kode_akun[]" class="form-select" required onchange="updateAccountName(this)">
                                    <option value="">Pilih Kode Akun</option>
                                    @foreach($kodeAkun as $akun)
                                    <option value="{{ $akun->kode_akun }}" 
                                            data-nama="{{ $akun->nama_akun }}"
                                            {{ $detail->kode_akun == $akun->kode_akun ? 'selected' : '' }}>
                                        {{ $akun->kode_akun }} - {{ $akun->nama_akun }}
                                    </option>
                                    @endforeach
                                </select>
                            </td>
                            <td class="nama-akun">
                                @foreach($kodeAkun as $akun)
                                    @if($akun->kode_akun == $detail->kode_akun)
                                        {{ $akun->nama_akun }}
                                        @break
                                    @endif
                                @endforeach
                            </td>
                            <td class="jenis-masuk">{{ strtoupper($transaksi->jenis_masuk) }}</td>
                            <td>{{ $transaksi->tanggal->format('Y-m-d') }}</td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="debet[]" class="form-control currency-input" 
                                           value="{{ number_format($detail->debet, 0, ',', '.') }}">
                                </div>
                            </td>
                            <td>
                                <div class="input-group">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="kredit[]" class="form-control currency-input" 
                                           value="{{ number_format($detail->kredit, 0, ',', '.') }}">
                                </div>
                            </td>
                            <td>
                                <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                    <tfoot>
                        <tr>
                            <td colspan="5" class="text-end"><strong>TOTAL:</strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalDebet">0</span></strong></td>
                            <td class="text-end"><strong class="currency-display">Rp <span id="totalKredit">0</span></strong></td>
                            <td></td>
                        </tr>
                        <tr>
                            <td colspan="5" class="text-end"><strong>SELISIH:</strong></td>
                            <td colspan="2" class="text-center">
                                <strong class="currency-display">Rp <span id="selisih">0</span></strong>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            
            <div class="mt-4 d-flex gap-2">
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Update Transaksi
                </button>
                <a href="{{ route('laporan.transaksi') }}" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Kembali
                </a>
            </div>
        </div>
    </div>
</form>
@endsection

@push('scripts')
<script>
// Kode akun data untuk JavaScript
const kodeAkunData = @json($kodeAkun);

// Format angka ke Rupiah (tanpa simbol Rp)
function formatRupiah(angka) {
    if (angka === null || angka === undefined || isNaN(angka)) return '0';
    let number = parseFloat(angka);
    return number.toLocaleString('id-ID', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 2
    });
}

// Parse Rupiah string ke number
function parseRupiah(rupiahString) {
    if (!rupiahString) return 0;
    let cleanString = rupiahString.toString().replace(/[^\d,]/g, '');
    cleanString = cleanString.replace(/\./g, '').replace(',', '.');
    return parseFloat(cleanString) || 0;
}

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}

// Update account name when kode akun changes
function updateAccountName(select) {
    const row = select.closest('tr');
    const namaAkunCell = row.querySelector('.nama-akun');
    const selectedOption = select.options[select.selectedIndex];
    namaAkunCell.textContent = selectedOption.dataset.nama || '-';
    calculateTotal();
}

// Add new transaction row
function addTransactionRow() {
    const tbody = document.getElementById('transactionDetails');
    const rowCount = tbody.rows.length + 1;
    
    let optionsHtml = '<option value="">Pilih Kode Akun</option>';
    kodeAkunData.forEach(akun => {
        optionsHtml += `<option value="${akun.kode_akun}" data-nama="${akun.nama_akun}">${akun.kode_akun} - ${akun.nama_akun}</option>`;
    });
    
    const row = tbody.insertRow();
    row.innerHTML = `
        <td>${rowCount}</td>
        <td>
            <select name="kode_akun[]" class="form-select" required onchange="updateAccountName(this)">
                ${optionsHtml}
            </select>
        </td>
        <td class="nama-akun">-</td>
        <td class="jenis-masuk">${document.getElementById('jenis_masuk').value.toUpperCase()}</td>
        <td>${document.getElementById('tanggal').value}</td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="debet[]" class="form-control currency-input" value="0">
            </div>
        </td>
        <td>
            <div class="input-group">
                <span class="input-group-text currency-prefix">Rp</span>
                <input type="text" name="kredit[]" class="form-control currency-input" value="0">
            </div>
        </td>
        <td>
            <button type="button" class="btn btn-danger btn-sm" onclick="removeRow(this)">
                <i class="fas fa-trash"></i>
            </button>
        </td>
    `;
    
    initCurrencyInputs();
    updateRowNumbers();
}

// Remove row
function removeRow(btn) {
    const row = btn.closest('tr');
    const tbody = row.parentNode;
    
    if (tbody.rows.length > 1) {
        row.remove();
        updateRowNumbers();
        calculateTotal();
    } else {
        alert('Minimal harus ada 1 baris detail!');
    }
}

// Update row numbers
function updateRowNumbers() {
    const tbody = document.getElementById('transactionDetails');
    const rows = tbody.rows;
    for (let i = 0; i < rows.length; i++) {
        rows[i].cells[0].textContent = i + 1;
    }
}

// Calculate totals
function calculateTotal() {
    let totalDebet = 0;
    let totalKredit = 0;
    
    document.querySelectorAll('input[name="debet[]"]').forEach(input => {
        totalDebet += parseRupiah(input.value);
    });
    
    document.querySelectorAll('input[name="kredit[]"]').forEach(input => {
        totalKredit += parseRupiah(input.value);
    });
    
    document.getElementById('totalDebet').textContent = formatRupiah(totalDebet);
    document.getElementById('totalKredit').textContent = formatRupiah(totalKredit);
    
    const selisih = Math.abs(totalDebet - totalKredit);
    const selisihElement = document.getElementById('selisih');
    selisihElement.textContent = formatRupiah(selisih);
    
    // Show/hide balance warning
    const warningElement = document.getElementById('balanceWarning');
    if (selisih > 0.01) {
        warningElement.classList.add('show');
        selisihElement.style.color = '#dc3545';
    } else {
        warningElement.classList.remove('show');
        selisihElement.style.color = '#28a745';
    }
}

// Initialize currency inputs
function initCurrencyInputs() {
    document.querySelectorAll('input.currency-input').forEach(input => {
        input.addEventListener('input', function() {
            formatCurrencyInput(this);
            calculateTotal();
        });
        
        input.addEventListener('blur', function() {
            if (this.value === '') {
                this.value = '0';
            }
            formatCurrencyInput(this);
            calculateTotal();
        });
        
        input.addEventListener('focus', function() {
            this.select();
        });
    });
}

// Update jenis masuk display when changed
document.getElementById('jenis_masuk').addEventListener('change', function() {
    document.querySelectorAll('.jenis-masuk').forEach(td => {
        td.textContent = this.value.toUpperCase();
    });
});

// Initialize on load
document.addEventListener('DOMContentLoaded', function() {
    initCurrencyInputs();
    calculateTotal();
});
</script>
@endpush
