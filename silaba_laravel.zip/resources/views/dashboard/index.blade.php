@extends('layouts.app')

@section('title', 'Dashboard')
@section('page-title')
    Dashboard <span class="badge bg-info">V2</span>
@endsection

@section('content')
<div class="filter-section">
    <form method="GET" action="{{ route('dashboard') }}" class="row g-3 align-items-end">
        <div class="col-md-3">
            <label class="form-label">Pilih Bulan</label>
            <select name="bulan" class="form-select">
                @foreach($bulanNama as $key => $value)
                    <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>
                        {{ $value }}
                    </option>
                @endforeach
            </select>
        </div>
        <div class="col-md-3">
            <label class="form-label">Pilih Tahun</label>
            <select name="tahun" class="form-select">
                @for($y = 2020; $y <= 2030; $y++)
                    <option value="{{ $y }}" {{ $tahun == $y ? 'selected' : '' }}>
                        {{ $y }}
                    </option>
                @endfor
            </select>
        </div>
        <div class="col-md-3">
            <button type="submit" class="btn btn-light">
                <i class="fas fa-filter"></i> Tampilkan Data
            </button>
            <a href="{{ route('dashboard') }}" class="btn btn-outline-light">
                <i class="fas fa-undo"></i> Reset
            </a>
        </div>
        <div class="col-md-3 text-end">
            <div class="period-info">
                <i class="fas fa-calendar-alt"></i> 
                <strong>Periode: {{ $periodeDisplay }}</strong>
            </div>
        </div>
    </form>
</div>

<div class="stats-container">
    <div class="stat-card">
        <h4>Saldo Kas & Bank</h4>
        <h2>Rp {{ number_format($saldoAkhirKasBank, 2, ',', '.') }}</h2>
        <i class="fas fa-wallet stat-icon"></i>
        <small class="text-white-50">Saldo akhir {{ $periodeDisplay }}</small>
    </div>
    <div class="stat-card info">
        <h4>Penerimaan</h4>
        <h2>Rp {{ number_format($totalPenerimaan, 2, ',', '.') }}</h2>
        <i class="fas fa-arrow-down stat-icon"></i>
        <small class="text-white-50">{{ $periodeDisplay }}</small>
    </div>
    <div class="stat-card warning">
        <h4>Pengeluaran</h4>
        <h2>Rp {{ number_format($totalPengeluaran, 2, ',', '.') }}</h2>
        <i class="fas fa-arrow-up stat-icon"></i>
        <small class="text-white-50">{{ $periodeDisplay }}</small>
    </div>
    <div class="stat-card danger">
        <h4>Laba/Rugi</h4>
        <h2 class="{{ $labaRugi >= 0 ? 'text-white' : 'text-warning' }}">
            Rp {{ number_format(abs($labaRugi), 2, ',', '.') }}
        </h2>
        <i class="fas fa-chart-line stat-icon"></i>
        <small class="text-white-50">{{ $labaRugi >= 0 ? 'Laba' : 'Rugi' }} {{ $periodeDisplay }}</small>
    </div>
</div>

<div class="row">
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header bg-primary text-white">
                <h5 class="mb-0">
                    <i class="fas fa-chart-bar"></i> 
                    Penerimaan vs Pengeluaran - {{ $periodeDisplay }}
                </h5>
            </div>
            <div class="card-body">
                <canvas id="penerimaanPengeluaranChart" height="300"></canvas>
            </div>
        </div>
    </div>
    <div class="col-lg-6">
        <div class="card">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">
                    <i class="fas fa-chart-line"></i> 
                    Trend Saldo Kas & Bank - {{ $periodeDisplay }}
                </h5>
            </div>
            <div class="card-body">
                <canvas id="saldoKasBankChart" height="300"></canvas>
            </div>
        </div>
    </div>
</div>

<div class="card mt-4">
    <div class="card-header">
        <h5 class="mb-0">
            <i class="fas fa-list"></i> 
            Transaksi Terbaru - {{ $periodeDisplay }}
        </h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Jenis</th>
                        <th>Uraian</th>
                        <th>Kas/Bank</th>
                        <th>Debet</th>
                        <th>Kredit</th>
                        <th>Dibuat Oleh</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($transactions as $trans)
                        @php
                            $jenisLabel = [
                                'penerimaan' => '<span class="badge bg-success">Penerimaan</span>',
                                'pengeluaran' => '<span class="badge bg-danger">Pengeluaran</span>',
                                'rupa_rupa' => '<span class="badge bg-info">Rupa-rupa</span>'
                            ];
                            
                            $kasDebet = $trans->kas_debet ?? 0;
                            $kasKredit = $trans->kas_kredit ?? 0;
                            
                            if ($kasDebet > 0) {
                                $kasBank = '<span class="text-success">+' . number_format($kasDebet, 0, ',', '.') . '</span>';
                            } elseif ($kasKredit > 0) {
                                $kasBank = '<span class="text-danger">-' . number_format($kasKredit, 0, ',', '.') . '</span>';
                            } else {
                                $kasBank = '-';
                            }
                        @endphp
                        <tr>
                            <td>{{ $trans->tanggal->format('d/m/Y') }}</td>
                            <td>{!! $jenisLabel[$trans->jenis_transaksi] ?? '-' !!}</td>
                            <td>{{ Str::limit($trans->uraian_kegiatan, 50) }}</td>
                            <td class="text-center">{!! $kasBank !!}</td>
                            <td class="text-end">{{ number_format($trans->total_debet ?? 0, 0, ',', '.') }}</td>
                            <td class="text-end">{{ number_format($trans->total_kredit ?? 0, 0, ',', '.') }}</td>
                            <td><small>{{ $trans->user->full_name ?? '-' }}</small></td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center">Tidak ada transaksi pada periode {{ $periodeDisplay }}</td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Chart 1: Penerimaan vs Pengeluaran
    const ctx1 = document.getElementById('penerimaanPengeluaranChart').getContext('2d');
    new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: @json($chartLabels),
            datasets: [{
                label: 'Penerimaan',
                data: @json($chartPenerimaan),
                backgroundColor: 'rgba(40, 167, 69, 0.7)',
                borderColor: 'rgba(40, 167, 69, 1)',
                borderWidth: 1
            }, {
                label: 'Pengeluaran',
                data: @json($chartPengeluaran),
                backgroundColor: 'rgba(220, 53, 69, 0.7)',
                borderColor: 'rgba(220, 53, 69, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Tanggal'
                    }
                },
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            if (value >= 1000000) {
                                return 'Rp ' + (value/1000000).toFixed(1) + ' Jt';
                            }
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                            return label;
                        }
                    }
                }
            }
        }
    });
    
    // Chart 2: Trend Saldo Kas & Bank
    const ctx2 = document.getElementById('saldoKasBankChart').getContext('2d');
    new Chart(ctx2, {
        type: 'line',
        data: {
            labels: @json($chartLabels),
            datasets: [{
                label: 'Saldo Kas & Bank',
                data: @json($chartSaldo),
                borderColor: 'rgba(13, 110, 253, 1)',
                backgroundColor: 'rgba(13, 110, 253, 0.1)',
                tension: 0.3,
                fill: true,
                pointRadius: 3,
                pointHoverRadius: 5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Tanggal'
                    }
                },
                y: {
                    beginAtZero: false,
                    ticks: {
                        callback: function(value) {
                            if (value >= 1000000000) {
                                return 'Rp ' + (value/1000000000).toFixed(1) + ' M';
                            } else if (value >= 1000000) {
                                return 'Rp ' + (value/1000000).toFixed(1) + ' Jt';
                            }
                            return 'Rp ' + value.toLocaleString('id-ID');
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            let label = context.dataset.label || '';
                            if (label) {
                                label += ': ';
                            }
                            label += 'Rp ' + context.parsed.y.toLocaleString('id-ID');
                            return label;
                        }
                    }
                }
            }
        }
    });
});
</script>
@endpush
