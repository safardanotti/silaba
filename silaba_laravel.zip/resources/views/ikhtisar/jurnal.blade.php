@extends('layouts.app')

@section('title', 'Ikhtisar Jurnal')
@section('page-title', 'Ikhtisar Jurnal')

@push('styles')
<style>
    .jurnal-table {
        font-size: 0.9rem;
    }
    .jurnal-table th {
        background-color: #f8f9fa;
        border: 1px solid #dee2e6;
        text-align: center;
        vertical-align: middle;
        font-weight: bold;
    }
    .jurnal-table td {
        border: 1px solid #dee2e6;
        vertical-align: middle;
    }
    .text-right {
        text-align: right !important;
    }
    .text-center {
        text-align: center !important;
    }
    .total-row {
        background-color: #e9ecef;
        font-weight: bold;
    }
    .koperasi-header {
        text-align: center;
        margin-bottom: 20px;
    }
    .koperasi-header h2 {
        margin: 0;
        font-size: 1.1rem;
        font-weight: bold;
    }
    .koperasi-header h3 {
        margin: 5px 0;
        font-size: 1rem;
        font-weight: bold;
    }
    .periode-header {
        text-align: center;
        margin: 20px 0;
        font-weight: bold;
        font-size: 0.95rem;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        .main-content {
            margin-left: 0 !important;
        }
        .jurnal-table {
            font-size: 0.8rem;
        }
    }
</style>
@endpush

@section('content')
<!-- Filter Section -->
<div class="card no-print mb-3">
    <div class="card-body">
        <div class="row align-items-center">
            <div class="col-md-6">
                <form method="GET" action="" class="row g-2" id="filterForm">
                    <div class="col-md-5">
                        <label class="form-label">Bulan</label>
                        <select class="form-select" id="filterBulan" name="bulan">
                            @foreach($bulanNama as $key => $value)
                                <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>
                                    {{ $value }}
                                </option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-md-5">
                        <label class="form-label">Tahun</label>
                        <select class="form-select" id="filterTahun" name="tahun">
                            @for($i = 2020; $i <= date('Y') + 1; $i++)
                                <option value="{{ $i }}" {{ $tahun == $i ? 'selected' : '' }}>{{ $i }}</option>
                            @endfor
                        </select>
                    </div>
                    <div class="col-md-2 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">
                            <i class="fas fa-filter"></i>
                        </button>
                    </div>
                </form>
            </div>
            <div class="col-md-6">
                <div class="d-flex gap-2 justify-content-end align-items-end h-100 mt-3">
                    <button class="btn btn-success" onclick="window.print()">
                        <i class="fas fa-print"></i> Cetak
                    </button>
                    <a href="{{ route('laporan.transaksi') }}" class="btn btn-secondary">
                        <i class="fas fa-arrow-left"></i> Kembali
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Penerimaan -->
<div class="card mb-4">
    <div class="card-body">
        <div class="koperasi-header">
            <h2>KOPERASI KARYAWAN PELABUHAN</h2>
            <h2>CABANG PALEMBANG</h2>
        </div>
        
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENERIMAAN KAS</h3>
            <h3>BULAN {{ $periodeName }}</h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($penerimaan as $index => $row)
                        <tr>
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center">{{ $row->kode_akun }}</td>
                            <td>{{ $row->nama_akun }}</td>
                            <td class="text-right">
                                {{ $row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-' }}
                            </td>
                            <td class="text-right">
                                {{ $row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi penerimaan untuk periode ini</em></td>
                        </tr>
                    @endforelse
                    @if($penerimaan->isNotEmpty())
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPenerimaan['debet'], 2, ',', '.') }}</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPenerimaan['kredit'], 2, ',', '.') }}</strong></td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Pengeluaran -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENGELUARAN KAS</h3>
            <h3>BULAN {{ $periodeName }}</h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($pengeluaran as $index => $row)
                        <tr>
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center">{{ $row->kode_akun }}</td>
                            <td>{{ $row->nama_akun }}</td>
                            <td class="text-right">
                                {{ $row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-' }}
                            </td>
                            <td class="text-right">
                                {{ $row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi pengeluaran untuk periode ini</em></td>
                        </tr>
                    @endforelse
                    @if($pengeluaran->isNotEmpty())
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPengeluaran['debet'], 2, ',', '.') }}</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPengeluaran['kredit'], 2, ',', '.') }}</strong></td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Rupa-Rupa -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL RUPA-RUPA</h3>
            <h3>BULAN {{ $periodeName }}</h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($rupaRupa as $index => $row)
                        <tr>
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center">{{ $row->kode_akun }}</td>
                            <td>{{ $row->nama_akun }}</td>
                            <td class="text-right">
                                {{ $row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-' }}
                            </td>
                            <td class="text-right">
                                {{ $row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi rupa-rupa untuk periode ini</em></td>
                        </tr>
                    @endforelse
                    @if($rupaRupa->isNotEmpty())
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsRupaRupa['debet'], 2, ',', '.') }}</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsRupaRupa['kredit'], 2, ',', '.') }}</strong></td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Ikhtisar Jurnal Penjualan Kredit -->
<div class="card mb-4">
    <div class="card-body">
        <div class="periode-header">
            <h3>IKHTISAR JURNAL PENJUALAN KREDIT</h3>
            <h3>BULAN {{ $periodeName }}</h3>
        </div>
        
        <div class="table-responsive">
            <table class="table jurnal-table">
                <thead>
                    <tr>
                        <th style="width: 50px;">NO</th>
                        <th style="width: 100px;">KODE REK</th>
                        <th>URAIAN</th>
                        <th colspan="2">MUTASI</th>
                    </tr>
                    <tr>
                        <th></th>
                        <th></th>
                        <th></th>
                        <th style="width: 150px;">DEBET</th>
                        <th style="width: 150px;">KREDIT</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($penjualanKredit as $index => $row)
                        <tr>
                            <td class="text-center">{{ $index + 1 }}</td>
                            <td class="text-center">{{ $row->kode_akun }}</td>
                            <td>{{ $row->nama_akun }}</td>
                            <td class="text-right">
                                {{ $row->total_debet > 0 ? number_format($row->total_debet, 2, ',', '.') : '-' }}
                            </td>
                            <td class="text-right">
                                {{ $row->total_kredit > 0 ? number_format($row->total_kredit, 2, ',', '.') : '-' }}
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center"><em>Tidak ada transaksi penjualan kredit untuk periode ini</em></td>
                        </tr>
                    @endforelse
                    @if($penjualanKredit->isNotEmpty())
                        <tr class="total-row">
                            <td colspan="3" class="text-center"><strong>JUMLAH</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPenjualanKredit['debet'], 2, ',', '.') }}</strong></td>
                            <td class="text-right"><strong>{{ number_format($totalsPenjualanKredit['kredit'], 2, ',', '.') }}</strong></td>
                        </tr>
                    @endif
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('filterBulan').addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });
    document.getElementById('filterTahun').addEventListener('change', function() {
        document.getElementById('filterForm').submit();
    });
});
</script>
@endpush
