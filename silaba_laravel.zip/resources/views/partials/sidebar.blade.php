<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <div class="sidebar-header">
        <h3><i class="fas fa-chart-line"></i> SIKOPKAR</h3>
    </div>
    <ul class="sidebar-menu">
        <li>
            <a href="{{ route('dashboard') }}" class="{{ request()->routeIs('dashboard') ? 'active' : '' }}">
                <i class="fas fa-home"></i>
                <span>Dashboard</span>
            </a>
        </li>
        
        @if(auth()->user()->isAdmin())
        <!-- Menu Koperasi -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>KOPERASI</span>
        </li>
        <li>
            <a href="{{ route('admin.anggota.index') }}" class="{{ request()->routeIs('admin.anggota.*') ? 'active' : '' }}">
                <i class="fas fa-users"></i>
                <span>Manajemen Anggota</span>
            </a>
        </li>
        <li>
            <a href="{{ route('admin.pinjaman.index') }}" class="{{ request()->routeIs('admin.pinjaman.*') && !request()->routeIs('admin.pinjaman.pengajuan*') ? 'active' : '' }}">
                <i class="fas fa-hand-holding-usd"></i>
                <span>Pinjaman</span>
            </a>
        </li>
        <li>
            <a href="{{ route('admin.pinjaman.pengajuan') }}" class="{{ request()->routeIs('admin.pinjaman.pengajuan*') ? 'active' : '' }}">
                <i class="fas fa-file-alt"></i>
                <span>Pengajuan Pinjaman</span>
                @php
                    $pendingCount = \App\Models\PengajuanPinjaman::pending()->count();
                @endphp
                @if($pendingCount > 0)
                    <span class="badge bg-danger ms-auto">{{ $pendingCount }}</span>
                @endif
            </a>
        </li>
        <li>
            <a href="{{ route('admin.manajemen-user.index') }}" class="{{ request()->routeIs('admin.manajemen-user.*') ? 'active' : '' }}">
                <i class="fas fa-user-cog"></i>
                <span>Manajemen User</span>
            </a>
        </li>
        
        <!-- Menu Akuntansi -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>AKUNTANSI</span>
        </li>
        <li>
            <a href="{{ route('transaksi.penerimaan') }}" class="{{ request()->routeIs('transaksi.penerimaan*') ? 'active' : '' }}">
                <i class="fas fa-download"></i>
                <span>Penerimaan</span>
            </a>
        </li>
        <li>
            <a href="{{ route('transaksi.pengeluaran') }}" class="{{ request()->routeIs('transaksi.pengeluaran*') ? 'active' : '' }}">
                <i class="fas fa-upload"></i>
                <span>Pengeluaran</span>
            </a>
        </li>
        <li>
            <a href="{{ route('transaksi.rupa-rupa') }}" class="{{ request()->routeIs('transaksi.rupa-rupa*') ? 'active' : '' }}">
                <i class="fas fa-exchange-alt"></i>
                <span>Rupa-rupa</span>
            </a>
        </li>
        <li>
            <a href="{{ route('saldo-awal.index') }}" class="{{ request()->routeIs('saldo-awal*') ? 'active' : '' }}">
                <i class="fas fa-wallet"></i>
                <span>Saldo Awal</span>
            </a>
        </li>
        <li>
            <a href="{{ route('kas-bank.index') }}" class="{{ request()->routeIs('kas-bank*') ? 'active' : '' }}">
                <i class="fas fa-money-bill-wave"></i>
                <span>Kas & Bank</span>
            </a>
        </li>
        @endif
        
        <!-- Menu Laporan -->
        <li style="padding: 10px 20px; color: rgba(255,255,255,0.5); font-size: 0.75rem; text-transform: uppercase;">
            <span>LAPORAN</span>
        </li>
        <li>
            <a href="{{ route('laporan.transaksi') }}" class="{{ request()->routeIs('laporan.transaksi*') ? 'active' : '' }}">
                <i class="fas fa-list"></i>
                <span>Laporan Transaksi</span>
            </a>
        </li>
        <li>
            <a href="{{ route('rekap.akun') }}" class="{{ request()->routeIs('rekap*') ? 'active' : '' }}">
                <i class="fas fa-calculator"></i>
                <span>Rekap Per Akun</span>
            </a>
        </li>
        <li>
            <a href="{{ route('ikhtisar.jurnal') }}" class="{{ request()->routeIs('ikhtisar*') ? 'active' : '' }}">
                <i class="fas fa-chart-bar"></i>
                <span>Ikhtisar Jurnal</span>
            </a>
        </li>
        <li>
            <a href="{{ route('neraca.index') }}" class="{{ request()->routeIs('neraca.index') ? 'active' : '' }}">
                <i class="fas fa-balance-scale"></i>
                <span>Neraca</span>
            </a>
        </li>
        <li>
            <a href="{{ route('neraca.mutasi') }}" class="{{ request()->routeIs('neraca.mutasi') ? 'active' : '' }}">
                <i class="fas fa-sync-alt"></i>
                <span>Neraca Mutasi</span>
            </a>
        </li>
        @if(auth()->user()->isAdmin() || auth()->user()->isPimpinan())
        <li>
            <a href="{{ route('neraca.review') }}" class="{{ request()->routeIs('neraca.review*') ? 'active' : '' }}">
                <i class="fas fa-clipboard-check"></i>
                <span>Review Neraca</span>
            </a>
        </li>
        @endif
        <li>
            <a href="{{ route('laba-rugi.index') }}" class="{{ request()->routeIs('laba-rugi*') ? 'active' : '' }}">
                <i class="fas fa-chart-line"></i>
                <span>Laba Rugi</span>
            </a>
        </li>
        <li>
            <a href="{{ route('piutang.index') }}" class="{{ request()->routeIs('piutang*') ? 'active' : '' }}">
                <i class="fas fa-file-invoice-dollar"></i>
                <span>Piutang</span>
            </a>
        </li>
        
        <!-- Logout -->
        <li style="margin-top: 20px;">
            <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                <i class="fas fa-sign-out-alt"></i>
                <span>Logout</span>
            </a>
            <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                @csrf
            </form>
        </li>
    </ul>
</div>
