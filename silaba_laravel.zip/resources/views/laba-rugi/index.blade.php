@extends('layouts.app')

@section('title', 'Laba Rugi')
@section('page-title', 'Laba Rugi')

@push('styles')
<style>
    .laba-rugi-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 10pt;
    }
    .laba-rugi-table td, .laba-rugi-table th {
        padding: 3px 5px;
        border: 1px solid #000;
    }
    .laba-rugi-table th {
        background-color: #f0f0f0;
        text-align: center;
        font-weight: bold;
        vertical-align: middle;
    }
    .laba-rugi-table td.text-right {
        font-family: 'Courier New', monospace;
    }
    .section-header {
        font-weight: bold;
    }
    .text-right {
        text-align: right;
    }
    .text-center {
        text-align: center;
    }
    .total-row {
        font-weight: bold;
        background-color: #e0e0e0;
    }
    .sub-total {
        font-weight: bold;
    }
    .grand-total {
        font-weight: bold;
        background-color: #ffffcc;
    }
    .laba-rugi-row {
        background-color: #e6ffe6;
        font-weight: bold;
    }
    .currency-input {
        text-align: right;
        font-family: 'Courier New', monospace;
    }
    .input-group-text.currency-prefix {
        background-color: #e9ecef;
        font-weight: 600;
        color: #495057;
        font-size: 0.8rem;
    }
    @media print {
        .no-print {
            display: none !important;
        }
        body {
            font-size: 10pt;
        }
        .main-content {
            margin-left: 0 !important;
        }
    }
</style>
@endpush

@section('content')
<!-- Filter Section -->
<div class="card mb-4 no-print">
    <div class="card-body">
        <form method="GET" action="" class="row g-3">
            <div class="col-md-3">
                <label class="form-label">Bulan</label>
                <select name="bulan" class="form-select" onchange="updateUrl()">
                    @foreach($bulanNama as $key => $value)
                        <option value="{{ $key }}" {{ $bulan == $key ? 'selected' : '' }}>
                            {{ $value }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label">Tahun</label>
                <input type="number" name="tahun" class="form-control" value="{{ $tahun }}" 
                       min="2020" max="2030" onchange="updateUrl()">
            </div>
            <div class="col-md-6 d-flex align-items-end gap-2">
                <button type="submit" name="generate" value="1" class="btn btn-primary">
                    <i class="fas fa-file-alt"></i> Generate Laba Rugi
                </button>
                @if($showLabaRugi ?? false)
                <button type="button" class="btn btn-info" onclick="window.print()">
                    <i class="fas fa-print"></i> Cetak
                </button>
                <a href="{{ route('export.laba-rugi', ['bulan' => $bulan, 'tahun' => $tahun]) }}" 
                   class="btn btn-success">
                    <i class="fas fa-file-excel"></i> Export Excel
                </a>
                <a href="{{ route('neraca.index', ['bulan' => $bulan, 'tahun' => $tahun]) }}" 
                   class="btn btn-warning">
                    <i class="fas fa-balance-scale"></i> Lihat Neraca
                </a>
                @endif
            </div>
        </form>
    </div>
</div>

@if($showLabaRugi ?? false)
<!-- Laba Rugi Header -->
<div class="text-center mb-3">
    <h5>KOPERASI KARYAWAN PELABUHAN<br>
    CABANG PALEMBANG</h5>
    <h4><strong>REALISASI PERHITUNGAN LABA-RUGI<br>
    BULAN {{ strtoupper($bulanNama[$bulan]) }} {{ $tahun }}</strong></h4>
</div>

<!-- Laba Rugi Table -->
<table class="laba-rugi-table">
    <thead>
        <tr>
            <th rowspan="2" width="5%">NO</th>
            <th rowspan="2" width="35%">URAIAN</th>
            <th rowspan="2" width="12%">Anggaran Tahun {{ $tahun }} (Rp)</th>
            <th rowspan="2" width="12%">Anggaran Triwulan IV (Rp)</th>
            <th colspan="3">Realisasi (Rp)</th>
        </tr>
        <tr>
            <th width="12%">S/D BULAN LALU</th>
            <th width="12%">BULAN INI</th>
            <th width="12%">S/D BULAN INI</th>
        </tr>
    </thead>
    <tbody>
        <!-- I. PENDAPATAN -->
        <tr>
            <td colspan="7" class="section-header">I. PENDAPATAN</td>
        </tr>
        @foreach($pendapatan as $item)
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 1:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah1, 0, ',', '.') }}</td>
        </tr>
        
        <!-- PENDAPATAN USAHA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">PENDAPATAN USAHA DILUAR ANGGOTA</td>
        </tr>
        @foreach($pendapatanUsaha as $item)
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 2:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah2, 0, ',', '.') }}</td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Pendapatan (1+2)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">Rp {{ number_format($jumlahPendapatan, 0, ',', '.') }}</td>
        </tr>
        
        <!-- II. BIAYA - BIAYA -->
        <tr>
            <td colspan="7" class="section-header">II. BIAYA - BIAYA</td>
        </tr>
        
        <!-- BIAYA DENGAN ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA DENGAN ANGGOTA</td>
        </tr>
        @foreach($biayaDenganAnggota as $item)
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 3:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah3, 0, ',', '.') }}</td>
        </tr>
        
        <!-- BIAYA - BIAYA DILUAR ANGGOTA -->
        <tr>
            <td colspan="7" class="section-header">BIAYA - BIAYA DILUAR ANGGOTA</td>
        </tr>
        @foreach($biayaDiluarAnggota as $item)
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 4:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah4, 0, ',', '.') }}</td>
        </tr>
        
        <!-- BIAYA ORGANISASI DAN MANAJEMEN -->
        <tr>
            <td colspan="7" class="section-header">BIAYA ORGANISASI DAN MANAJEMEN</td>
        </tr>
        @foreach($biayaOrganisasi as $item)
        <tr>
            <td class="text-center">{{ $item->kode_akun }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td class="text-right">{{ number_format($item->anggaran_tahun, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->anggaran_triwulan, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->realisasi_bulan_lalu, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->mutasi_bulan_ini, 0, ',', '.') }}</td>
            <td class="text-right">{{ number_format($item->sd_bulan_ini, 0, ',', '.') }}</td>
        </tr>
        @endforeach
        
        <tr class="sub-total">
            <td colspan="2" class="text-right">Jumlah 5:</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">{{ number_format($jumlah5, 0, ',', '.') }}</td>
        </tr>
        
        <tr class="total-row">
            <td colspan="2" class="text-center">Jumlah Biaya (3+4+5)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">Rp {{ number_format($jumlahBiaya, 0, ',', '.') }}</td>
        </tr>
        
        <!-- LABA RUGI CALCULATIONS -->
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (1-3)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">Rp {{ number_format($labaRugi1_3, 0, ',', '.') }}</td>
        </tr>
        
        <tr class="laba-rugi-row">
            <td colspan="2" class="text-center">Laba - Rugi (2-4)</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">Rp {{ number_format($labaRugi2_4, 0, ',', '.') }}</td>
        </tr>
        
        <tr class="grand-total">
            <td colspan="2" class="text-center"><strong>Laba - Rugi (I-II)</strong></td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right">-</td>
            <td class="text-right"><strong>Rp {{ number_format($labaRugiBersih, 0, ',', '.') }}</strong></td>
        </tr>
    </tbody>
</table>

<div class="alert alert-info mt-3 no-print">
    <strong>Informasi:</strong>
    <ul>
        <li>Nilai Laba/Rugi Bersih: <strong>Rp {{ number_format($labaRugiBersih, 0, ',', '.') }}</strong></li>
        <li>Laba Rugi (1-3): <strong>Rp {{ number_format($labaRugi1_3, 0, ',', '.') }}</strong></li>
        <li>Laba Rugi (2-4): <strong>Rp {{ number_format($labaRugi2_4, 0, ',', '.') }}</strong></li>
        <li>Nilai ini akan dicatat sebagai SHU Tahun Berjalan (kode 900) di Neraca</li>
    </ul>
</div>

<!-- Form untuk input/update anggaran -->
<div class="card mt-3 no-print">
    <div class="card-header bg-secondary text-white">
        <h6 class="mb-0">Update Anggaran & Realisasi S/D Bulan Lalu</h6>
    </div>
    <div class="card-body">
        <form method="POST" action="{{ route('laba-rugi.store-anggaran') }}">
            @csrf
            <input type="hidden" name="periode" value="{{ $tahun }}-{{ $bulan }}-01">
            <input type="hidden" name="redirect_url" value="{{ route('laba-rugi.index', ['bulan' => $bulan, 'tahun' => $tahun, 'generate' => 1]) }}">
            
            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Nama Akun</th>
                            <th>Anggaran Tahun (Rp)</th>
                            <th>Anggaran Triwulan (Rp)</th>
                            <th>Realisasi S/D Bulan Lalu (Rp)</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($allAccounts as $acc)
                        @php
                            $accObj = is_array($acc) ? (object)$acc : $acc;
                        @endphp
                        <tr>
                            <td>{{ $accObj->kode_akun }}</td>
                            <td>{{ $accObj->nama_akun }}</td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="anggaran_tahun[{{ $accObj->kode_akun }}]" 
                                           class="form-control form-control-sm currency-input" 
                                           value="{{ number_format($accObj->anggaran_tahun, 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this);"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="anggaran_triwulan[{{ $accObj->kode_akun }}]" 
                                           class="form-control form-control-sm currency-input" 
                                           value="{{ number_format($accObj->anggaran_triwulan, 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this);"
                                           onfocus="this.select();">
                                </div>
                            </td>
                            <td>
                                <div class="input-group input-group-sm">
                                    <span class="input-group-text currency-prefix">Rp</span>
                                    <input type="text" name="realisasi_bulan_lalu[{{ $accObj->kode_akun }}]" 
                                           class="form-control form-control-sm currency-input" 
                                           value="{{ number_format($accObj->realisasi_bulan_lalu, 0, ',', '.') }}"
                                           onkeyup="formatCurrencyInput(this);"
                                           onfocus="this.select();">
                                </div>
                            </td>
                        </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
            
            <button type="submit" class="btn btn-primary">
                <i class="fas fa-save"></i> Simpan Anggaran
            </button>
        </form>
    </div>
</div>

@endif
@endsection

@push('scripts')
<script>
function updateUrl() {
    const bulan = document.querySelector('[name="bulan"]').value;
    const tahun = document.querySelector('[name="tahun"]').value;
    window.location.href = `?bulan=${bulan}&tahun=${tahun}`;
}

// Format currency input
function formatCurrencyInput(input) {
    let value = input.value;
    value = value.replace(/[^\d,]/g, '');
    let parts = value.split(',');
    
    if (parts[0]) {
        parts[0] = parts[0].replace(/^0+/, '') || '0';
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    if (parts.length > 1) {
        parts[1] = parts[1].substring(0, 2);
    }
    
    input.value = parts.join(',');
}
</script>
@endpush
